import 'dotenv/config';
import express, { NextFunction, Request, Response } from 'express';
import cors from 'cors';
import multer from 'multer';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { EdgeTTS } from 'node-edge-tts';
import {
  assertValidEdgeVoiceId,
  buildAutoBlurFfmpegFilter,
  buildTtsVoicePersonaDirective,
  DEFAULT_AUTO_BLUR_CONFIG,
  DEFAULT_EDGE_VOICE_ID,
  DEFAULT_TTS_ENGINE,
  detectStaticOverlayRegionsFromPpmFrames,
  EDGE_BURMESE_VOICES,
  enforceSingleVoiceForDubbingSegments,
  extractMediaDurationSeconds,
  generateAssSubtitles,
  getGeminiFreeVoice,
  getVoiceSpeedFactor,
  isAudibleNonSilentStats,
  MAX_UPLOAD_FILE_BYTES,
  MAX_VIDEO_DURATION_SECONDS,
  normalizeMyanmarVoiceId,
  normalizeTtsEngineId,
  normalizeVoiceSpeed,
  parseFfmpegVolumeStats,
  parseVoiceSpeedInput,
  resolveCaptionsEnabledFlag,
  resolveEdgeVoiceForGender,
  sanitizeAutoBlurConfig,
  sanitizeAutoBlurRegions,
  sanitizeTtsSpeechText,
  shouldBurnSubtitlesInRender,
  splitLongCaptionsToMaxTwoLines,
  splitScriptIntoTimedCaptions,
  splitTextIntoTtsChunks,
  truncateThumbnailTitle,
  validateEdgeTtsInputText,
  validateVideoDuration,
  validateVideoUrl,
  validateVoiceGenderForTool,
  wrapWavHeaderIfNeeded,
  CREDIT_PACKAGES,
} from './src/utils/studioLogic';
import {
  applyMyanmarScriptToTimeline,
  buildAtempoFilterChain,
  buildFullRecapBeats,
  buildOriginalAudioCaptions,
  buildProportionalCaptionsForDuration,
  buildSilenceCutFfmpegFilter,
  buildTimelineFromGroq,
  computeKeepAudioSegmentsFromSilences,
  computeUniformDubbingSchedule,
  computeVideoSpeedSyncPlan,
  DEFAULT_AUTO_SILENCE_CUT_CONFIG,
  getAudioTtsPostFilter,
  normalizeTranscriptSegments,
  parseSilenceDetectOutput,
  protectSpeechIntervalsInKeptSegments,
  remapCaptionsForSilenceCut,
  sanitizeAutoSilenceCutConfig,
  splitAudioBoundariesForSegments,
  type GroqSegmentTimestamp,
  type GroqWordTimestamp,
} from './src/utils/audioSync';
import {
  computeCandidateFrameTimestamps,
  getThumbnailDimensions,
  normalizeThumbnailAspectRatio,
  sanitizeThumbnailAnalysisResponse,
  type RawVisionThumbnailResponse,
} from './src/utils/thumbnailLogic';
import {
  extractRetryAfterSeconds,
  isModelNotFoundError,
  isQuotaRateLimitError,
  isTransientNetworkError,
  ModelCooldownTracker,
  withTransientRetry,
} from './src/utils/retry';
import {
  classifySceneProviderError,
  computeRepresentativeFrameTimestamps,
  computeResumeBatchIndex,
  deduplicateExtractedFrames,
  formatSceneProviderStatusMy,
  GROQ_VISION_MAX_IMAGES_PER_REQUEST,
  isGeminiQuotaExhaustedError,
  isProviderAuthError,
  mergeScenesChronologically,
  partitionFramesIntoBatches,
  PROVIDER_STATUS_MY,
  selectGroqVisionModelCandidates,
  type ExtractedFrameMeta,
  type SceneAnalysisCheckpoint,
} from './src/utils/sceneAnalysis';
import {
  auditRecapCharacterConsistency,
  buildRecapAutoExpansionPrompt,
  buildRecapCharacterConsistencyPrompt,
  buildRecapMixedNarrationPrompt,
  extractVerifiedCharacterClues,
  hasSubstantiveTranscript,
  selectRecapBeatsForAutoExpansion,
  validateAndRefineRecapSegments,
  type TimestampedTranscriptItem,
  type VerifiedCharacterProfile,
} from './src/utils/recapScript';
import type {
  AutoBlurRegion,
  AutoSilenceCutConfig,
  CaptionSegment,
  EdgeVoiceId,
  ExportResolution,
  MusicMood,
  MyanmarVoiceId,
  SceneAnalysisProvider,
  SceneSummary,
  SilenceCutPlan,
  StudioTool,
  SyncSummary,
  ThumbnailAspectRatio,
  TtsEngineId,
  VideoTimelineSegment,
  VoiceGender,
  VoiceSpeed,
} from './src/types/studio';

const execFileAsync = promisify(execFile);

const PORT = Number(process.env.PORT || 3000);
const SESSION_ROOT = path.join(os.tmpdir(), 'alpharecap-sessions');
fs.mkdirSync(SESSION_ROOT, { recursive: true });
const UPLOAD_TMP_DIR = path.join(os.tmpdir(), 'alpharecap-uploads');
fs.mkdirSync(UPLOAD_TMP_DIR, { recursive: true });

const SAMPLE_CACHE_DIR = path.join(os.tmpdir(), 'alpharecap-sample');
fs.mkdirSync(SAMPLE_CACHE_DIR, { recursive: true });
const SAMPLE_VIDEO_PATH = path.join(SAMPLE_CACHE_DIR, 'sample_noir_v3.mp4');

// Track session last-accessed timestamps for automatic zero-persistence cleanup
const sessionLastActive = new Map<string, number>();

// Shared cooldown tracker so exhausted Free Tier models (429 / 404) are skipped cleanly
const geminiCooldowns = new ModelCooldownTracker();

function getSessionDir(sessionId: string): string {
  const safeId = sessionId.replace(/[^a-zA-Z0-9_-]/g, '');
  if (!safeId) throw new Error('Invalid session ID');
  const dir = path.join(SESSION_ROOT, safeId);
  fs.mkdirSync(dir, { recursive: true });
  sessionLastActive.set(safeId, Date.now());
  return dir;
}

function cleanupSessionDir(sessionId: string): void {
  const safeId = sessionId.replace(/[^a-zA-Z0-9_-]/g, '');
  if (!safeId) return;
  const dir = path.join(SESSION_ROOT, safeId);
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
  sessionLastActive.delete(safeId);
}

// Sweep stale temporary sessions every 5 minutes (15-minute max idle TTL)
setInterval(() => {
  const now = Date.now();
  for (const [id, lastSeen] of sessionLastActive.entries()) {
    if (now - lastSeen > 15 * 60 * 1000) {
      cleanupSessionDir(id);
    }
  }
}, 5 * 60 * 1000).unref();

function createGeminiClient(apiVersion?: 'v1' | 'v1beta'): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey === 'YOUR_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    ...(apiVersion ? { apiVersion } : {}),
    httpOptions: {
      ...(apiVersion ? { apiVersion } : {}),
      timeout: 60000,
      retryOptions: { attempts: 1 },
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function getGroqApiKey(): string | null {
  const key = process.env.GROQ_API_KEY?.trim();
  if (!key || key === 'YOUR_GROQ_API_KEY') return null;
  return key;
}

const groqModelsCache: { fetchedAt: number; ids: string[] } = {
  fetchedAt: 0,
  ids: [],
};

const groqInvalidKeys = new Set<string>();

async function getGroqAvailableModelIds(groqKey: string): Promise<string[]> {
  if (groqInvalidKeys.has(groqKey)) return [];
  const now = Date.now();
  if (groqModelsCache.ids.length > 0 && now - groqModelsCache.fetchedAt < 10 * 60 * 1000) {
    return groqModelsCache.ids;
  }
  try {
    const res = await withTransientRetry(
      () =>
        fetch('https://api.groq.com/openai/v1/models', {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${groqKey}`,
          },
        }),
      2,
      400
    );
    if (res.status === 401 || res.status === 403) {
      groqInvalidKeys.add(groqKey);
      return [];
    }
    if (!res.ok) return groqModelsCache.ids;
    const payload = (await res.json()) as { data?: Array<{ id?: string }> };
    const ids = (payload.data || [])
      .map((m) => String(m?.id || '').trim())
      .filter(Boolean);
    if (ids.length > 0) {
      groqModelsCache.ids = ids;
      groqModelsCache.fetchedAt = now;
    }
    return ids;
  } catch {
    return groqModelsCache.ids;
  }
}

async function transcribeAudioBufferWithGemini(
  audioBuf: Buffer,
  chunkDurationSec: number
): Promise<{ text: string; segments: GroqSegmentTimestamp[]; words: GroqWordTimestamp[] }> {
  const aiBeta = createGeminiClient('v1beta');
  const aiV1 = createGeminiClient('v1');
  const candidates: Array<{ client: GoogleGenAI | null; model: string }> = [
    { client: aiBeta, model: 'gemini-4-hydrogen' },
    { client: aiV1, model: 'gemini-4-hydrogen' },
    { client: aiBeta, model: 'gemini-3.1-flash-lite' },
  ];

  const base64Audio = audioBuf.toString('base64');
  const safeMaxDur = Math.max(1, Number.isFinite(chunkDurationSec) ? chunkDurationSec : 12);
  let lastErr: unknown = null;

  for (const cand of candidates) {
    if (!cand.client) continue;
    try {
      const resp = await withTransientRetry(
        () =>
          cand.client!.models.generateContent({
            model: cand.model,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: 'audio/mpeg',
                    data: base64Audio,
                  },
                },
                {
                  text: `Transcribe ONLY actual spoken dialogue/narration in this ${safeMaxDur.toFixed(1)}s audio clip with accurate timestamps in seconds (0 to ${safeMaxDur.toFixed(1)}). If there is no clear spoken dialogue (only music, rain, noise, or silence), return empty text "" and empty segments []. Return strict JSON: { "text": string, "segments": [{ "start": number, "end": number, "text": string }] }.`,
                },
              ],
            },
            config: {
              systemInstruction:
                'You are an accurate audio speech transcriber. Never invent speech when audio contains only music, ambient noise, or tones. Return strict JSON matching { "text": string, "segments": [{ "start": number, "end": number, "text": string }] }.',
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING },
                  segments: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        start: { type: Type.NUMBER },
                        end: { type: Type.NUMBER },
                        text: { type: Type.STRING },
                      },
                      required: ['start', 'end', 'text'],
                    },
                  },
                },
                required: ['text', 'segments'],
              },
            },
          }),
        2,
        500
      );

      const rawText = String(resp?.text || '').trim();
      if (!rawText) continue;
      const parsed = JSON.parse(rawText) as {
        text?: string;
        segments?: Array<{ start?: number; end?: number; text?: string }>;
      };
      const cleanSegments: GroqSegmentTimestamp[] = (parsed.segments || [])
        .map((s) => ({
          start: Math.max(0, Math.min(safeMaxDur, Number(s.start || 0))),
          end: Math.max(0, Math.min(safeMaxDur, Number(s.end || 0))),
          text: String(s.text || '').trim(),
        }))
        .filter((s) => s.text.length > 0 && s.end > s.start)
        .sort((a, b) => a.start - b.start);

      const cleanText = String(parsed.text || '').trim() || cleanSegments.map((s) => s.text).join(' ').trim();
      return {
        text: cleanText,
        segments: cleanSegments,
        words: [],
      };
    } catch (err) {
      lastErr = err;
      if (isModelNotFoundError(err) || isQuotaRateLimitError(err) || isTransientNetworkError(err)) {
        continue;
      }
    }
  }

  throw lastErr instanceof Error ? lastErr : new Error('Gemini audio transcription unavailable');
}

class SceneProviderBatchError extends Error {
  readonly provider: SceneAnalysisProvider;
  readonly isQuota: boolean;
  readonly errorMy: string;

  constructor(provider: SceneAnalysisProvider, isQuota: boolean, errorMy: string, causeMessage?: string) {
    super(causeMessage || errorMy);
    this.name = 'SceneProviderBatchError';
    this.provider = provider;
    this.isQuota = isQuota;
    this.errorMy = errorMy;
  }
}

function getTelegramBotToken(): string | null {
  const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
  if (!token || token === 'YOUR_TELEGRAM_BOT_TOKEN') return null;
  return token;
}

async function checkBinary(name: string): Promise<boolean> {
  try {
    await execFileAsync('which', [name]);
    return true;
  } catch {
    return false;
  }
}

function moveFileSafely(srcPath: string, destPath: string): void {
  if (srcPath === destPath) return;
  try {
    fs.renameSync(srcPath, destPath);
  } catch {
    fs.copyFileSync(srcPath, destPath);
    fs.rmSync(srcPath, { force: true });
  }
}

async function probeVideo(filePath: string): Promise<{
  duration: number;
  width: number;
  height: number;
  hasAudio: boolean;
  formatName: string;
  videoCodec: string;
  pixFmt: string;
  audioCodec: string;
}> {
  const { stdout } = await execFileAsync('ffprobe', [
    '-v',
    'quiet',
    '-print_format',
    'json',
    '-show_format',
    '-show_streams',
    filePath,
  ]);
  const info = JSON.parse(stdout || '{}');
  const videoStream = (info.streams || []).find((s: { codec_type?: string }) => s.codec_type === 'video');
  const audioStream = (info.streams || []).find((s: { codec_type?: string }) => s.codec_type === 'audio');
  if (!videoStream) {
    throw new Error('No video stream found in uploaded file');
  }
  let duration = extractMediaDurationSeconds(info);
  if (duration <= 0) {
    // Fallback for malformed container headers missing duration metadata
    try {
      const { stderr } = await execFileAsync('ffmpeg', ['-i', filePath, '-f', 'null', '-']);
      const matches = [...String(stderr || '').matchAll(/time=(\d+):(\d+):(\d+(?:\.\d+)?)/g)];
      const last = matches[matches.length - 1];
      if (last) {
        duration = Number(last[1]) * 3600 + Number(last[2]) * 60 + Number(last[3]);
      }
    } catch {
      // ignore
    }
  }
  const rawWidth = Number(videoStream?.width || 1280);
  const rawHeight = Number(videoStream?.height || 720);
  const rotateTag = Number(
    videoStream?.tags?.rotate ??
      (Array.isArray(videoStream?.side_data_list)
        ? videoStream.side_data_list.find((d: { rotation?: number }) => typeof d?.rotation === 'number')?.rotation
        : 0) ??
      0
  );
  const isRotatedPortrait = Math.abs(Math.round(rotateTag)) % 180 === 90;
  return {
    duration: Number.isFinite(duration) ? duration : 0,
    width: isRotatedPortrait ? rawHeight : rawWidth,
    height: isRotatedPortrait ? rawWidth : rawHeight,
    hasAudio: Boolean(audioStream),
    formatName: String(info.format?.format_name || '').toLowerCase(),
    videoCodec: String(videoStream?.codec_name || '').toLowerCase(),
    pixFmt: String(videoStream?.pix_fmt || '').toLowerCase(),
    audioCodec: String(audioStream?.codec_name || '').toLowerCase(),
  };
}

async function finalizeUploadedSourceVideo(
  rawPath: string,
  targetMp4Path: string,
  originalFilename: string
): Promise<{ duration: number; width: number; height: number; hasAudio: boolean }> {
  const ext = path.extname(originalFilename || '').toLowerCase();
  const initialMeta = await probeVideo(rawPath);
  const isMp4Container =
    (!ext || ext === '.mp4' || ext === '.m4v') &&
    (initialMeta.formatName.includes('mp4') || initialMeta.formatName.includes('mov'));
  const isBrowserVideoCompatible =
    initialMeta.videoCodec === 'h264' &&
    (!initialMeta.pixFmt || initialMeta.pixFmt === 'yuv420p');
  const isBrowserAudioCompatible =
    !initialMeta.hasAudio ||
    initialMeta.audioCodec === 'aac' ||
    initialMeta.audioCodec === 'mp3';

  if (isMp4Container && isBrowserVideoCompatible && isBrowserAudioCompatible) {
    moveFileSafely(rawPath, targetMp4Path);
    return initialMeta;
  }

  try {
    // Ensure universal browser H.264 (yuv420p) + AAC MP4 with faststart metadata
    await execFileAsync('ffmpeg', [
      '-y',
      '-i',
      rawPath,
      '-c:v',
      isBrowserVideoCompatible ? 'copy' : 'libx264',
      ...(isBrowserVideoCompatible
        ? []
        : ['-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-preset', 'veryfast', '-pix_fmt', 'yuv420p']),
      ...(initialMeta.hasAudio ? ['-c:a', isBrowserAudioCompatible ? 'copy' : 'aac'] : ['-an']),
      '-movflags',
      '+faststart',
      targetMp4Path,
    ]);
    fs.rmSync(rawPath, { force: true });
    const finalMeta = await probeVideo(targetMp4Path);
    return finalMeta;
  } catch {
    moveFileSafely(rawPath, targetMp4Path);
    return initialMeta;
  }
}

async function probeAudioDuration(filePath: string): Promise<number> {
  const { stdout } = await execFileAsync('ffprobe', [
    '-v',
    'quiet',
    '-print_format',
    'json',
    '-show_format',
    '-show_streams',
    filePath,
  ]);
  const info = JSON.parse(stdout || '{}');
  const audioStream = (info.streams || []).find((s: { codec_type?: string }) => s.codec_type === 'audio');
  const duration = Number(info.format?.duration || audioStream?.duration || 0);
  return Number.isFinite(duration) && duration > 0 ? duration : 1.0;
}

async function detectAudioSilences(audioPath: string): Promise<ReturnType<typeof parseSilenceDetectOutput>> {
  return detectAudioSilencesWithConfig(audioPath, -32, 0.18);
}

async function detectAudioSilencesWithConfig(
  audioPath: string,
  noiseThresholdDb = -35,
  minSilenceDuration = 0.45
): Promise<ReturnType<typeof parseSilenceDetectOutput>> {
  const safeDb = Math.round(Math.min(-18, Math.max(-55, noiseThresholdDb)));
  const safeMin = Math.min(3.0, Math.max(0.15, minSilenceDuration));
  try {
    const { stderr } = await execFileAsync('ffmpeg', [
      '-i',
      audioPath,
      '-af',
      `silencedetect=noise=${safeDb}dB:d=${safeMin.toFixed(2)}`,
      '-f',
      'null',
      '-',
    ]);
    return parseSilenceDetectOutput(stderr || '');
  } catch (err) {
    const stderr = (err as { stderr?: string })?.stderr || '';
    return parseSilenceDetectOutput(stderr);
  }
}

class TtsQuotaError extends Error {
  retryAfterSeconds: number;
  constructor(message: string, retryAfterSeconds: number) {
    super(message);
    this.name = 'TtsQuotaError';
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

class EdgeTtsProviderError extends Error {
  voiceId: EdgeVoiceId;
  constructor(message: string, voiceId: EdgeVoiceId) {
    super(message);
    this.name = 'EdgeTtsProviderError';
    this.voiceId = voiceId;
  }
}

async function validateAudibleSpeechFile(
  audioPath: string,
  label = 'Generated TTS Audio'
): Promise<{ duration: number; maxVolumeDb: number | null; meanVolumeDb: number | null }> {
  if (!fs.existsSync(audioPath)) {
    throw new Error(`${label} failed validation: output file missing`);
  }
  const fileSize = fs.statSync(audioPath).size;
  if (fileSize < 512) {
    throw new Error(`${label} failed validation: output file too small (${fileSize} bytes)`);
  }

  const duration = await probeAudioDuration(audioPath);
  let stderrText = '';
  try {
    const res = await execFileAsync('ffmpeg', [
      '-i',
      audioPath,
      '-af',
      'volumedetect',
      '-f',
      'null',
      '-',
    ]);
    stderrText = String(res.stderr || '');
  } catch (err) {
    stderrText = String((err as { stderr?: string })?.stderr || '');
    if (!stderrText.includes('max_volume')) {
      throw new Error(
        `${label} validation failed: ${err instanceof Error ? err.message : 'FFmpeg volumedetect error'}`
      );
    }
  }

  const stats = parseFfmpegVolumeStats(stderrText);
  const check = isAudibleNonSilentStats(stats, duration);
  if (!check.valid) {
    throw new Error(`${label}: ${check.reason}`);
  }
  return {
    duration,
    maxVolumeDb: stats.maxVolumeDb,
    meanVolumeDb: stats.meanVolumeDb,
  };
}

function isRetryableEdgeTtsError(err: unknown): boolean {
  const msg = String(err instanceof Error ? err.message : err || '').toLowerCase();
  return (
    msg.includes('timed out') ||
    msg.includes('timeout') ||
    msg.includes('econnreset') ||
    msg.includes('etimedout') ||
    msg.includes('eai_again') ||
    msg.includes('enotfound') ||
    msg.includes('socket') ||
    msg.includes('websocket') ||
    msg.includes('closed') ||
    msg.includes('502') ||
    msg.includes('503') ||
    msg.includes('429')
  );
}

async function synthesizeEdgeTtsAudioToFile(
  textToSpeak: string,
  edgeVoiceId: EdgeVoiceId,
  targetMp3Path: string
): Promise<void> {
  const verifiedVoiceId = assertValidEdgeVoiceId(edgeVoiceId);
  const cleanedText = validateEdgeTtsInputText(textToSpeak);
  const chunks = splitTextIntoTtsChunks(cleanedText, 850);
  if (chunks.length === 0) {
    throw new EdgeTtsProviderError(
      `Edge Burmese Neural (${verifiedVoiceId}) အတွက် စကားပြောစာသား မတွေ့ရှိပါ`,
      verifiedVoiceId
    );
  }

  const synthesizeSingleChunk = async (chunkText: string, chunkOutMp3: string): Promise<void> => {
    const maxAttempts = 3;
    let lastError: unknown = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        fs.rmSync(chunkOutMp3, { force: true });
        const tts = new EdgeTTS({
          voice: verifiedVoiceId,
          lang: 'my-MM',
          outputFormat: 'audio-24khz-48kbitrate-mono-mp3',
          rate: '+0%',
          timeout: 25000,
        });
        await tts.ttsPromise(chunkText, chunkOutMp3);
        await validateAudibleSpeechFile(chunkOutMp3, `Edge Burmese Neural (${verifiedVoiceId})`);
        return;
      } catch (err) {
        lastError = err;
        fs.rmSync(chunkOutMp3, { force: true });
        if (attempt < maxAttempts && (isRetryableEdgeTtsError(err) || String(err).includes('too small'))) {
          const delayMs = 500 * attempt + Math.floor(Math.random() * 250);
          await new Promise((resolve) => setTimeout(resolve, delayMs));
          continue;
        }
        break;
      }
    }

    const reason =
      lastError instanceof Error ? lastError.message : String(lastError || 'Unknown Edge TTS error');
    throw new EdgeTtsProviderError(
      `Edge Burmese Neural (${verifiedVoiceId}) အသံထုတ်လုပ်မှု မအောင်မြင်ပါ: ${reason}`,
      verifiedVoiceId
    );
  };

  if (chunks.length === 1) {
    await synthesizeSingleChunk(chunks[0], targetMp3Path);
    return;
  }

  // Synthesize multi-chunk long text independently & join cleanly via FFmpeg concat
  const chunkFiles: string[] = [];
  try {
    for (let i = 0; i < chunks.length; i++) {
      const chunkPath = `${targetMp3Path}.part${i}.mp3`;
      await synthesizeSingleChunk(chunks[i], chunkPath);
      chunkFiles.push(chunkPath);
    }

    const inputs: string[] = ['-y'];
    const filterParts: string[] = [];
    const concatLabels: string[] = [];
    chunkFiles.forEach((f, idx) => {
      inputs.push('-i', f);
      filterParts.push(`[${idx}:a]aresample=24000,aformat=channel_layouts=mono[ec_${idx}]`);
      concatLabels.push(`[ec_${idx}]`);
    });
    filterParts.push(`${concatLabels.join('')}concat=n=${chunkFiles.length}:v=0:a=1[ec_out]`);

    await execFileAsync('ffmpeg', [
      ...inputs,
      '-filter_complex',
      filterParts.join(';'),
      '-map',
      '[ec_out]',
      '-b:a',
      '48k',
      targetMp3Path,
    ]);
    await validateAudibleSpeechFile(targetMp3Path, `Edge Burmese Neural (${verifiedVoiceId})`);
  } finally {
    for (const f of chunkFiles) {
      fs.rmSync(f, { force: true });
    }
  }
}

function isAuthCredentialError(err: unknown): boolean {
  const msg = String(err instanceof Error ? err.message : err || '').toLowerCase();
  const status = Number((err as { status?: number })?.status || 0);
  return (
    status === 401 ||
    status === 403 ||
    msg.includes('api_key_invalid') ||
    msg.includes('api key not valid') ||
    msg.includes('permission_denied')
  );
}

async function synthesizeGeminiTtsAudio(
  textToSpeak: string,
  _speed: VoiceSpeed,
  multiSegment = false,
  voiceStyle: MyanmarVoiceId = 'street_bro',
  voiceGender: VoiceGender = 'male'
): Promise<Uint8Array> {
  const cleanedSpeechText = validateEdgeTtsInputText(textToSpeak);
  const resolvedVoice = getGeminiFreeVoice(voiceStyle);
  const voiceDirective = buildTtsVoicePersonaDirective(voiceGender, resolvedVoice.id);

  // Keep Gemini reading pace steady at 1.0x across ALL calls so FFmpeg WSOLA controls speed uniformly
  // without erratic double-compounding or sudden sentence-to-sentence pace fluctuations.
  const paceDirective =
    'Read at a steady, clear, uniform natural 1.0x pace from start to finish without speeding up or slowing down.';
  const pauseDirective = multiSegment
    ? ' Pause briefly (about half a second) between each separate paragraph line.'
    : '';

  const ttsPrompt = `${voiceDirective} ${paceDirective}${pauseDirective} Read the following Burmese (Myanmar) movie narration aloud naturally without reading punctuation or instructions:\n\n${cleanedSpeechText}`;

  // CRITICAL RULE COMPLIANCE: No "speechMetadata" and no "speechConfig" anywhere in the request!
  const candidates: Array<{ apiVersion: 'v1beta' | 'v1'; model: string }> = resolvedVoice.preferExpressiveModel
    ? [
        { apiVersion: 'v1beta', model: 'gemini-2.5-flash-preview-tts' },
        { apiVersion: 'v1beta', model: 'gemini-3.8-flash-tts' },
        { apiVersion: 'v1beta', model: 'gemini-2.5-pro-preview-tts' },
        { apiVersion: 'v1beta', model: 'gemini-3.8-flash-lite-tts' },
        { apiVersion: 'v1', model: 'gemini-3.8-flash-lite-tts' },
      ]
    : [
        { apiVersion: 'v1beta', model: 'gemini-2.5-flash-preview-tts' },
        { apiVersion: 'v1beta', model: 'gemini-3.8-flash-lite-tts' },
        { apiVersion: 'v1beta', model: 'gemini-3.8-flash-tts' },
        { apiVersion: 'v1beta', model: 'gemini-2.5-pro-preview-tts' },
        { apiVersion: 'v1', model: 'gemini-3.8-flash-lite-tts' },
      ];

  type TtsResult = Awaited<ReturnType<GoogleGenAI['models']['generateContent']>>;
  const triedKeys = new Set<string>();
  let ttsResponse: TtsResult | null = null;
  let lastError: unknown = null;
  let sawQuotaLimit = false;
  let shortestRetryAfter = 35;

  const tryCandidate = async (apiVersion: 'v1beta' | 'v1', model: string): Promise<TtsResult | null> => {
    const key = `${apiVersion}:${model}`;
    if (triedKeys.has(key)) return null;
    triedKeys.add(key);

    const quotaKey = `quota:${model}`;
    const notFoundKey = `notfound:${apiVersion}:${model}`;
    if (geminiCooldowns.isCoolingDown(notFoundKey)) return null;
    if (geminiCooldowns.isCoolingDown(quotaKey)) {
      sawQuotaLimit = true;
      const rem = geminiCooldowns.getRemainingSeconds(quotaKey);
      if (rem > 0 && rem < shortestRetryAfter) {
        shortestRetryAfter = rem;
      }
      return null;
    }

    const client = createGeminiClient(apiVersion);
    if (!client) return null;

    try {
      const resp = await withTransientRetry(
        () =>
          client.models.generateContent({
            model,
            contents: [{ role: 'user', parts: [{ text: ttsPrompt }] }],
            config: { responseModalities: ['AUDIO'] },
          }),
        2,
        600
      );
      const hasAudioPart = (resp.candidates?.[0]?.content?.parts ?? []).some((p) => Boolean(p.inlineData?.data));
      if (!hasAudioPart) {
        lastError = new Error(`Model ${model} returned empty audio payload`);
        return null;
      }
      return resp;
    } catch (err) {
      lastError = err;

      if (isAuthCredentialError(err)) {
        throw err;
      }

      if (isQuotaRateLimitError(err)) {
        sawQuotaLimit = true;
        const parsedDelay = extractRetryAfterSeconds(err) || 35;
        geminiCooldowns.markCoolingDown(quotaKey, parsedDelay);
        if (parsedDelay < shortestRetryAfter) {
          shortestRetryAfter = parsedDelay;
        }
        return null;
      }

      if (isModelNotFoundError(err)) {
        geminiCooldowns.markCoolingDown(notFoundKey, 6 * 3600);
        return null;
      }

      // Fail over cleanly to the remaining TTS models on unsupported model / 400 / transient 5xx errors
      if (isTransientNetworkError(err)) {
        geminiCooldowns.markCoolingDown(quotaKey, 8);
      } else {
        geminiCooldowns.markCoolingDown(notFoundKey, 600);
      }
      return null;
    }
  };

  for (const candidate of candidates) {
    ttsResponse = await tryCandidate(candidate.apiVersion, candidate.model);
    if (ttsResponse) break;
  }

  if (!ttsResponse) {
    const betaClient = createGeminiClient('v1beta');
    if (betaClient) {
      try {
        const pager = await withTransientRetry(() => betaClient.models.list(), 2, 500);
        for await (const m of pager) {
          const modelName = (m.name || '').replace(/^models\//, '');
          const actions = m.supportedActions || [];
          if (
            modelName.toLowerCase().includes('tts') &&
            (actions.length === 0 || actions.includes('generateContent'))
          ) {
            ttsResponse = await tryCandidate('v1beta', modelName);
            if (ttsResponse) break;
          }
        }
      } catch (listErr) {
        lastError = listErr;
      }
    }
  }

  if (!ttsResponse) {
    if (sawQuotaLimit) {
      const trackedRetry = geminiCooldowns.getShortestRemainingSeconds(
        candidates.map((c) => `quota:${c.model}`)
      );
      const retrySec = trackedRetry ?? shortestRetryAfter;
      throw new TtsQuotaError(
        `Gemini TTS rate limit exceeded across available models; retry in ${retrySec}s`,
        retrySec
      );
    }
    throw lastError instanceof Error ? lastError : new Error('No compatible Gemini TTS model found');
  }

  let base64Audio: string | undefined;
  for (const part of ttsResponse.candidates?.[0]?.content?.parts ?? []) {
    if (part.inlineData?.data) {
      base64Audio = part.inlineData.data;
      break;
    }
  }

  if (!base64Audio) {
    throw new Error('Gemini TTS returned empty audio payload');
  }

  const rawBytes = new Uint8Array(Buffer.from(base64Audio, 'base64'));
  return wrapWavHeaderIfNeeded(rawBytes, 24000, 1, 16);
}

async function ensureSampleVideo(): Promise<string> {
  if (fs.existsSync(SAMPLE_VIDEO_PATH) && fs.statSync(SAMPLE_VIDEO_PATH).size > 10_000) {
    return SAMPLE_VIDEO_PATH;
  }

  const assetsDir = path.resolve(process.cwd(), 'src/assets/images');
  let imagePath = '';
  if (fs.existsSync(assetsDir)) {
    const files = fs.readdirSync(assetsDir).filter((f) => f.startsWith('cinema_noir_frame') && /\.(jpg|jpeg|png)$/i.test(f));
    if (files.length > 0) {
      imagePath = path.join(assetsDir, files[0]);
    }
  }

  if (imagePath) {
    await execFileAsync('ffmpeg', [
      '-y',
      '-loop',
      '1',
      '-i',
      imagePath,
      '-f',
      'lavfi',
      '-i',
      "aevalsrc='0.25*sin(2*PI*220*t)*(between(t,0.8,3.6)+between(t,5.2,8.2)+between(t,9.4,11.4))':s=48000:d=12",
      '-vf',
      'scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,zoompan=z=\'min(zoom+0.0008,1.12)\':d=300:s=1280x720:fps=25',
      '-t',
      '12',
      '-c:v',
      'libx264',
      '-preset',
      'veryfast',
      '-pix_fmt',
      'yuv420p',
      '-c:a',
      'aac',
      '-shortest',
      SAMPLE_VIDEO_PATH,
    ]);
  } else {
    await execFileAsync('ffmpeg', [
      '-y',
      '-f',
      'lavfi',
      '-i',
      'color=c=#0b1220:s=1280x720:d=12:r=25',
      '-f',
      'lavfi',
      '-i',
      "aevalsrc='0.25*sin(2*PI*220*t)*(between(t,0.8,3.6)+between(t,5.2,8.2)+between(t,9.4,11.4))':s=48000:d=12",
      '-c:v',
      'libx264',
      '-preset',
      'veryfast',
      '-pix_fmt',
      'yuv420p',
      '-c:a',
      'aac',
      '-shortest',
      SAMPLE_VIDEO_PATH,
    ]);
  }
  return SAMPLE_VIDEO_PATH;
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => {
      fs.mkdirSync(UPLOAD_TMP_DIR, { recursive: true });
      cb(null, UPLOAD_TMP_DIR);
    },
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || '').toLowerCase() || '.bin';
      cb(null, `${file.fieldname}_${Date.now()}_${crypto.randomBytes(4).toString('hex')}${ext}`);
    },
  }),
  limits: {
    fileSize: MAX_UPLOAD_FILE_BYTES, // Up to 2GB (and chunked uploads keep each HTTP request <= 4MB)
  },
});

async function startServer() {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: '50mb' }));

  // 1. Server health & capability check (never exposes secrets)
  app.get('/api/health', async (_req: Request, res: Response) => {
    const [ffmpegAvailable, ytDlpAvailable] = await Promise.all([
      checkBinary('ffmpeg'),
      checkBinary('yt-dlp'),
    ]);
    res.json({
      ok: true,
      ffmpegAvailable,
      ytDlpAvailable,
      geminiConfigured: Boolean(createGeminiClient()),
      groqConfigured: Boolean(getGroqApiKey()),
      telegramConfigured: Boolean(getTelegramBotToken()),
      edgeTtsAvailable: true,
      defaultTtsEngine: DEFAULT_TTS_ENGINE,
      defaultEdgeVoice: DEFAULT_EDGE_VOICE_ID,
    });
  });

  // 2. Serve ephemeral session media files (auto-deleted on session close)
  app.get('/api/session/:sessionId/file/:filename', (req: Request, res: Response) => {
    try {
      const sessionId = String(req.params.sessionId || '');
      const filename = path.basename(String(req.params.filename || ''));
      const dir = getSessionDir(sessionId);
      const filePath = path.join(dir, filename);
      if (!fs.existsSync(filePath)) {
        res.status(404).json({ errorMy: 'ဖိုင်မတွေ့ပါ' });
        return;
      }
      res.sendFile(filePath);
    } catch {
      res.status(400).json({ errorMy: 'တောင်းဆိုမှု မမှန်ကန်ပါ' });
    }
  });

  // 3. Load built-in sample movie clip into active ephemeral session
  app.post('/api/load-sample', async (req: Request, res: Response) => {
    try {
      const sessionId = String(req.body?.sessionId || crypto.randomUUID());
      const dir = getSessionDir(sessionId);
      const sampleSrc = await ensureSampleVideo();
      const targetPath = path.join(dir, 'source.mp4');
      fs.copyFileSync(sampleSrc, targetPath);
      fs.writeFileSync(path.join(dir, 'is_sample.flag'), '1', 'utf8');
      const meta = await probeVideo(targetPath);

      res.json({
        sessionId,
        videoUrl: `/api/session/${sessionId}/file/source.mp4`,
        durationSeconds: meta.duration,
        width: meta.width,
        height: meta.height,
        title: 'Midnight Overpass (နမူနာရုပ်ရှင်)',
      });
    } catch (error) {
      console.error('Sample load error:', error);
      res.status(500).json({ errorMy: 'နမူနာဗီဒီယို ဖန်တီးရာတွင် အမှားဖြစ်ပွားပါသည်' });
    }
  });

  // 4. Upload MP4 video file (single request for <= 4MB OR chunked upload for large videos up to 2GB / 120 mins)
  app.post('/api/upload-video', upload.single('video'), async (req: Request, res: Response) => {
    try {
      const sessionId = String(req.body?.sessionId || req.headers['x-session-id'] || crypto.randomUUID());
      if (!req.file) {
        res.status(400).json({ errorMy: 'MP4 ဗီဒီယိုဖိုင် ရွေးချယ်တင်သွင်းပေးပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      fs.rmSync(path.join(dir, 'is_sample.flag'), { force: true });
      const targetPath = path.join(dir, 'source.mp4');
      const meta = await finalizeUploadedSourceVideo(req.file.path, targetPath, req.file.originalname);

      const durationCheck = validateVideoDuration(meta.duration);
      if (!durationCheck.valid) {
        fs.rmSync(targetPath, { force: true });
        res.status(400).json({
          errorMy: durationCheck.errorMy || `ဗီဒီယိုအရှည်သည် ${MAX_VIDEO_DURATION_SECONDS / 60} မိနစ်ထက် မကျော်ရပါ`,
        });
        return;
      }

      res.json({
        sessionId,
        videoUrl: `/api/session/${sessionId}/file/source.mp4`,
        durationSeconds: meta.duration,
        width: meta.width,
        height: meta.height,
        title: req.file.originalname,
      });
    } catch (error) {
      if (req.file?.path) {
        fs.rmSync(req.file.path, { force: true });
      }
      console.error('Upload video error:', error);
      res.status(400).json({
        errorMy: 'ဗီဒီယိုဖိုင် ဖတ်ရှု၍မရပါ — ဖိုင်ပျက်နေခြင်း သို့မဟုတ် ဗီဒီယို Format မမှန်ကန်ခြင်း ဖြစ်နိုင်ပါသည်',
      });
    }
  });

  // 4b. Chunked MP4 Upload endpoints (bypasses Cloud Run 32MB request body cap reliably)
  app.post('/api/upload-video/chunk', upload.single('chunk'), (req: Request, res: Response) => {
    try {
      const sessionId = String(req.body?.sessionId || req.headers['x-session-id'] || '');
      const uploadId = String(req.body?.uploadId || '').replace(/[^a-zA-Z0-9_-]/g, '');
      const chunkIndex = Number(req.body?.chunkIndex);
      if (!sessionId || !uploadId || !Number.isInteger(chunkIndex) || chunkIndex < 0 || !req.file) {
        if (req.file?.path) fs.rmSync(req.file.path, { force: true });
        res.status(400).json({ errorMy: 'MP4 ဖိုင်အပိုင်း (Chunk) တင်သွင်းမှု မမှန်ကန်ပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      const chunksDir = path.join(dir, `chunks_${uploadId}`);
      fs.mkdirSync(chunksDir, { recursive: true });
      const chunkDest = path.join(chunksDir, `chunk_${String(chunkIndex).padStart(6, '0')}`);
      moveFileSafely(req.file.path, chunkDest);

      res.json({ ok: true, chunkIndex });
    } catch (error) {
      if (req.file?.path) fs.rmSync(req.file.path, { force: true });
      console.error('Chunk upload error:', error);
      res.status(500).json({ errorMy: 'ဗီဒီယိုဖိုင်အပိုင်း လက်ခံရာတွင် အမှားဖြစ်ပွားပါသည်' });
    }
  });

  app.post('/api/upload-video/complete', async (req: Request, res: Response) => {
    let rawMergedPath = '';
    let chunksDir = '';
    try {
      const sessionId = String(req.body?.sessionId || req.headers['x-session-id'] || '');
      const uploadId = String(req.body?.uploadId || '').replace(/[^a-zA-Z0-9_-]/g, '');
      const totalChunks = Number(req.body?.totalChunks || 0);
      const filename = String(req.body?.filename || 'uploaded.mp4');

      if (!sessionId || !uploadId || !Number.isInteger(totalChunks) || totalChunks < 1) {
        res.status(400).json({ errorMy: 'MP4 ဖိုင်ပေါင်းစည်းရန် အချက်အလက် မပြည့်စုံပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      chunksDir = path.join(dir, `chunks_${uploadId}`);
      for (let i = 0; i < totalChunks; i++) {
        const partPath = path.join(chunksDir, `chunk_${String(i).padStart(6, '0')}`);
        if (!fs.existsSync(partPath)) {
          res.status(400).json({ errorMy: `MP4 ဖိုင်အပိုင်း (${i + 1}/${totalChunks}) မပြည့်စုံပါ — ပြန်လည်တင်သွင်းပါ` });
          return;
        }
      }

      const ext = path.extname(filename).toLowerCase() || '.mp4';
      rawMergedPath = path.join(dir, `raw_upload_${uploadId}${ext}`);
      const writeStream = fs.createWriteStream(rawMergedPath);
      for (let i = 0; i < totalChunks; i++) {
        const partPath = path.join(chunksDir, `chunk_${String(i).padStart(6, '0')}`);
        const buf = fs.readFileSync(partPath);
        if (!writeStream.write(buf)) {
          await new Promise<void>((resolve) => writeStream.once('drain', resolve));
        }
      }
      await new Promise<void>((resolve, reject) => {
        writeStream.on('finish', resolve);
        writeStream.on('error', reject);
        writeStream.end();
      });
      fs.rmSync(chunksDir, { recursive: true, force: true });

      fs.rmSync(path.join(dir, 'is_sample.flag'), { force: true });
      const targetPath = path.join(dir, 'source.mp4');
      const meta = await finalizeUploadedSourceVideo(rawMergedPath, targetPath, filename);

      const durationCheck = validateVideoDuration(meta.duration);
      if (!durationCheck.valid) {
        fs.rmSync(targetPath, { force: true });
        res.status(400).json({
          errorMy: durationCheck.errorMy || `ဗီဒီယိုအရှည်သည် ${MAX_VIDEO_DURATION_SECONDS / 60} မိနစ်ထက် မကျော်ရပါ`,
        });
        return;
      }

      res.json({
        sessionId,
        videoUrl: `/api/session/${sessionId}/file/source.mp4`,
        durationSeconds: meta.duration,
        width: meta.width,
        height: meta.height,
        title: filename,
      });
    } catch (error) {
      if (chunksDir) fs.rmSync(chunksDir, { recursive: true, force: true });
      if (rawMergedPath) fs.rmSync(rawMergedPath, { force: true });
      console.error('Complete chunked upload error:', error);
      res.status(400).json({
        errorMy: 'MP4 ဗီဒီယိုဖိုင် ဖတ်ရှု၍မရပါ — ဖိုင်ပျက်နေခြင်း သို့မဟုတ် ဗီဒီယို Format မမှန်ကန်ခြင်း ဖြစ်နိုင်ပါသည်',
      });
    }
  });

  // 5. Resolve public YouTube, TikTok, Facebook, Instagram link (via yt-dlp if available)
  app.post('/api/resolve-link', async (req: Request, res: Response) => {
    try {
      const url = String(req.body?.url || '').trim();
      const sessionId = String(req.body?.sessionId || crypto.randomUUID());
      const validation = validateVideoUrl(url);
      if (!validation.valid) {
        res.status(400).json({ errorMy: validation.errorMy });
        return;
      }

      const hasYtDlp = await checkBinary('yt-dlp');
      if (!hasYtDlp) {
        res.status(422).json({
          errorMy: `${validation.platform} လင့်ခ်ကို မှန်ကန်ကြောင်း စစ်ဆေးပြီးပါပြီ။ သို့သော် ဤ Server တွင် yt-dlp မပါဝင်သေးသဖြင့် MP4 ဖိုင်ကို တိုက်ရိုက်တင်သွင်းခြင်း သို့မဟုတ် Render Dockerfile ဖြင့် Deploy လုပ်၍ အသုံးပြုပါ။`,
          platform: validation.platform,
        });
        return;
      }

      const dir = getSessionDir(sessionId);
      fs.rmSync(path.join(dir, 'is_sample.flag'), { force: true });
      const targetPath = path.join(dir, 'source.mp4');

      // Check duration before downloading
      const { stdout: durOut } = await execFileAsync('yt-dlp', [
        '--no-playlist',
        '--print',
        'duration',
        '--print',
        'title',
        url,
      ]);
      const lines = durOut.trim().split('\n');
      const durationSeconds = Number(lines[0] || 0);
      const videoTitle = lines[1] || `${validation.platform} Video`;
      if (durationSeconds > 0) {
        const check = validateVideoDuration(durationSeconds);
        if (!check.valid) {
          res.status(400).json({ errorMy: check.errorMy });
          return;
        }
      }

      await execFileAsync('yt-dlp', [
        '--no-playlist',
        '-f',
        'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        '--merge-output-format',
        'mp4',
        '-o',
        targetPath,
        url,
      ]);

      const meta = await probeVideo(targetPath);
      const durCheck = validateVideoDuration(meta.duration);
      if (!durCheck.valid) {
        fs.rmSync(targetPath, { force: true });
        res.status(400).json({ errorMy: durCheck.errorMy });
        return;
      }

      res.json({
        sessionId,
        videoUrl: `/api/session/${sessionId}/file/source.mp4`,
        durationSeconds: meta.duration,
        width: meta.width,
        height: meta.height,
        title: videoTitle,
        platform: validation.platform,
      });
    } catch (error) {
      console.error('Resolve link error:', error);
      res.status(500).json({ errorMy: 'အများသုံးဗီဒီယိုလင့်ခ်မှ ဗီဒီယိုရယူရာတွင် မအောင်မြင်ပါ — MP4 ဖိုင်တင်သွင်းစမ်းကြည့်ပါ' });
    }
  });

  // 6. Step 2: Groq Whisper API transcript extraction -> speaking & silence timeline segments
  app.post('/api/transcribe', async (req: Request, res: Response) => {
    try {
      const sessionId = String(req.body?.sessionId || '');
      if (!sessionId) {
        res.status(400).json({ errorMy: 'Session မတွေ့ပါ — ဗီဒီယိုကို ပြန်လည်ထည့်သွင်းပါ' });
        return;
      }

      const groqKey = getGroqApiKey();
      const hasGeminiFallback = Boolean(createGeminiClient('v1beta') || createGeminiClient('v1'));
      if (!groqKey && !hasGeminiFallback) {
        res.status(400).json({
          missingKey: 'GROQ_API_KEY',
          errorMy: 'GROQ_API_KEY သို့မဟုတ် GEMINI_API_KEY မသတ်မှတ်ရသေးပါ — Server Environment Variable တွင် ထည့်သွင်းပါ',
        });
        return;
      }

      const dir = getSessionDir(sessionId);
      const sourcePath = path.join(dir, 'source.mp4');
      if (!fs.existsSync(sourcePath)) {
        res.status(404).json({ errorMy: 'အရင်းအမြစ် ဗီဒီယိုဖိုင် မတွေ့ပါ' });
        return;
      }

      const meta = await probeVideo(sourcePath);
      const isSampleSession = fs.existsSync(path.join(dir, 'is_sample.flag'));

      if (!meta.hasAudio) {
        const timelineSegments = isSampleSession
          ? buildTimelineFromGroq(
              [
                { start: 0.8, end: 3.6, text: 'Detective waits alone on the dark rainy bridge.' },
                { start: 5.2, end: 8.2, text: 'Someone silently watches from the shadows.' },
                { start: 9.4, end: 11.4, text: 'The hidden truth flips the entire case.' },
              ],
              [],
              meta.duration
            )
          : buildTimelineFromGroq([], [], meta.duration);

        const speakingSegments = timelineSegments.filter((s) => s.kind === 'speaking');
        fs.writeFileSync(path.join(dir, 'timeline_groq.json'), JSON.stringify(timelineSegments), 'utf8');
        res.json({
          transcript: speakingSegments.map((s) => s.text).join(' ') || '',
          segments: speakingSegments,
          timelineSegments,
          durationSeconds: meta.duration,
        });
        return;
      }

      const audioExtractPath = path.join(dir, 'extracted_audio.mp3');
      await execFileAsync('ffmpeg', [
        '-y',
        '-i',
        sourcePath,
        '-vn',
        '-ac',
        '1',
        '-ar',
        '16000',
        '-b:a',
        '24k',
        audioExtractPath,
      ]);

      const MAX_GROQ_BYTES = 24 * 1024 * 1024;
      const transcribeChunkBuffer = async (buf: Buffer, filename: string, chunkDurSec: number) => {
        let groqErrStatus = 0;

        if (groqKey && !groqInvalidKeys.has(groqKey)) {
          try {
            const groqRes = await withTransientRetry(() => {
              const formData = new FormData();
              formData.append('file', new Blob([new Uint8Array(buf)], { type: 'audio/mpeg' }), filename);
              formData.append('model', 'whisper-large-v3-turbo');
              formData.append('response_format', 'verbose_json');
              formData.append('timestamp_granularities[]', 'segment');
              formData.append('timestamp_granularities[]', 'word');
              return fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
                method: 'POST',
                headers: {
                  Authorization: `Bearer ${groqKey}`,
                },
                body: formData,
              });
            });

            if (groqRes.ok) {
              return (await groqRes.json()) as {
                text?: string;
                segments?: GroqSegmentTimestamp[];
                words?: GroqWordTimestamp[];
              };
            }

            groqErrStatus = groqRes.status;
            const errBody = await groqRes.text();
            if (groqRes.status === 401 || groqRes.status === 403) {
              groqInvalidKeys.add(groqKey);
              console.warn('[Transcribe] Groq Whisper key unauthorized (401/403); switching to Gemini audio fallback.');
            } else {
              console.warn(`[Transcribe] Groq Whisper HTTP ${groqRes.status}; falling back to Gemini:`, errBody.slice(0, 160));
            }
          } catch (groqNetErr) {
            console.warn('[Transcribe] Groq Whisper request failed; falling back to Gemini:', groqNetErr instanceof Error ? groqNetErr.message : groqNetErr);
          }
        }

        // Fallback cleanly to Gemini audio transcription when Groq Whisper is unavailable, rate-limited, or has invalid API key
        if (hasGeminiFallback && buf.byteLength <= 18 * 1024 * 1024) {
          try {
            return await transcribeAudioBufferWithGemini(buf, chunkDurSec);
          } catch (gemErr) {
            if (isSampleSession) {
              return { text: '', segments: [], words: [] };
            }
            console.warn('[Transcribe] Gemini audio fallback failed:', gemErr instanceof Error ? gemErr.message : gemErr);
          }
        }

        if (isSampleSession) {
          return { text: '', segments: [], words: [] };
        }
        throw new Error(`GROQ_${groqErrStatus || 502}`);
      };

      const extractedStat = fs.statSync(audioExtractPath);
      let combinedText = '';
      let allSegments: GroqSegmentTimestamp[] = [];
      let allWords: GroqWordTimestamp[] = [];

      if (extractedStat.size <= MAX_GROQ_BYTES) {
        try {
          const data = await transcribeChunkBuffer(fs.readFileSync(audioExtractPath), 'audio.mp3', meta.duration);
          combinedText = data.text || '';
          allSegments = data.segments || [];
          allWords = data.words || [];
        } catch (err) {
          const status = Number(String(err instanceof Error ? err.message : '').replace('GROQ_', '')) || 500;
          res.status(status).json({
            errorMy:
              status === 401 || status === 403
                ? 'GROQ_API_KEY မှားယွင်းနေပါသည် (401 Invalid API Key) — Server Environment Secrets တွင် GROQ_API_KEY ကို ပြန်လည်စစ်ဆေးပါ'
                : `Groq API မှ အသံစာသားထုတ်ယူရာတွင် အမှားဖြစ်ပွားပါသည် (${status})`,
          });
          return;
        }
      } else {
        // Long-video chunked transcription: read every second from 0s to end without skipping
        const chunkPattern = path.join(dir, 'audio_chunk_%03d.mp3');
        await execFileAsync('ffmpeg', [
          '-y',
          '-i',
          audioExtractPath,
          '-f',
          'segment',
          '-segment_time',
          '1500',
          '-c',
          'copy',
          chunkPattern,
        ]);
        const chunkFiles = fs
          .readdirSync(dir)
          .filter((f) => f.startsWith('audio_chunk_') && f.endsWith('.mp3'))
          .sort();
        let offsetSec = 0;
        const textParts: string[] = [];
        for (const chunkFile of chunkFiles) {
          const chunkPath = path.join(dir, chunkFile);
          const chunkDur = await probeAudioDuration(chunkPath);
          try {
            const chunkData = await transcribeChunkBuffer(fs.readFileSync(chunkPath), chunkFile, chunkDur);
            if (chunkData.text) textParts.push(chunkData.text.trim());
            for (const s of chunkData.segments || []) {
              allSegments.push({ ...s, start: s.start + offsetSec, end: s.end + offsetSec });
            }
            for (const w of chunkData.words || []) {
              allWords.push({ ...w, start: w.start + offsetSec, end: w.end + offsetSec });
            }
          } catch (err) {
            const status = Number(String(err instanceof Error ? err.message : '').replace('GROQ_', '')) || 500;
            res.status(status).json({
              errorMy:
                status === 401 || status === 403
                  ? 'GROQ_API_KEY မှားယွင်းနေပါသည် (401 Invalid API Key) — Server Environment Secrets တွင် GROQ_API_KEY ကို ပြန်လည်စစ်ဆေးပါ'
                  : `Groq API မှ အသံစာသားထုတ်ယူရာတွင် အမှားဖြစ်ပွားပါသည် (${status})`,
            });
            return;
          }
          offsetSec += chunkDur;
        }
        combinedText = textParts.join(' ').trim();
      }

      const data = { text: combinedText, segments: allSegments, words: allWords };

      let timelineSegments = buildTimelineFromGroq(
        data.segments || [],
        data.words || [],
        meta.duration,
        { maxSpeakingSegments: 120 }
      );

      // Only if this is the synthetic sine-tone sample clip and Groq hears zero/negligible words (<1.5s), provide alternating demo speaking + silence slices
      const detectedSpeechDur = timelineSegments
        .filter((s) => s.kind === 'speaking')
        .reduce((acc, s) => acc + s.duration, 0);
      if (isSampleSession && detectedSpeechDur < 1.5) {
        const dur = Math.max(4, meta.duration);
        timelineSegments = buildTimelineFromGroq(
          [
            { start: Math.min(0.8, dur * 0.08), end: Math.min(3.6, dur * 0.31), text: 'Detective waits alone on the dark rainy bridge.' },
            { start: Math.min(5.2, dur * 0.43), end: Math.min(8.2, dur * 0.68), text: 'Someone silently watches from the shadows.' },
            { start: Math.min(9.4, dur * 0.78), end: Math.min(11.4, dur * 0.94), text: 'The hidden truth flips the entire case.' },
          ],
          [],
          dur
        );
      }

      const speakingSegments = timelineSegments.filter((s) => s.kind === 'speaking');
      fs.writeFileSync(path.join(dir, 'timeline_groq.json'), JSON.stringify(timelineSegments), 'utf8');

      res.json({
        transcript: data.text || speakingSegments.map((s) => s.text).join(' '),
        segments: speakingSegments,
        timelineSegments,
        durationSeconds: meta.duration,
      });
    } catch (error) {
      console.error('Transcribe error:', error);
      res.status(500).json({ errorMy: 'အသံဖိုင်မှ စာသားထုတ်ယူခြင်း မအောင်မြင်ပါ' });
    }
  });

  // 7. Step 3, 5, 8: Gemini API Myanmar script ONLY for speaking segments (silence segments remain empty)
  app.post('/api/generate-script', async (req: Request, res: Response) => {
    try {
      const ai = createGeminiClient();
      if (!ai) {
        res.status(400).json({
          missingKey: 'GEMINI_API_KEY',
          errorMy: 'GEMINI_API_KEY မသတ်မှတ်ရသေးပါ — Server Environment Variable တွင် GEMINI_API_KEY ထည့်သွင်းပါ',
        });
        return;
      }

      const transcript = String(req.body?.transcript || '').trim();
      const tool = (req.body?.tool || 'recap') as StudioTool;
      const voiceStyle = normalizeMyanmarVoiceId(req.body?.voiceStyle);
      const voiceMeta = getGeminiFreeVoice(voiceStyle);
      const rawSpeedInput = req.body?.voiceSpeed ?? req.body?.speed ?? 1.0;
      const voiceSpeed: VoiceSpeed = parseVoiceSpeedInput(rawSpeedInput);
      const durationSeconds = Math.max(1, Number(req.body?.durationSeconds || 12));
      const videoWidth = Math.max(160, Number(req.body?.videoWidth || 1280));
      const videoHeight = Math.max(160, Number(req.body?.videoHeight || 720));
      const incomingTimeline = Array.isArray(req.body?.timelineSegments)
        ? (req.body.timelineSegments as VideoTimelineSegment[])
        : null;
      const rawSegments = Array.isArray(req.body?.segments)
        ? (req.body.segments as Array<{ start: number; end: number; text: string }>)
        : [{ start: 0, end: durationSeconds, text: transcript }];

      const baseTimeline: VideoTimelineSegment[] =
        incomingTimeline && incomingTimeline.length > 0
          ? incomingTimeline
          : buildTimelineFromGroq(rawSegments, [], durationSeconds);

      const speakingSegments = baseTimeline.filter(
        (s) => s.kind === 'speaking' && String(s.text || '').trim().length > 0
      );

      // Prepare separate prompt & target items depending on which of the 3 tools is active
      let targetItems: Array<{ id: string; start: number; end: number; maxWords: number; text: string }> = [];
      let systemInstruction = '';
      let prompt = '';
      let recapContext: {
        beats: ReturnType<typeof buildFullRecapBeats>;
        timestampedSegments: TimestampedTranscriptItem[];
        scenes: SceneSummary[];
        storyAnalysisMy: string;
        transcript: string;
        verifiedCharacters: VerifiedCharacterProfile[];
      } | null = null;

      if (tool === 'recap') {
        // TOOL 1: MOVIE RECAP — MIXED (Professional Narration + Important Character Dialogues) & 90% duration target
        const sessionIdForContext = String(req.body?.sessionId || '').trim();
        let recapTimestampedSegments: TimestampedTranscriptItem[] = Array.isArray(req.body?.segments)
          ? (req.body.segments as Array<{ start: number; end: number; text: string }>)
              .filter((s) => String(s?.text || '').trim().length > 0)
              .map((s) => ({
                start: Math.max(0, Number(s.start || 0)),
                end: Math.min(durationSeconds, Math.max(0, Number(s.end || durationSeconds))),
                text: String(s.text || '').trim(),
              }))
          : [];
        let resolvedTranscript = transcript;

        if (sessionIdForContext && !hasSubstantiveTranscript(resolvedTranscript, recapTimestampedSegments)) {
          try {
            const cachedTimelinePath = path.join(getSessionDir(sessionIdForContext), 'timeline_groq.json');
            if (fs.existsSync(cachedTimelinePath)) {
              const cachedTl = JSON.parse(fs.readFileSync(cachedTimelinePath, 'utf8')) as VideoTimelineSegment[];
              const cachedSpeaking = cachedTl
                .filter((s) => s.kind === 'speaking' && String(s.text || '').trim().length > 0)
                .map((s) => ({
                  start: Math.max(0, Number(s.start || 0)),
                  end: Math.min(durationSeconds, Math.max(0, Number(s.end || durationSeconds))),
                  text: String(s.text).trim(),
                }));
              if (cachedSpeaking.length > 0) {
                recapTimestampedSegments = cachedSpeaking;
                if (!resolvedTranscript) {
                  resolvedTranscript = cachedSpeaking.map((s) => s.text).join(' ').trim();
                }
              }
            }
          } catch {
            // Ignore unreadable optional cached transcript timeline
          }
        }

        const beatsInputSegments =
          recapTimestampedSegments.length > 0
            ? recapTimestampedSegments
            : resolvedTranscript
              ? [{ start: 0, end: durationSeconds, text: resolvedTranscript }]
              : rawSegments;

        const beats = buildFullRecapBeats(beatsInputSegments, durationSeconds, voiceSpeed);
        targetItems = beats.map((b) => ({
          id: b.id,
          start: b.start,
          end: b.end,
          maxWords: b.maxMyanmarWords,
          text: b.contextText,
        }));

        let recapScenes: SceneSummary[] = Array.isArray(req.body?.scenes)
          ? (req.body.scenes as SceneSummary[])
          : [];
        let recapStoryAnalysisMy = String(req.body?.storyAnalysisMy || '').trim();

        if (sessionIdForContext && (recapScenes.length === 0 || !recapStoryAnalysisMy)) {
          try {
            const statePath = path.join(getSessionDir(sessionIdForContext), 'scene_analysis_state.json');
            if (fs.existsSync(statePath)) {
              const savedState = JSON.parse(fs.readFileSync(statePath, 'utf8')) as Partial<SceneAnalysisCheckpoint>;
              if (recapScenes.length === 0 && Array.isArray(savedState.completedScenes)) {
                recapScenes = savedState.completedScenes;
              }
              if (!recapStoryAnalysisMy && typeof savedState.storyAnalysisMy === 'string') {
                recapStoryAnalysisMy = savedState.storyAnalysisMy;
              }
            }
          } catch {
            // Ignore unreadable optional scene state cache
          }
        }

        const verifiedCharacters = extractVerifiedCharacterClues({
          transcript: resolvedTranscript,
          timestampedSegments: recapTimestampedSegments,
          scenes: recapScenes,
          storyAnalysisMy: recapStoryAnalysisMy,
          videoTitle: String(req.body?.videoTitle || '').trim(),
          explicitCharacters: Array.isArray(req.body?.characters) ? req.body.characters : [],
        });

        const numericRecapSpeed = getVoiceSpeedFactor(voiceSpeed);
        const recapSpeedNote =
          voiceSpeed === 'slow' || numericRecapSpeed < 0.95
            ? 'USER SELECTED SLOW VOICE SPEED: Write vivid, atmospheric, unhurried storytelling + natural character dialogue lines around TARGET_WORDS per beat.'
            : numericRecapSpeed >= 1.15
              ? `USER SELECTED ${numericRecapSpeed.toFixed(1)}X VOICE SPEED: Write clean, direct, punchy storytelling + natural character dialogue sentences around TARGET_WORDS per beat with zero filler so ${numericRecapSpeed.toFixed(1)}x speed stays crisp and synced.`
              : 'Write engaging, natural-paced Myanmar movie recap narration blending storytelling and meaningful character dialogue around TARGET_WORDS per beat.';

        const beatListText = targetItems
          .map(
            (b) =>
              `- Beat id="${b.id}" [${b.start.toFixed(2)}s -> ${b.end.toFixed(2)}s, TARGET_WORDS=${b.maxWords}]: "${b.text}"`
          )
          .join('\n');

        const recapPromptBundle = buildRecapMixedNarrationPrompt({
          durationSeconds,
          transcript: resolvedTranscript,
          timestampedSegments: recapTimestampedSegments,
          voiceStyleName: voiceMeta.nameMy,
          voiceStyleTag: voiceMeta.tagMy,
          voiceStyleDesc: voiceMeta.descMy,
          speedNote: recapSpeedNote,
          beatListText,
          beatCount: targetItems.length,
          scenes: recapScenes,
          storyAnalysisMy: recapStoryAnalysisMy,
          verifiedCharacters,
        });

        systemInstruction = recapPromptBundle.systemInstruction;
        prompt = recapPromptBundle.prompt;
        recapContext = {
          beats,
          timestampedSegments: recapTimestampedSegments,
          scenes: recapScenes,
          storyAnalysisMy: recapStoryAnalysisMy,
          transcript: resolvedTranscript,
          verifiedCharacters,
        };
      } else if (tool === 'captions') {
        // TOOL 3: CAPTIONS ONLY — Keep original audio; translate/adapt ONLY speaking segments at original timestamps
        if (speakingSegments.length === 0) {
          res.json({
            scriptMy: '',
            thumbnailTitleMy: 'မူရင်းအသံ စာတန်းထိုး',
            captions: [],
            timelineSegments: [],
          });
          return;
        }
        const normalized = normalizeTranscriptSegments(
          speakingSegments.map((s) => ({ start: s.start, end: s.end, text: s.text })),
          durationSeconds
        );
        targetItems = speakingSegments.map((s, idx) => ({
          id: s.id,
          start: s.start,
          end: s.end,
          maxWords: normalized[idx]?.maxMyanmarWords ?? Math.max(3, Math.round(s.duration * 2.4)),
          text: s.text,
        }));

        const capSpecText = targetItems
          .map(
            (s) =>
              `- Caption id="${s.id}" [${s.start.toFixed(2)}s -> ${s.end.toFixed(2)}s, MAX_WORDS=${s.maxWords}]: "${s.text}"`
          )
          .join('\n');

        systemInstruction =
          'You are a Myanmar dynamic subtitle translator for social video. Keep meaning faithful to the original spoken audio and keep subtitles crisp, punchy, and readable within original timestamps. Never exceed 24 characters for thumbnailTitleMy.';

        prompt = `Translate/adapt ONLY these original spoken lines into concise, punchy Myanmar dynamic subtitles (NO extra narration, keep original video audio pacing).

Spoken Segments:
${capSpecText}

Requirements:
1. "segments": Array with EXACTLY ${targetItems.length} items matching each input id in order. Each item MUST have: id (string matching input id), myanmarText (concise Myanmar subtitle), emoji (1 matching emoji like 💬, 🎬, ⚡).
2. "thumbnailTitleMy": A viral Myanmar thumbnail title STRICTLY under 25 characters (maximum 24 characters).`;
      } else {
        // TOOL 2: MYANMAR DUBBING — Full-video synchronized one-voice Myanmar dubbing preserving 100% original video duration & 1.0x speed
        if (speakingSegments.length === 0) {
          const silentOnly = applyMyanmarScriptToTimeline(baseTimeline, []);
          res.json({
            scriptMy: '',
            thumbnailTitleMy: 'အသံတိတ်မြင်ကွင်း',
            captions: [],
            timelineSegments: silentOnly,
          });
          return;
        }

        const normalizedSpeaking = normalizeTranscriptSegments(
          speakingSegments.map((s) => ({ start: s.start, end: s.end, text: s.text })),
          durationSeconds
        );

        targetItems = speakingSegments.map((s, idx) => {
          const baseWords = normalizedSpeaking[idx]?.maxMyanmarWords ?? Math.max(3, Math.round(s.duration * 2.5));
          return {
            id: s.id,
            start: s.start,
            end: s.end,
            maxWords: Math.max(2, baseWords),
            text: s.text,
          };
        });

        const segmentSpecText = targetItems
          .map(
            (s) =>
              `- Segment id="${s.id}" [${s.start.toFixed(2)}s -> ${s.end.toFixed(2)}s, window=${(s.end - s.start).toFixed(2)}s, TARGET_WORDS=${s.maxWords}]: "${s.text}"`
          )
          .join('\n');

        systemInstruction =
          'You are a professional Myanmar dubbing script writer. Read the entire uploaded video from beginning to end completely without skipping any part. Capture every spoken sentence, every dialogue, and all important narration in natural Burmese suitable for one-voice narration. Match the total script length and each segment word count to the exact original video duration so the video never speeds up, cuts short, or finishes early. Never exceed 24 characters for thumbnailTitleMy.';

        prompt = `You are a professional Myanmar dubbing script writer.

## Rules
1. Read the entire uploaded video from the very beginning (0.00s) to the end (${durationSeconds.toFixed(2)}s) completely. Do NOT skip any part of the video.
2. Capture every spoken sentence, every dialogue, and all important narration from the original video.
3. The total length of your generated Myanmar dubbing script MUST match the original video duration (${durationSeconds.toFixed(2)} seconds). Keep each segment close to TARGET_WORDS so one-voice narration fits the window naturally.
4. Do NOT make the final video speed up, cut short, or finish earlier than the original video.
5. Maintain correct timing for every segment below so audio and video remain 100% synchronized.
6. Write clean, natural spoken Burmese suitable for cohesive one-voice narration ONLY (no speaker labels, no stage directions, no brackets).

${transcript ? `Full Original Video Transcript Context (0.00s -> ${durationSeconds.toFixed(2)}s):\n"${transcript}"\n` : ''}
Speaking Segments Covering Entire Video (${targetItems.length} segments):
${segmentSpecText}

Requirements:
1. "segments": Array with EXACTLY ${targetItems.length} items matching each input speaking segment id in order. Each item MUST have: id (string matching input id), myanmarText (natural one-voice Myanmar dubbing line matching TARGET_WORDS), emoji (1 matching emoji like 🔥, 😱, 🎬, 💬).
2. "thumbnailTitleMy": A viral Myanmar thumbnail title STRICTLY under 25 characters (maximum 24 characters).`;
      }

      const aiBeta = createGeminiClient('v1beta') || ai;
      const scriptCandidates: Array<{ client: GoogleGenAI; apiVersion: 'v1' | 'v1beta'; model: string }> = [
        { client: ai, apiVersion: 'v1', model: 'gemini-4-hydrogen' },
        { client: aiBeta, apiVersion: 'v1beta', model: 'gemini-4-hydrogen' },
        { client: aiBeta, apiVersion: 'v1beta', model: 'gemini-3.1-flash-lite' },
        { client: ai, apiVersion: 'v1', model: 'gemini-3.1-flash-lite' },
      ];

      const scriptConfig = {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            thumbnailTitleMy: { type: Type.STRING },
            segments: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  myanmarText: { type: Type.STRING },
                  emoji: { type: Type.STRING },
                },
                required: ['id', 'myanmarText', 'emoji'],
              },
            },
          },
          required: ['thumbnailTitleMy', 'segments'],
        },
      };

      const runScriptGeneration = async (
        callSystemInstruction: string,
        callPrompt: string,
        callResponseSchema: {
          type: Type;
          properties: Record<string, unknown>;
          required: string[];
        }
      ) => {
        let callResponse: Awaited<ReturnType<GoogleGenAI['models']['generateContent']>> | null = null;
        let lastErr: unknown = null;
        let sawQuota = false;

        for (const sc of scriptCandidates) {
          const quotaKey = `quota:${sc.model}`;
          const notFoundKey = `notfound:${sc.apiVersion}:${sc.model}`;
          if (geminiCooldowns.isCoolingDown(notFoundKey)) continue;
          if (geminiCooldowns.isCoolingDown(quotaKey)) {
            sawQuota = true;
            continue;
          }

          try {
            callResponse = await withTransientRetry(
              () =>
                sc.client.models.generateContent({
                  model: sc.model,
                  contents: callPrompt,
                  config: {
                    systemInstruction: callSystemInstruction,
                    responseMimeType: 'application/json',
                    responseSchema: callResponseSchema,
                  },
                }),
              2,
              600
            );
            if (callResponse?.text) break;
          } catch (err) {
            lastErr = err;
            if (isQuotaRateLimitError(err)) {
              sawQuota = true;
              const retrySec = extractRetryAfterSeconds(err) || 35;
              geminiCooldowns.markCoolingDown(quotaKey, retrySec);
              continue;
            }
            if (isModelNotFoundError(err)) {
              geminiCooldowns.markCoolingDown(notFoundKey, 6 * 3600);
              continue;
            }
            if (isTransientNetworkError(err)) {
              continue; // Fail over immediately to next script candidate model/version
            }
            throw err;
          }
        }

        return { response: callResponse, lastErr, sawQuota };
      };

      const initialResult = await runScriptGeneration(systemInstruction, prompt, scriptConfig.responseSchema);

      if (!initialResult.response) {
        if (initialResult.sawQuota) {
          const retrySec =
            geminiCooldowns.getShortestRemainingSeconds([
              'quota:gemini-4-hydrogen',
              'quota:gemini-3.1-flash-lite',
            ]) || 35;
          res.status(429).json({
            retryAfterSeconds: retrySec,
            errorMy: `Gemini AI အသုံးပြုမှု ခေတ္တပြည့်သွားပါသည် — ${retrySec} စက္ကန့်ခန့်စောင့်ပြီး ထပ်မံနှိပ်ပေးပါ`,
          });
          return;
        }
        throw initialResult.lastErr instanceof Error
          ? initialResult.lastErr
          : new Error('No script model available');
      }

      const parsed = JSON.parse((initialResult.response.text || '{}').trim()) as {
        thumbnailTitleMy?: string;
        segments?: Array<{ id?: string; myanmarText: string; emoji: string }>;
      };

      if (tool === 'dubbing') {
        const scriptedTimeline = applyMyanmarScriptToTimeline(
          baseTimeline,
          speakingSegments.map((orig, idx) => ({
            id: parsed.segments?.[idx]?.id || orig.id,
            myanmarText: String(parsed.segments?.[idx]?.myanmarText || orig.text).trim(),
            emoji: String(parsed.segments?.[idx]?.emoji || '🎬').trim(),
          }))
        );

        const rawLockedCaptions: CaptionSegment[] = scriptedTimeline
          .filter((s) => s.kind === 'speaking' && s.myanmarText.trim().length > 0)
          .map((s) => ({
            id: `cap_${s.id}`,
            start: s.start,
            end: s.end,
            text: s.myanmarText,
            emoji: s.emoji || '🎬',
          }));
        const lockedCaptions = splitLongCaptionsToMaxTwoLines(rawLockedCaptions, {
          videoWidth,
          videoHeight,
        });

        res.json({
          scriptMy: lockedCaptions.map((c) => c.text.replace(/\n+/g, ' ')).join(' '),
          thumbnailTitleMy: truncateThumbnailTitle(String(parsed.thumbnailTitleMy || 'မထင်မှတ်ထားတဲ့အလှည့်')),
          captions: lockedCaptions,
          timelineSegments: scriptedTimeline,
        });
        return;
      }

      if (tool === 'recap' && recapContext) {
        // Phase 2 & 3 (MOVIE RECAP ONLY): Duration coverage check -> conditional targeted auto-expansion -> quality validation
        const initialValidation = validateAndRefineRecapSegments({
          beats: recapContext.beats,
          rawSegments: Array.isArray(parsed.segments) ? parsed.segments : [],
          videoDurationSeconds: durationSeconds,
          voiceSpeed,
        });

        let finalRecapSegments = initialValidation.segments;
        const expansionCheck = selectRecapBeatsForAutoExpansion({
          beats: recapContext.beats,
          segments: finalRecapSegments,
          videoDurationSeconds: durationSeconds,
          voiceSpeed,
          timestampedSegments: recapContext.timestampedSegments,
          scenes: recapContext.scenes,
          transcript: recapContext.transcript,
          storyAnalysisMy: recapContext.storyAnalysisMy,
        });

        if (expansionCheck.shouldExpand && expansionCheck.candidates.length > 0) {
          try {
            const expandBundle = buildRecapAutoExpansionPrompt({
              durationSeconds,
              targetDurationSeconds: expansionCheck.estimate.targetDurationSeconds,
              currentEstimatedSeconds: expansionCheck.estimate.estimatedDurationSeconds,
              candidates: expansionCheck.candidates,
              storyAnalysisMy: recapContext.storyAnalysisMy,
              verifiedCharacters: recapContext.verifiedCharacters,
            });
            const expandSchema = {
              type: Type.OBJECT,
              properties: {
                segments: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      myanmarText: { type: Type.STRING },
                      emoji: { type: Type.STRING },
                    },
                    required: ['id', 'myanmarText', 'emoji'],
                  },
                },
              },
              required: ['segments'],
            };
            const expandResult = await runScriptGeneration(
              expandBundle.systemInstruction,
              expandBundle.prompt,
              expandSchema
            );
            if (expandResult.response?.text) {
              const expandedJson = JSON.parse(expandResult.response.text.trim()) as {
                segments?: Array<{ id?: string; myanmarText?: string; emoji?: string }>;
              };
              const expandedById = new Map(
                (expandedJson.segments || [])
                  .filter((s) => s?.id && String(s.myanmarText || '').trim().length > 0)
                  .map((s) => [String(s.id), s])
              );
              if (expandedById.size > 0) {
                const candidateMerged = finalRecapSegments.map((seg) => {
                  const exp = expandedById.get(seg.id);
                  if (!exp || !String(exp.myanmarText || '').trim()) return seg;
                  return {
                    id: seg.id,
                    myanmarText: String(exp.myanmarText).trim(),
                    emoji: String(exp.emoji || seg.emoji || '🎬').trim() || '🎬',
                  };
                });
                const postExpansionValidation = validateAndRefineRecapSegments({
                  beats: recapContext.beats,
                  rawSegments: candidateMerged,
                  videoDurationSeconds: durationSeconds,
                  voiceSpeed,
                });
                // Accept expanded segments when they genuinely move closer toward the 90% target without extreme overshoot
                if (
                  postExpansionValidation.estimatedDurationSeconds >=
                    initialValidation.estimatedDurationSeconds &&
                  postExpansionValidation.coverageRatio <= 1.25
                ) {
                  finalRecapSegments = postExpansionValidation.segments;
                }
              }
            }
          } catch {
            // Preserve valid initial recap segments if optional expansion pass fails
          }
        }

        // Phase 4 (MOVIE RECAP ONLY): Pre-final Character Name & Identity Consistency Verification Pass
        if (recapContext.verifiedCharacters.length > 0) {
          const consistencyAudit = auditRecapCharacterConsistency(
            finalRecapSegments,
            recapContext.verifiedCharacters
          );
          if (consistencyAudit.needsConsistencyPass) {
            try {
              const consistencyBundle = buildRecapCharacterConsistencyPrompt({
                beats: recapContext.beats,
                segments: finalRecapSegments,
                verifiedCharacters: recapContext.verifiedCharacters,
                audit: consistencyAudit,
                timestampedSegments: recapContext.timestampedSegments,
                scenes: recapContext.scenes,
              });
              const consistencySchema = {
                type: Type.OBJECT,
                properties: {
                  segments: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        id: { type: Type.STRING },
                        myanmarText: { type: Type.STRING },
                        emoji: { type: Type.STRING },
                      },
                      required: ['id', 'myanmarText', 'emoji'],
                    },
                  },
                },
                required: ['segments'],
              };
              const consistencyResult = await runScriptGeneration(
                consistencyBundle.systemInstruction,
                consistencyBundle.prompt,
                consistencySchema
              );
              if (consistencyResult.response?.text) {
                const refinedJson = JSON.parse(consistencyResult.response.text.trim()) as {
                  segments?: Array<{ id?: string; myanmarText?: string; emoji?: string }>;
                };
                if (Array.isArray(refinedJson.segments) && refinedJson.segments.length === finalRecapSegments.length) {
                  const postConsistencyValidation = validateAndRefineRecapSegments({
                    beats: recapContext.beats,
                    rawSegments: refinedJson.segments,
                    videoDurationSeconds: durationSeconds,
                    voiceSpeed,
                  });
                  const postAudit = auditRecapCharacterConsistency(
                    postConsistencyValidation.segments,
                    recapContext.verifiedCharacters
                  );
                  const improvedIdentity =
                    postAudit.usedKnownNames.length > consistencyAudit.usedKnownNames.length ||
                    postAudit.pronounHeavyBeatIds.length < consistencyAudit.pronounHeavyBeatIds.length;
                  if (
                    improvedIdentity &&
                    postConsistencyValidation.coverageRatio >= Math.min(0.75, initialValidation.coverageRatio * 0.85) &&
                    postConsistencyValidation.coverageRatio <= 1.25
                  ) {
                    finalRecapSegments = postConsistencyValidation.segments;
                  }
                }
              }
            } catch {
              // Preserve validated segments cleanly if optional consistency refinement fails
            }
          }
        }

        const rawRecapCaptions: CaptionSegment[] = buildOriginalAudioCaptions(
          targetItems.map((orig, idx) => ({
            id: `cap_${idx + 1}`,
            start: orig.start,
            end: orig.end,
            text: String(finalRecapSegments[idx]?.myanmarText || orig.text).trim(),
            emoji: String(finalRecapSegments[idx]?.emoji || '🎬').trim() || '🎬',
          }))
        );
        const directRecapCaptions = splitLongCaptionsToMaxTwoLines(rawRecapCaptions, {
          videoWidth,
          videoHeight,
        });

        res.json({
          scriptMy: directRecapCaptions.map((c) => c.text.replace(/\n+/g, ' ')).join(' '),
          thumbnailTitleMy: truncateThumbnailTitle(
            String(parsed.thumbnailTitleMy || 'မထင်မှတ်ထားတဲ့အလှည့်')
          ),
          captions: directRecapCaptions,
          timelineSegments: [],
        });
        return;
      }

      // Tool 3 ('captions'): build direct captions (no silence/speaking timeline segmentation)
      const rawDirectCaptions: CaptionSegment[] = buildOriginalAudioCaptions(
        targetItems.map((orig, idx) => ({
          id: `cap_${idx + 1}`,
          start: orig.start,
          end: orig.end,
          text: String(parsed.segments?.[idx]?.myanmarText || orig.text).trim(),
          emoji: String(parsed.segments?.[idx]?.emoji || '💬').trim(),
        }))
      );
      const directCaptions = splitLongCaptionsToMaxTwoLines(rawDirectCaptions, {
        videoWidth,
        videoHeight,
      });

      res.json({
        scriptMy: directCaptions.map((c) => c.text.replace(/\n+/g, ' ')).join(' '),
        thumbnailTitleMy: truncateThumbnailTitle(
          String(parsed.thumbnailTitleMy || 'မူရင်းအသံ စာတန်းထိုး')
        ),
        captions: directCaptions,
        timelineSegments: [],
      });
    } catch (error) {
      if (isQuotaRateLimitError(error)) {
        const retrySec = extractRetryAfterSeconds(error) || 35;
        res.status(429).json({
          retryAfterSeconds: retrySec,
          errorMy: `Gemini AI အသုံးပြုမှု ခေတ္တပြည့်သွားပါသည် — ${retrySec} စက္ကန့်ခန့်စောင့်ပြီး ထပ်မံနှိပ်ပေးပါ`,
        });
        return;
      }
      console.error('Gemini script error:', error instanceof Error ? error.message : error);
      const isNetwork = isTransientNetworkError(error);
      res.status(isNetwork ? 503 : 500).json({
        errorMy: isNetwork
          ? 'Gemini AI ဆာဗာနှင့် ချိတ်ဆက်မှု ယာယီပြတ်တောက်သွားပါသည် — ခေတ္တစောင့်ပြီး ထပ်မံနှိပ်ပေးပါ'
          : 'Gemini AI ဖြင့် မြန်မာဇာတ်ညွှန်း ဖန်တီးရာတွင် အမှားဖြစ်ပွားပါသည်',
      });
    }
  });

  // 7b. Live Free Gemini AI Voice Preview (caches short sample clips cleanly per voice + gender)
  const VOICE_PREVIEW_DIR = path.join(SAMPLE_CACHE_DIR, 'voice_previews');
  fs.mkdirSync(VOICE_PREVIEW_DIR, { recursive: true });

  app.get('/api/preview-voice/file/:filename', (req: Request, res: Response) => {
    const filename = path.basename(String(req.params.filename || '')).replace(/[^a-zA-Z0-9._-]/g, '');
    const filePath = path.join(VOICE_PREVIEW_DIR, filename);
    if (!filename || !fs.existsSync(filePath)) {
      res.status(404).json({ errorMy: 'အသံနမူနာဖိုင် မတွေ့ပါ' });
      return;
    }
    res.sendFile(filePath);
  });

  app.post('/api/preview-voice', async (req: Request, res: Response) => {
    try {
      const ttsEngine: TtsEngineId = normalizeTtsEngineId(req.body?.ttsEngine ?? req.body?.engine);
      const rawSpeed = req.body?.speed ?? req.body?.voiceSpeed ?? 1.0;
      const speed: VoiceSpeed = parseVoiceSpeedInput(rawSpeed);
      const safeSpeedTag = String(getVoiceSpeedFactor(speed).toFixed(2)).replace('.', '_');

      if (ttsEngine === 'edge-tts') {
        const rawGender = String(req.body?.voiceGender || '').toLowerCase();
        const requestedGender: VoiceGender | null =
          rawGender === 'male' ? 'male' : rawGender === 'female' ? 'female' : null;
        const explicitVoiceId = req.body?.voiceId ?? req.body?.edgeVoiceId;
        const edgeVoiceId = resolveEdgeVoiceForGender(requestedGender, explicitVoiceId);
        const edgeMeta = EDGE_BURMESE_VOICES[edgeVoiceId];
        const voiceGender = edgeMeta.gender;
        const sampleText = String(req.body?.sampleTextMy || edgeMeta.sampleTextMy).trim();

        const filename = `preview_edge_${edgeVoiceId}_${safeSpeedTag}.wav`;
        const outPath = path.join(VOICE_PREVIEW_DIR, filename);

        let needsGenerate = !fs.existsSync(outPath) || fs.statSync(outPath).size < 2000;
        if (!needsGenerate) {
          try {
            await validateAudibleSpeechFile(outPath, 'Cached Edge Voice Preview');
          } catch {
            needsGenerate = true;
          }
        }

        if (needsGenerate) {
          const rawTmpPath = path.join(VOICE_PREVIEW_DIR, `raw_${filename}.mp3`);
          await synthesizeEdgeTtsAudioToFile(sampleText, edgeVoiceId, rawTmpPath);
          const postFilter = getAudioTtsPostFilter(speed);
          await execFileAsync('ffmpeg', [
            '-y',
            '-i',
            rawTmpPath,
            ...(postFilter ? ['-af', postFilter] : []),
            '-ac',
            '1',
            '-ar',
            '48000',
            outPath,
          ]);
          fs.rmSync(rawTmpPath, { force: true });
          await validateAudibleSpeechFile(outPath, `Edge Voice Preview (${edgeVoiceId})`);
        }

        res.json({
          audioUrl: `/api/preview-voice/file/${filename}`,
          ttsEngine: 'edge-tts',
          voiceId: edgeVoiceId,
          voiceGender,
          sampleTextMy: sampleText,
        });
        return;
      }

      const ai = createGeminiClient();
      if (!ai) {
        res.status(400).json({
          missingKey: 'GEMINI_API_KEY',
          errorMy: 'GEMINI_API_KEY မသတ်မှတ်ရသေးပါ — Server Environment Variable တွင် GEMINI_API_KEY ထည့်သွင်းပါ',
        });
        return;
      }

      const voiceStyle = normalizeMyanmarVoiceId(req.body?.voiceStyle);
      const voiceMeta = getGeminiFreeVoice(voiceStyle);
      const rawGender = String(req.body?.voiceGender || 'female').toLowerCase();
      const voiceGender: VoiceGender = rawGender === 'male' ? 'male' : 'female';

      const filename = `preview_gemini_${voiceMeta.id}_${voiceGender}_${safeSpeedTag}.wav`;
      const outPath = path.join(VOICE_PREVIEW_DIR, filename);

      if (!fs.existsSync(outPath) || fs.statSync(outPath).size < 2000) {
        const rawBytes = await synthesizeGeminiTtsAudio(
          voiceMeta.sampleTextMy,
          speed,
          false,
          voiceMeta.id,
          voiceGender
        );
        const rawTmpPath = path.join(VOICE_PREVIEW_DIR, `raw_${filename}`);
        fs.writeFileSync(rawTmpPath, Buffer.from(rawBytes));
        const postFilter = getAudioTtsPostFilter(speed);
        await execFileAsync('ffmpeg', [
          '-y',
          '-i',
          rawTmpPath,
          ...(postFilter ? ['-af', postFilter] : []),
          '-ac',
          '1',
          '-ar',
          '48000',
          outPath,
        ]);
        fs.rmSync(rawTmpPath, { force: true });
        await validateAudibleSpeechFile(outPath, 'Gemini Voice Preview');
      }

      res.json({
        audioUrl: `/api/preview-voice/file/${filename}`,
        ttsEngine: 'gemini-tts',
        voiceStyle: voiceMeta.id,
        voiceGender,
        sampleTextMy: voiceMeta.sampleTextMy,
      });
    } catch (error) {
      if (error instanceof EdgeTtsProviderError) {
        res.status(502).json({
          providerError: true,
          ttsEngine: 'edge-tts',
          voiceId: error.voiceId,
          errorMy: error.message,
        });
        return;
      }
      if (error instanceof TtsQuotaError) {
        res.status(429).json({
          rateLimited: true,
          retryAfterSeconds: error.retryAfterSeconds,
          errorMy: `Gemini TTS ခေတ္တပြည့်နေပါသည် — ${error.retryAfterSeconds} စက္ကန့်အကြာ ထပ်မံစမ်းသပ်ပါ`,
        });
        return;
      }
      console.error('Voice preview error:', error);
      res.status(500).json({
        errorMy:
          error instanceof Error
            ? `အသံနမူနာ ထုတ်လုပ်ရာတွင် အမှားဖြစ်ပွားပါသည်: ${error.message}`
            : 'AI အသံနမူနာ ထုတ်လုပ်ရာတွင် အမှားဖြစ်ပွားပါသည်',
      });
    }
  });

  // 8. Step 4: Per-Speaking-Segment TTS (Edge Burmese Neural API-key-free OR Gemini TTS) + Duration-Locked Sync
  app.post('/api/generate-tts', async (req: Request, res: Response) => {
    try {
      const ttsEngine: TtsEngineId = normalizeTtsEngineId(req.body?.ttsEngine ?? req.body?.engine);
      if (ttsEngine === 'gemini-tts') {
        const ai = createGeminiClient();
        if (!ai) {
          res.status(400).json({
            missingKey: 'GEMINI_API_KEY',
            errorMy: 'GEMINI_API_KEY မသတ်မှတ်ရသေးပါ — Server Environment Variable တွင် GEMINI_API_KEY ထည့်သွင်းပါ',
          });
          return;
        }
      }

      const sessionId = String(req.body?.sessionId || '');
      const tool = (req.body?.tool || 'dubbing') as StudioTool;
      const scriptMy = String(req.body?.scriptMy || '').trim();
      const rawSpeed = req.body?.speed ?? req.body?.voiceSpeed ?? 1.0;
      const speed: VoiceSpeed = parseVoiceSpeedInput(rawSpeed);
      const voiceStyle = normalizeMyanmarVoiceId(req.body?.voiceStyle);
      const explicitVoiceId = req.body?.voiceId ?? req.body?.edgeVoiceId;
      const incomingCaptions = Array.isArray(req.body?.captions)
        ? (req.body.captions as CaptionSegment[])
        : [];
      const incomingTimeline = Array.isArray(req.body?.timelineSegments)
        ? (req.body.timelineSegments as VideoTimelineSegment[])
        : null;
      const requestedDuration = Number(req.body?.durationSeconds || 12);

      if (!sessionId) {
        res.status(400).json({ errorMy: 'Session ID မတွေ့ပါ — ဗီဒီယိုကို ပြန်လည်ထည့်သွင်းပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      const sourcePath = path.join(dir, 'source.mp4');
      const videoMeta = fs.existsSync(sourcePath) ? await probeVideo(sourcePath) : null;
      const videoDuration = Math.max(0.5, videoMeta?.duration || requestedDuration || 12);
      const finalWavPath = path.join(dir, 'tts_final.wav');

      // TOOL 3: CAPTIONS ONLY — Keep original audio; never generate AI voice or apply voice speed selection
      if (tool === 'captions') {
        res.json({
          audioUrl: null,
          syncedCaptions: incomingCaptions,
          timelineSegments: [],
          syncSummary: {
            tool: 'captions',
            segmentCount: incomingCaptions.length,
            originalVideoDuration: Number(videoDuration.toFixed(3)),
            aiVoiceDuration: 0,
            finalVideoDuration: Number(videoDuration.toFixed(3)),
            videoPlaybackRate: 1.0,
            voiceSpeed: 1.0,
          } satisfies SyncSummary,
        });
        return;
      }

      let selectedVoiceGender: VoiceGender = 'female';
      let edgeVoiceId: EdgeVoiceId | undefined;
      if (ttsEngine === 'edge-tts') {
        const rawG = String(req.body?.voiceGender ?? req.body?.gender ?? '').trim().toLowerCase();
        const inferredGender: VoiceGender | null =
          rawG === 'male' ? 'male' : rawG === 'female' ? 'female' : null;
        edgeVoiceId = resolveEdgeVoiceForGender(inferredGender, explicitVoiceId);
        selectedVoiceGender = EDGE_BURMESE_VOICES[edgeVoiceId].gender;
      } else {
        const genderValidation = validateVoiceGenderForTool(
          tool,
          req.body?.voiceGender ?? req.body?.gender
        );
        if (!genderValidation.valid) {
          res.status(400).json({ errorMy: genderValidation.errorMy });
          return;
        }
        selectedVoiceGender = genderValidation.gender ?? 'male';
      }

      const ttsPostFilter = getAudioTtsPostFilter(speed);

      const synthesizeToWavFile = async (
        textToSpeak: string,
        outputWavPath: string,
        multiSegment = false,
        tag = 'TTS'
      ) => {
        if (ttsEngine === 'edge-tts' && edgeVoiceId) {
          const rawMp3Path = `${outputWavPath}.edge.mp3`;
          await synthesizeEdgeTtsAudioToFile(textToSpeak, edgeVoiceId, rawMp3Path);
          await execFileAsync('ffmpeg', [
            '-y',
            '-i',
            rawMp3Path,
            ...(ttsPostFilter ? ['-af', ttsPostFilter] : []),
            '-ac',
            '1',
            '-ar',
            '48000',
            outputWavPath,
          ]);
          fs.rmSync(rawMp3Path, { force: true });
          await validateAudibleSpeechFile(outputWavPath, `${tag} (Edge ${edgeVoiceId})`);
          return;
        }

        const rawBytes = await synthesizeGeminiTtsAudio(
          textToSpeak,
          speed,
          multiSegment,
          voiceStyle,
          selectedVoiceGender
        );
        const rawGemPath = `${outputWavPath}.gem.wav`;
        fs.writeFileSync(rawGemPath, Buffer.from(rawBytes));
        await execFileAsync('ffmpeg', [
          '-y',
          '-i',
          rawGemPath,
          ...(ttsPostFilter ? ['-af', ttsPostFilter] : []),
          '-ac',
          '1',
          '-ar',
          '48000',
          outputWavPath,
        ]);
        fs.rmSync(rawGemPath, { force: true });
        await validateAudibleSpeechFile(outputWavPath, `${tag} (Gemini TTS)`);
      };

      // TOOL 1: MOVIE RECAP — Generate ONE continuous full Myanmar recap TTS voice and adjust WHOLE video up to 2x+ to match it
      if (tool === 'recap') {
        try {
          if (fs.existsSync(path.join(dir, 'timeline_plan.json'))) {
            fs.unlinkSync(path.join(dir, 'timeline_plan.json'));
          }
        } catch {
          // ignore cleanup failure
        }

        const cleanScriptSpeech = sanitizeTtsSpeechText(scriptMy);
        const rawCaptionsSpeech = sanitizeTtsSpeechText(
          incomingCaptions.map((c) => c.text).join(' ')
        );
        const shouldPreferScriptMy =
          cleanScriptSpeech.length > 0 &&
          (incomingCaptions.length === 0 ||
            Math.abs(rawCaptionsSpeech.length - cleanScriptSpeech.length) >
              Math.max(18, cleanScriptSpeech.length * 0.12));

        const captionItems = shouldPreferScriptMy
          ? splitScriptIntoTimedCaptions(scriptMy, videoDuration).map((c) => ({
              id: c.id,
              text: c.text,
              emoji: c.emoji,
            }))
          : incomingCaptions.length > 0
            ? incomingCaptions.map((c) => ({ id: c.id, text: c.text, emoji: c.emoji }))
            : [
                {
                  id: 'cap_1',
                  text: scriptMy || 'ဒီဇာတ်ကားထဲက အဓိကအဖြစ်အပျက်ကို ကြည့်လိုက်ရအောင်။',
                  emoji: '🎬',
                },
              ];

        const continuousRecapText = shouldPreferScriptMy
          ? cleanScriptSpeech
          : captionItems
              .map((c) => `${sanitizeTtsSpeechText(c.text).replace(/[။.!?]+$/, '')}။`)
              .filter((t) => t !== '။')
              .join(' ');

        await synthesizeToWavFile(continuousRecapText, finalWavPath, false, 'Recap TTS');

        const aiVoiceDuration = await probeAudioDuration(finalWavPath);
        const wholePlan = computeVideoSpeedSyncPlan(videoDuration, aiVoiceDuration);
        const rawRecapCaptions = buildProportionalCaptionsForDuration(captionItems, wholePlan.aiVoiceDuration);
        const syncedCaptions = splitLongCaptionsToMaxTwoLines(rawRecapCaptions, {
          videoWidth: videoMeta?.width || 1280,
          videoHeight: videoMeta?.height || 720,
        });

        const recapSyncSummary: SyncSummary = {
          tool: 'recap',
          segmentCount: syncedCaptions.length,
          originalVideoDuration: wholePlan.originalVideoDuration,
          aiVoiceDuration: wholePlan.aiVoiceDuration,
          finalVideoDuration: wholePlan.aiVoiceDuration,
          videoPlaybackRate: wholePlan.videoPlaybackRate,
          voiceSpeed: speed,
          voiceGender: selectedVoiceGender,
          ttsEngine,
          ...(edgeVoiceId ? { voiceId: edgeVoiceId } : {}),
        };

        res.json({
          audioUrl: `/api/session/${sessionId}/file/tts_final.wav`,
          syncedCaptions,
          timelineSegments: [],
          syncSummary: recapSyncSummary,
        });
        return;
      }

      // TOOL 2: MYANMAR DUBBING — Single locked Burmese voice across ALL speaking segments + silence preserved strictly at 1.0x
      let workingTimeline: VideoTimelineSegment[] = [];
      if (incomingTimeline && incomingTimeline.length > 0) {
        workingTimeline = incomingTimeline;
      } else if (fs.existsSync(path.join(dir, 'timeline_groq.json'))) {
        try {
          workingTimeline = JSON.parse(fs.readFileSync(path.join(dir, 'timeline_groq.json'), 'utf8')) as VideoTimelineSegment[];
        } catch {
          workingTimeline = [];
        }
      }
      if (workingTimeline.length === 0) {
        workingTimeline =
          incomingCaptions.length > 0
            ? buildTimelineFromGroq(
                incomingCaptions.map((c) => ({ start: c.start, end: c.end, text: c.text })),
                [],
                videoDuration
              )
            : scriptMy
              ? buildTimelineFromGroq([{ start: 0, end: videoDuration, text: scriptMy }], [], videoDuration)
              : buildTimelineFromGroq([], [], videoDuration);
      }

      const editedByCapId = new Map<string, CaptionSegment>();
      for (const c of incomingCaptions) {
        editedByCapId.set(c.id, c);
      }
      workingTimeline = enforceSingleVoiceForDubbingSegments(
        workingTimeline.map((seg) => {
          if (seg.kind === 'silence') {
            return { ...seg, myanmarText: '', emoji: '', aiVoiceDuration: 0, setptsFactor: 1.0, videoPlaybackRate: 1.0 };
          }
          const directEdit = editedByCapId.get(`cap_${seg.id}`) || editedByCapId.get(seg.id);
          const splitEdits = incomingCaptions.filter(
            (c) => c.id.startsWith(`cap_${seg.id}_p`) || c.id.startsWith(`${seg.id}_p`)
          );
          const combinedSplitText =
            splitEdits.length > 0
              ? splitEdits.map((c) => c.text.replace(/\r?\n+/g, ' ').trim()).filter(Boolean).join(' ')
              : '';
          const rawCandidateText = (
            combinedSplitText ||
            directEdit?.text?.replace(/\r?\n+/g, ' ').trim() ||
            seg.myanmarText ||
            seg.text ||
            ''
          ).trim();
          const speakableText = sanitizeTtsSpeechText(rawCandidateText);
          if (!speakableText) {
            return {
              ...seg,
              kind: 'silence' as const,
              myanmarText: '',
              emoji: '',
              aiVoiceDuration: 0,
              setptsFactor: 1.0,
              videoPlaybackRate: 1.0,
            };
          }
          const emoji = (splitEdits[0]?.emoji || directEdit?.emoji || seg.emoji || '🎬').trim();
          return { ...seg, myanmarText: speakableText, emoji };
        }),
        selectedVoiceGender
      );

      const speakingSegments = workingTimeline.filter(
        (s) => s.kind === 'speaking' && sanitizeTtsSpeechText(s.myanmarText || s.text).length > 0
      );

      // Never generate fake silent audio as successful speech when no speaking text exists
      if (speakingSegments.length === 0) {
        res.status(400).json({
          errorMy: 'အသံသွင်းရန် မြန်မာစကားပြောအပိုင်း မတွေ့ရှိပါ — စာသားပါဝင်သော စကားပြောအပိုင်း လိုအပ်ပါသည်',
        });
        return;
      }

      // Phase A: Synthesize ALL speaking segments cleanly at ONE consistent user voiceSpeed
      // and strip only dead trailing silence (< -50dB) without distorting speech cadence.
      const rawVoiceDurationsById: Record<string, number> = {};
      const synthesizeRawSegment = async (seg: VideoTimelineSegment): Promise<void> => {
        const cleanBody = sanitizeTtsSpeechText(seg.myanmarText || seg.text);
        if (!cleanBody) return;
        const lineText = `${cleanBody.replace(/[။.!?]+$/, '')}။`;
        const speedSegPath = path.join(dir, `tts_${seg.id}_spd.wav`);
        const trimmedSegPath = path.join(dir, `tts_${seg.id}_raw.wav`);
        await synthesizeToWavFile(lineText, speedSegPath, false, `Dubbing Segment ${seg.id}`);
        await execFileAsync('ffmpeg', [
          '-y',
          '-i',
          speedSegPath,
          '-af',
          'areverse,silenceremove=start_periods=1:start_duration=0.05:start_threshold=-50dB,areverse,aresample=48000,aformat=channel_layouts=mono',
          '-ac',
          '1',
          '-ar',
          '48000',
          trimmedSegPath,
        ]);
        fs.rmSync(speedSegPath, { force: true });
        try {
          await validateAudibleSpeechFile(trimmedSegPath, `Raw Dubbing Segment ${seg.id}`);
        } catch {
          // If aggressive trim failed, synthesize cleanly without silenceremove
          await synthesizeToWavFile(lineText, trimmedSegPath, false, `Dubbing Segment ${seg.id}`);
        }
        rawVoiceDurationsById[seg.id] = await probeAudioDuration(trimmedSegPath);
      };

      const synthesizeBatchSegmentsRaw = async (segs: VideoTimelineSegment[], batchIdx: number) => {
        const joinedText = segs
          .map((s) => `${sanitizeTtsSpeechText(s.myanmarText || s.text).replace(/[။.!?]+$/, '')}။`)
          .join('\n\n');
        const batchWavPath = path.join(dir, `tts_batch_${batchIdx}.wav`);
        try {
          await synthesizeToWavFile(joinedText, batchWavPath, segs.length > 1, `Dubbing Batch ${batchIdx}`);
          const batchDur = await probeAudioDuration(batchWavPath);
          const silences = await detectAudioSilences(batchWavPath);
          const slices = splitAudioBoundariesForSegments(
            segs.map((s) => ({ text: s.myanmarText || s.text })),
            batchDur,
            silences
          );
          for (let i = 0; i < segs.length; i++) {
            const seg = segs[i];
            const sl = slices[i];
            const sliceRawPath = path.join(dir, `tts_${seg.id}_raw.wav`);
            const sliceDur = Math.max(0.18, sl.audioEnd - sl.audioStart);
            await execFileAsync('ffmpeg', [
              '-y',
              '-i',
              batchWavPath,
              '-ss',
              sl.audioStart.toFixed(3),
              '-to',
              Math.min(batchDur, sl.audioStart + sliceDur).toFixed(3),
              '-ac',
              '1',
              '-ar',
              '48000',
              sliceRawPath,
            ]);
            try {
              await validateAudibleSpeechFile(sliceRawPath, `Dubbing Batch Slice ${seg.id}`);
            } catch {
              await synthesizeRawSegment(seg);
              continue;
            }
            rawVoiceDurationsById[seg.id] = await probeAudioDuration(sliceRawPath);
          }
        } finally {
          fs.rmSync(batchWavPath, { force: true });
        }
      };

      if (ttsEngine === 'edge-tts') {
        for (const seg of speakingSegments) {
          await synthesizeRawSegment(seg);
        }
      } else {
        let nextSegIdx = 0;
        if (speakingSegments.length <= 4) {
          while (nextSegIdx < speakingSegments.length) {
            try {
              await synthesizeRawSegment(speakingSegments[nextSegIdx]);
              nextSegIdx += 1;
            } catch (segErr) {
              if (segErr instanceof TtsQuotaError && speakingSegments.length - nextSegIdx > 1) {
                break;
              }
              throw segErr;
            }
          }
        }

        if (nextSegIdx < speakingSegments.length) {
          const remaining = speakingSegments.slice(nextSegIdx);
          let batchIdx = 0;
          for (let i = 0; i < remaining.length; i += 4) {
            const chunk = remaining.slice(i, i + 4);
            await synthesizeBatchSegmentsRaw(chunk, batchIdx++);
          }
        }
      }

      // Phase B: Compute ONE uniform, natural voice schedule borrowing adjacent silence slack
      // so sentences NEVER jump between slow and frantic speeds!
      const schedule = computeUniformDubbingSchedule(workingTimeline, rawVoiceDurationsById, {
        minBreathGapSec: 0.12,
        maxBaseUniformTempo: 1.25,
      });

      const slotById = new Map(schedule.slots.map((sl) => [sl.segmentId, sl]));
      const voiceDurationsById: Record<string, number> = {};

      for (const slot of schedule.slots) {
        const rawSegPath = path.join(dir, `tts_${slot.segmentId}_raw.wav`);
        const segWavPath = path.join(dir, `tts_${slot.segmentId}.wav`);
        const afChain = slot.atempoFilter
          ? `${slot.atempoFilter},aresample=48000,aformat=channel_layouts=mono,apad=whole_dur=${slot.fittedDuration.toFixed(3)},atrim=0:${slot.fittedDuration.toFixed(3)}`
          : `aresample=48000,aformat=channel_layouts=mono,apad=whole_dur=${slot.fittedDuration.toFixed(3)},atrim=0:${slot.fittedDuration.toFixed(3)}`;
        await execFileAsync('ffmpeg', [
          '-y',
          '-i',
          rawSegPath,
          '-af',
          afChain,
          '-ac',
          '1',
          '-ar',
          '48000',
          segWavPath,
        ]);
        fs.rmSync(rawSegPath, { force: true });
        await validateAudibleSpeechFile(segWavPath, `Dubbing Slot ${slot.segmentId}`);
        voiceDurationsById[slot.segmentId] = slot.fittedDuration;
      }

      // Update timeline segments with exact duration-locked 1.0x video metrics & actual audible windows
      const plannedTimeline: VideoTimelineSegment[] = workingTimeline.map((seg) => {
        if (seg.kind === 'silence') {
          return {
            ...seg,
            myanmarText: '',
            emoji: '',
            aiVoiceDuration: 0,
            setptsFactor: 1.0,
            videoPlaybackRate: 1.0,
            outputStart: seg.start,
            outputEnd: seg.end,
          };
        }
        const slot = slotById.get(seg.id);
        return {
          ...seg,
          aiVoiceDuration: slot ? slot.fittedDuration : 0,
          setptsFactor: 1.0,
          videoPlaybackRate: 1.0,
          outputStart: slot ? slot.actualStart : seg.start,
          outputEnd: slot ? slot.actualEnd : seg.end,
        };
      });
      fs.writeFileSync(path.join(dir, 'timeline_plan.json'), JSON.stringify(plannedTimeline), 'utf8');

      // Assemble final full-duration dubbing track placing every slot at its exact [actualStart, actualEnd]
      const previewInputs: string[] = ['-y'];
      const previewFilterParts: string[] = [];
      let pInputIdx = 0;
      const concatAudioLabels: string[] = [];
      let audioCursor = 0;
      let pieceIdx = 0;

      for (const slot of schedule.slots) {
        if (slot.actualStart > audioCursor + 0.015) {
          const gapDur = Number((slot.actualStart - audioCursor).toFixed(3));
          previewFilterParts.push(`anullsrc=r=48000:cl=mono:d=${gapDur.toFixed(3)}[pa_${pieceIdx}]`);
          concatAudioLabels.push(`[pa_${pieceIdx}]`);
          pieceIdx += 1;
          audioCursor = slot.actualStart;
        }
        const segWav = path.join(dir, `tts_${slot.segmentId}.wav`);
        if (fs.existsSync(segWav)) {
          previewInputs.push('-i', segWav);
          previewFilterParts.push(
            `[${pInputIdx}:a]aresample=48000,aformat=channel_layouts=mono,asetpts=PTS-STARTPTS,apad=whole_dur=${slot.fittedDuration.toFixed(3)},atrim=0:${slot.fittedDuration.toFixed(3)}[pa_${pieceIdx}]`
          );
          concatAudioLabels.push(`[pa_${pieceIdx}]`);
          pInputIdx += 1;
          pieceIdx += 1;
          audioCursor = Number((audioCursor + slot.fittedDuration).toFixed(3));
        }
      }
      if (videoDuration > audioCursor + 0.015) {
        const tailDur = Number((videoDuration - audioCursor).toFixed(3));
        previewFilterParts.push(`anullsrc=r=48000:cl=mono:d=${tailDur.toFixed(3)}[pa_${pieceIdx}]`);
        concatAudioLabels.push(`[pa_${pieceIdx}]`);
        pieceIdx += 1;
      }

      if (concatAudioLabels.length === 0) {
        throw new Error('No dubbing audio slots produced');
      } else if (concatAudioLabels.length === 1) {
        previewFilterParts.push(`${concatAudioLabels[0]}acopy[p_out]`);
      } else {
        previewFilterParts.push(`${concatAudioLabels.join('')}concat=n=${concatAudioLabels.length}:v=0:a=1[p_out]`);
      }

      await execFileAsync('ffmpeg', [
        ...previewInputs,
        '-filter_complex',
        previewFilterParts.join(';'),
        '-map',
        '[p_out]',
        '-t',
        videoDuration.toFixed(3),
        finalWavPath,
      ]);
      await validateAudibleSpeechFile(finalWavPath, 'Final Assembled Dubbing Track');

      const totalAiVoiceDur = Number(
        schedule.slots.reduce((acc, s) => acc + s.fittedDuration, 0).toFixed(3)
      );
      const totalSilenceDur = Number(Math.max(0, videoDuration - totalAiVoiceDur).toFixed(3));

      const syncSummary: SyncSummary = {
        tool: 'dubbing',
        segmentCount: plannedTimeline.length,
        speakingSegmentCount: schedule.slots.length,
        silenceSegmentCount: plannedTimeline.filter((s) => s.kind === 'silence').length,
        preservedSilenceDuration: totalSilenceDur,
        originalVideoDuration: Number(videoDuration.toFixed(3)),
        aiVoiceDuration: totalAiVoiceDur,
        finalVideoDuration: Number(videoDuration.toFixed(3)),
        videoPlaybackRate: 1.0,
        voiceSpeed: speed,
        voiceGender: selectedVoiceGender,
        ttsEngine,
        ...(edgeVoiceId ? { voiceId: edgeVoiceId } : {}),
      };

      const syncedSplitCaptions = splitLongCaptionsToMaxTwoLines(schedule.syncedCaptions, {
        videoWidth: videoMeta?.width || 1280,
        videoHeight: videoMeta?.height || 720,
      });

      res.json({
        audioUrl: `/api/session/${sessionId}/file/tts_final.wav`,
        syncedCaptions: syncedSplitCaptions,
        timelineSegments: plannedTimeline,
        syncSummary,
      });
    } catch (error) {
      if (error instanceof EdgeTtsProviderError) {
        res.status(502).json({
          providerError: true,
          ttsEngine: 'edge-tts',
          voiceId: error.voiceId,
          errorMy: error.message,
        });
        return;
      }
      if (error instanceof TtsQuotaError || isQuotaRateLimitError(error)) {
        const retrySec =
          error instanceof TtsQuotaError ? error.retryAfterSeconds : extractRetryAfterSeconds(error) || 35;
        res.status(429).json({
          retryAfterSeconds: retrySec,
          errorMy: `Gemini TTS အခမဲ့အသုံးပြုမှု အကြိမ်ရေ ပြည့်သွားပါသည် — ကျေးဇူးပြု၍ ${retrySec} စက္ကန့်ခန့် စောင့်ပြီးမှ ထပ်မံကြိုးစားပါ`,
        });
        return;
      }
      console.error('Gemini TTS error:', error instanceof Error ? error.message : error);
      const isNetwork = isTransientNetworkError(error);
      res.status(isNetwork ? 503 : 500).json({
        errorMy: isNetwork
          ? 'Gemini TTS ဆာဗာနှင့် ချိတ်ဆက်မှု ယာယီပြတ်တောက်သွားပါသည် — ခေတ္တစောင့်ပြီး ထပ်မံကြိုးစားပါ'
          : 'Gemini TTS မြန်မာအသံ ထုတ်လုပ်ရာတွင် အမှားဖြစ်ပွားပါသည်',
      });
    }
  });

  // 8a. Automatic Movie Recap Scene Analysis (Gemini Primary -> Groq Vision Automatic Fallback with Frame Deduplication & Resume)
  app.post('/api/analyze-scenes', async (req: Request, res: Response) => {
    const wantsStream =
      req.query.stream === '1' ||
      String(req.headers.accept || '').toLowerCase().includes('application/x-ndjson');

    const emitEvent = (payload: Record<string, unknown>) => {
      if (wantsStream && !res.writableEnded) {
        res.write(`${JSON.stringify(payload)}\n`);
      }
    };

    try {
      const sessionId = String(req.body?.sessionId || '').trim();
      if (!sessionId) {
        res.status(400).json({ errorMy: 'Session ID မတွေ့ပါ — ဗီဒီယိုကို ဦးစွာထည့်သွင်းပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      const sourcePath = path.join(dir, 'source.mp4');
      if (!fs.existsSync(sourcePath)) {
        res.status(404).json({ errorMy: 'စစ်ဆေးရန် ဗီဒီယိုဖိုင် မတွေ့ပါ — အဆင့် ၁ တွင် ဗီဒီယိုထည့်သွင်းပါ' });
        return;
      }

      const forceRestart = req.body?.forceRestart === true;
      const simulateGeminiQuota = req.body?.simulateGeminiQuota === true;
      const videoTitle = String(req.body?.videoTitle || '').trim();
      let transcriptText = String(req.body?.transcript || '').trim();
      let transcriptSegmentsInput = Array.isArray(req.body?.segments)
        ? (req.body.segments as Array<{ start: number; end: number; text: string }>)
        : [];

      if (wantsStream) {
        res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
        res.setHeader('Cache-Control', 'no-cache, no-transform');
        res.setHeader('X-Accel-Buffering', 'no');
        res.flushHeaders?.();
      }

      const sourceStat = fs.statSync(sourcePath);
      const videoSignature = `${sourceStat.size}:${Math.floor(sourceStat.mtimeMs)}`;
      const checkpointPath = path.join(dir, 'scene_analysis_state.json');

      // Load or validate checkpoint
      let checkpoint: SceneAnalysisCheckpoint | null = null;
      if (!forceRestart && fs.existsSync(checkpointPath)) {
        try {
          const parsed = JSON.parse(fs.readFileSync(checkpointPath, 'utf8')) as SceneAnalysisCheckpoint;
          if (parsed && parsed.videoSignature === videoSignature && Array.isArray(parsed.frames) && parsed.frames.length > 0) {
            checkpoint = parsed;
          }
        } catch {
          checkpoint = null;
        }
      }

      const meta = await probeVideo(sourcePath);
      const groqKey = getGroqApiKey();
      const geminiClientBeta = createGeminiClient('v1beta');
      const geminiClientV1 = createGeminiClient('v1');

      if (!geminiClientBeta && !geminiClientV1 && !groqKey) {
        const msg = 'GEMINI_API_KEY သို့မဟုတ် GROQ_API_KEY မသတ်မှတ်ရသေးပါ';
        if (wantsStream) {
          emitEvent({ type: 'error', errorMy: msg, scenes: [] });
          res.end();
        } else {
          res.status(400).json({ errorMy: msg });
        }
        return;
      }

      // Start on Gemini primary if configured and not cooling down from scene quota
      const geminiSceneCooldownActive =
        geminiCooldowns.isCoolingDown('scene_quota:gemini-4-hydrogen') &&
        geminiCooldowns.isCoolingDown('scene_quota:gemini-3.1-flash-lite');

      const groqUsable = Boolean(groqKey && !groqInvalidKeys.has(groqKey));
      let activeProvider: SceneAnalysisProvider =
        (geminiClientBeta || geminiClientV1) && !geminiSceneCooldownActive ? 'gemini' : groqUsable ? 'groq' : 'gemini';
      let fallbackUsed = Boolean(checkpoint?.fallbackUsed) || activeProvider === 'groq';
      let groqVisionModelUsed: string | null = checkpoint?.groqVisionModel || null;

      emitEvent({
        type: 'status',
        activeProvider,
        statusMy: formatSceneProviderStatusMy(
          activeProvider,
          activeProvider === 'groq' ? 'switching' : 'analyzing'
        ),
        fallbackUsed,
        scenes: checkpoint?.completedScenes || [],
        completedCount: checkpoint?.completedScenes?.length || 0,
        totalCount: checkpoint?.frames?.length || 0,
      });

      // Load transcript context from cache or extract if audio exists and not yet cached
      const cachedTimelinePath = path.join(dir, 'timeline_groq.json');
      if (transcriptSegmentsInput.length === 0 && fs.existsSync(cachedTimelinePath)) {
        try {
          const cachedTl = JSON.parse(fs.readFileSync(cachedTimelinePath, 'utf8')) as VideoTimelineSegment[];
          transcriptSegmentsInput = cachedTl
            .filter((s) => s.kind === 'speaking' && String(s.text || '').trim())
            .map((s) => ({ start: s.start, end: s.end, text: s.text }));
          if (!transcriptText) {
            transcriptText = transcriptSegmentsInput.map((s) => s.text).join(' ').trim();
          }
        } catch {
          // Ignore malformed cache
        }
      }

      if (
        transcriptSegmentsInput.length === 0 &&
        meta.hasAudio &&
        !fs.existsSync(path.join(dir, 'is_sample.flag'))
      ) {
        const sceneAudioPath = path.join(dir, 'scene_audio_tmp.mp3');
        try {
          await execFileAsync('ffmpeg', [
            '-y',
            '-i',
            sourcePath,
            '-vn',
            '-ac',
            '1',
            '-ar',
            '16000',
            '-b:a',
            '20k',
            '-t',
            '900',
            sceneAudioPath,
          ]);
          const audioSize = fs.existsSync(sceneAudioPath) ? fs.statSync(sceneAudioPath).size : 0;
          if (audioSize > 0 && audioSize <= 24 * 1024 * 1024) {
            const audioBuf = fs.readFileSync(sceneAudioPath);
            if (groqKey && !groqInvalidKeys.has(groqKey)) {
              const form = new FormData();
              form.append('file', new Blob([new Uint8Array(audioBuf)], { type: 'audio/mpeg' }), 'audio.mp3');
              form.append('model', 'whisper-large-v3-turbo');
              form.append('response_format', 'verbose_json');
              form.append('timestamp_granularities[]', 'segment');
              const trRes = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
                method: 'POST',
                headers: { Authorization: `Bearer ${groqKey}` },
                body: form,
              });
              if (trRes.status === 401 || trRes.status === 403) {
                groqInvalidKeys.add(groqKey);
              } else if (trRes.ok) {
                const trJson = (await trRes.json()) as { text?: string; segments?: GroqSegmentTimestamp[] };
                transcriptText = String(trJson.text || '').trim();
                transcriptSegmentsInput = (trJson.segments || [])
                  .filter((s) => String(s.text || '').trim())
                  .map((s) => ({ start: Number(s.start || 0), end: Number(s.end || 0), text: String(s.text).trim() }));
              }
            }

            if (
              transcriptSegmentsInput.length === 0 &&
              (geminiClientBeta || geminiClientV1) &&
              audioSize <= 12 * 1024 * 1024
            ) {
              const gemTr = await transcribeAudioBufferWithGemini(audioBuf, Math.min(900, meta.duration));
              transcriptText = gemTr.text;
              transcriptSegmentsInput = gemTr.segments.map((s) => ({
                start: s.start,
                end: s.end,
                text: s.text,
              }));
            }
          }
        } catch {
          // Visual scene analysis continues smoothly even if audio transcription fails or hits limit
        } finally {
          fs.rmSync(sceneAudioPath, { force: true });
        }
      }

      // Extract representative frames via FFmpeg & deduplicate visually identical frames
      let targetFrames: ExtractedFrameMeta[] = [];
      if (
        checkpoint &&
        checkpoint.frames.every((f) => fs.existsSync(path.join(dir, f.filename)))
      ) {
        targetFrames = checkpoint.frames.map((f) => ({
          index: f.index,
          timestamp: f.timestamp,
          imageUrl: f.imageUrl,
          jpgPath: path.join(dir, f.filename),
        }));
      } else {
        const candidateTimes = computeRepresentativeFrameTimestamps(meta.duration, {
          minFrames: 5,
          maxFrames: 16,
          intervalSeconds: meta.duration > 180 ? Math.max(8, meta.duration / 16) : 2.2,
        });

        const rawFrames: ExtractedFrameMeta[] = [];
        for (let i = 0; i < candidateTimes.length; i++) {
          const ts = candidateTimes[i];
          const filename = `scene_raw_${i.toString().padStart(3, '0')}.jpg`;
          const jpgPath = path.join(dir, filename);
          const ppmPath = path.join(dir, `scene_raw_${i.toString().padStart(3, '0')}.ppm`);

          try {
            await execFileAsync('ffmpeg', [
              '-y',
              '-ss',
              ts.toFixed(2),
              '-i',
              sourcePath,
              '-vframes',
              '1',
              '-vf',
              'scale=512:-2',
              '-q:v',
              '4',
              jpgPath,
            ]);
            await execFileAsync('ffmpeg', [
              '-y',
              '-ss',
              ts.toFixed(2),
              '-i',
              sourcePath,
              '-vframes',
              '1',
              '-vf',
              'scale=64:36',
              ppmPath,
            ]);
            if (fs.existsSync(jpgPath)) {
              const ppmBytes = fs.existsSync(ppmPath) ? fs.readFileSync(ppmPath) : null;
              fs.rmSync(ppmPath, { force: true });
              rawFrames.push({
                index: i,
                timestamp: ts,
                imageUrl: `/api/session/${sessionId}/file/${filename}`,
                jpgPath,
                ppmBytes,
              });
            }
          } catch {
            fs.rmSync(ppmPath, { force: true });
          }
        }

        const deduped = deduplicateExtractedFrames(rawFrames, 0.04, 4);
        const keptPaths = new Set(deduped.map((d) => d.jpgPath));
        for (const rf of rawFrames) {
          if (!keptPaths.has(rf.jpgPath)) {
            fs.rmSync(rf.jpgPath, { force: true });
          }
        }

        const versionTag = Date.now();
        targetFrames = deduped.map((f, idx) => {
          const finalName = `scene_${idx.toString().padStart(3, '0')}.jpg`;
          const finalPath = path.join(dir, finalName);
          moveFileSafely(f.jpgPath, finalPath);
          return {
            index: idx,
            timestamp: f.timestamp,
            imageUrl: `/api/session/${sessionId}/file/${finalName}?v=${versionTag}`,
            jpgPath: finalPath,
          };
        });
      }

      if (targetFrames.length === 0) {
        const msg = 'ဗီဒီယိုမှ Scene ဖရိန်များ ထုတ်ယူ၍မရပါ';
        if (wantsStream) {
          emitEvent({ type: 'error', errorMy: msg, scenes: [] });
          res.end();
        } else {
          res.status(500).json({ errorMy: msg });
        }
        return;
      }

      // If already completed cleanly from cache for this exact video signature, return immediately
      if (
        !forceRestart &&
        checkpoint?.status === 'completed' &&
        checkpoint.completedScenes.length >= targetFrames.length &&
        checkpoint.storyAnalysisMy
      ) {
        const donePayload = {
          activeProvider: checkpoint.activeProvider,
          providerStatusMy: formatSceneProviderStatusMy(checkpoint.activeProvider, 'completed'),
          fallbackUsed: checkpoint.fallbackUsed,
          groqVisionModel: checkpoint.groqVisionModel,
          scenes: checkpoint.completedScenes,
          storyAnalysisMy: checkpoint.storyAnalysisMy,
          completedCount: checkpoint.completedScenes.length,
          totalCount: targetFrames.length,
          resumable: false,
        };
        if (wantsStream) {
          emitEvent({ type: 'complete', ...donePayload });
          res.end();
        } else {
          res.json(donePayload);
        }
        return;
      }

      let completedScenes: SceneSummary[] = mergeScenesChronologically(
        [],
        checkpoint?.completedScenes || []
      );

      const persistCheckpoint = (
        status: SceneAnalysisCheckpoint['status'],
        storyAnalysisMy = '',
        lastErrorMy?: string
      ) => {
        const nextCheckpoint: SceneAnalysisCheckpoint = {
          videoSignature,
          frames: targetFrames.map((f) => ({
            index: f.index,
            timestamp: f.timestamp,
            imageUrl: f.imageUrl,
            filename: path.basename(f.jpgPath),
          })),
          completedScenes,
          storyAnalysisMy,
          activeProvider,
          fallbackUsed,
          groqVisionModel: groqVisionModelUsed,
          status,
          ...(lastErrorMy ? { lastErrorMy } : {}),
          updatedAt: Date.now(),
        };
        fs.writeFileSync(checkpointPath, JSON.stringify(nextCheckpoint), 'utf8');
      };

      const buildBatchPromptText = (batchFrames: ExtractedFrameMeta[]) => {
        const minTs = Math.max(0, batchFrames[0].timestamp - 1.5);
        const maxTs = batchFrames[batchFrames.length - 1].timestamp + 1.5;
        const windowTranscript = transcriptSegmentsInput
          .filter((s) => s.end >= minTs && s.start <= maxTs)
          .map((s) => `[${s.start.toFixed(1)}s-${s.end.toFixed(1)}s] ${s.text}`)
          .join('\n');

        const priorSummary =
          completedScenes.length > 0
            ? completedScenes
                .slice(-3)
                .map((s) => `- Frame #${s.index} (${s.timestamp.toFixed(1)}s): ${s.descriptionMy}`)
                .join('\n')
            : '';

        return `Analyze ONLY these ${batchFrames.length} chronological video frames extracted from the uploaded video (${videoTitle || 'Uploaded Video'}).
Frame indices and exact timestamps:
${batchFrames.map((f) => `- frameIndex=${f.index}, timestamp=${f.timestamp.toFixed(2)}s`).join('\n')}
${windowTranscript ? `\nAudio Transcript around this time window:\n${windowTranscript}\n` : ''}
${priorSummary ? `\nPrevious Chronological Scenes Already Analyzed:\n${priorSummary}\n` : ''}
STRICT ANALYSIS RULES:
1. Examine each attached image carefully: identify visible characters, locations, physical actions, emotions, and key story events.
2. Combine visual observations with the audio transcript above when available; preserve verified character names, nicknames, family titles/relationships, professional ranks/titles, and honorifics (or accurate roles like "ရဲအရာရှိ", "ဆရာဝန်", "အမျိုးသမီးတစ်ဦး", "သူ့အစ်ကို" when unnamed) instead of generic pronouns.
3. Maintain strict chronological order for every frameIndex listed above.
4. Write 1 clear, informative Myanmar (Burmese) description sentence per frame ("descriptionMy").
5. Do NOT invent dialogue, names, relationships, objects, characters, or events that are not supported by the attached frames or transcript.
6. Return STRICT valid JSON matching: { "scenes": [ { "frameIndex": number, "descriptionMy": string } ] }.`;
      };

      const runGeminiSceneBatch = async (batchFrames: ExtractedFrameMeta[]): Promise<SceneSummary[]> => {
        const candidates: Array<{ client: GoogleGenAI | null; apiVersion: 'v1beta' | 'v1'; model: string }> = [
          { client: geminiClientBeta, apiVersion: 'v1beta', model: 'gemini-4-hydrogen' },
          { client: geminiClientV1, apiVersion: 'v1', model: 'gemini-4-hydrogen' },
          { client: geminiClientBeta, apiVersion: 'v1beta', model: 'gemini-3.1-flash-lite' },
        ];

        const batchPrompt = buildBatchPromptText(batchFrames);
        const parts = batchFrames.flatMap((fb) => [
          { text: `Frame #${fb.index} (at ${fb.timestamp.toFixed(2)}s):` },
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: fs.readFileSync(fb.jpgPath).toString('base64'),
            },
          },
        ]);
        parts.push({ text: batchPrompt });

        let sawQuota = false;
        let lastErr: unknown = null;

        for (const cand of candidates) {
          if (!cand.client) continue;
          const quotaKey = `scene_quota:${cand.model}`;
          const notFoundKey = `notfound:${cand.apiVersion}:${cand.model}`;
          if (geminiCooldowns.isCoolingDown(notFoundKey)) continue;
          if (geminiCooldowns.isCoolingDown(quotaKey)) {
            sawQuota = true;
            continue;
          }

          try {
            const resp = await withTransientRetry(
              () =>
                cand.client!.models.generateContent({
                  model: cand.model,
                  contents: { parts },
                  config: {
                    systemInstruction:
                      'You are a precise Myanmar film scene analyst. Analyze only the provided timestamped frames and optional transcript. Return strict JSON listing chronological Myanmar scene descriptions without inventing unseen details.',
                    responseMimeType: 'application/json',
                    responseSchema: {
                      type: Type.OBJECT,
                      properties: {
                        scenes: {
                          type: Type.ARRAY,
                          items: {
                            type: Type.OBJECT,
                            properties: {
                              frameIndex: { type: Type.INTEGER },
                              descriptionMy: { type: Type.STRING },
                            },
                            required: ['frameIndex', 'descriptionMy'],
                          },
                        },
                      },
                      required: ['scenes'],
                    },
                  },
                }),
              2,
              500
            );
            const rawText = String(resp?.text || '').trim();
            if (!rawText) continue;
            const parsed = JSON.parse(rawText) as {
              scenes?: Array<{ frameIndex?: number; descriptionMy?: string }>;
            };
            const byIdx = new Map<number, string>();
            for (const s of parsed.scenes || []) {
              if (typeof s.frameIndex === 'number' && String(s.descriptionMy || '').trim()) {
                byIdx.set(s.frameIndex, String(s.descriptionMy).trim());
              }
            }
            return batchFrames.map((f, localIdx) => ({
              index: f.index,
              timestamp: f.timestamp,
              imageUrl: f.imageUrl,
              descriptionMy:
                byIdx.get(f.index) ||
                String(parsed.scenes?.[localIdx]?.descriptionMy || '').trim() ||
                `အချိန် ${f.timestamp.toFixed(1)}s မြင်ကွင်း`,
              provider: 'gemini' as const,
            }));
          } catch (err) {
            lastErr = err;
            if (isGeminiQuotaExhaustedError(err)) {
              sawQuota = true;
              const retrySec = extractRetryAfterSeconds(err) || 60;
              geminiCooldowns.markCoolingDown(quotaKey, retrySec);
              continue;
            }
            if (isModelNotFoundError(err)) {
              geminiCooldowns.markCoolingDown(notFoundKey, 6 * 3600);
              continue;
            }
            if (isTransientNetworkError(err)) {
              continue;
            }
            const info = classifySceneProviderError('gemini', err);
            throw new SceneProviderBatchError('gemini', false, info.errorMy, String(err));
          }
        }

        if (sawQuota) {
          throw new SceneProviderBatchError(
            'gemini',
            true,
            'Gemini API 429 Quota ပြည့်သွားပါသည် (RESOURCE_EXHAUSTED)'
          );
        }
        const info = classifySceneProviderError('gemini', lastErr);
        throw new SceneProviderBatchError('gemini', false, info.errorMy, String(lastErr || info.errorMy));
      };

      const runGroqVisionBatch = async (
        batchFrames: ExtractedFrameMeta[]
      ): Promise<{ scenes: SceneSummary[]; modelUsed: string }> => {
        if (!groqKey || groqInvalidKeys.has(groqKey)) {
          throw new SceneProviderBatchError(
            'groq',
            false,
            groqKey
              ? 'Groq AI API Key မှားယွင်းနေပါသည် သို့မဟုတ် သက်တမ်းကုန်နေပါသည် (401 Invalid API Key)'
              : 'GROQ_API_KEY မသတ်မှတ်ရသေးပါ — Groq AI Fallback ကို အသုံးပြု၍မရပါ'
          );
        }
        const availableIds = await getGroqAvailableModelIds(groqKey);
        if (groqInvalidKeys.has(groqKey)) {
          throw new SceneProviderBatchError(
            'groq',
            false,
            'Groq AI API Key မှားယွင်းနေပါသည် သို့မဟုတ် သက်တမ်းကုန်နေပါသည် (401 Invalid API Key)'
          );
        }
        const visionModels = selectGroqVisionModelCandidates(availableIds);
        if (visionModels.length === 0) {
          throw new SceneProviderBatchError(
            'groq',
            false,
            'လက်ရှိ Groq AI အကောင့်တွင် Vision Model မတွေ့ရှိပါ'
          );
        }

        const batchPrompt = buildBatchPromptText(batchFrames);
        const contentParts: Array<
          | { type: 'text'; text: string }
          | { type: 'image_url'; image_url: { url: string } }
        > = [{ type: 'text', text: batchPrompt }];

        for (const fb of batchFrames) {
          const b64 = fs.readFileSync(fb.jpgPath).toString('base64');
          contentParts.push({
            type: 'text',
            text: `Frame frameIndex=${fb.index} at timestamp=${fb.timestamp.toFixed(2)}s:`,
          });
          contentParts.push({
            type: 'image_url',
            image_url: { url: `data:image/jpeg;base64,${b64}` },
          });
        }

        let sawGroqQuota = false;
        let lastGroqErr: unknown = null;

        for (const modelId of visionModels) {
          try {
            const gRes = await withTransientRetry(
              () =>
                fetch('https://api.groq.com/openai/v1/chat/completions', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${groqKey}`,
                  },
                  body: JSON.stringify({
                    model: modelId,
                    messages: [
                      {
                        role: 'system',
                        content:
                          'You are a precise Myanmar film scene analyst. Analyze only the provided timestamped video frame images and optional transcript. Return STRICT JSON only matching { "scenes": [{ "frameIndex": number, "descriptionMy": string }] } with Burmese descriptions.',
                      },
                      {
                        role: 'user',
                        content: contentParts,
                      },
                    ],
                    temperature: 0.2,
                    max_completion_tokens: 900,
                    response_format: { type: 'json_object' },
                  }),
                }),
              2,
              600
            );

            if (!gRes.ok) {
              const errText = await gRes.text();
              const errObj = new Error(`Groq ${gRes.status} (${modelId}): ${errText}`);
              console.warn('[Groq Vision candidate failed]', errObj.message.slice(0, 220));
              lastGroqErr = errObj;
              if (gRes.status === 401 || gRes.status === 403 || isProviderAuthError(errObj)) {
                groqInvalidKeys.add(groqKey);
                break;
              }
              if (gRes.status === 429 || isGeminiQuotaExhaustedError(errObj)) {
                sawGroqQuota = true;
                continue;
              }
              if (gRes.status === 404 || gRes.status === 400) {
                // Model unavailable or rejects multimodal format — try next verified Groq vision model
                continue;
              }
              continue;
            }

            const gData = (await gRes.json()) as {
              choices?: Array<{ message?: { content?: string } }>;
            };
            const rawContent = String(gData.choices?.[0]?.message?.content || '')
              .trim()
              .replace(/^```json\s*/i, '')
              .replace(/^```\s*/i, '')
              .replace(/\s*```$/i, '')
              .trim();
            if (!rawContent) continue;

            const parsed = JSON.parse(rawContent) as {
              scenes?: Array<{ frameIndex?: number; descriptionMy?: string }>;
            };
            const byIdx = new Map<number, string>();
            for (const s of parsed.scenes || []) {
              if (typeof s.frameIndex === 'number' && String(s.descriptionMy || '').trim()) {
                byIdx.set(s.frameIndex, String(s.descriptionMy).trim());
              }
            }

            const mapped = batchFrames.map((f, localIdx) => ({
              index: f.index,
              timestamp: f.timestamp,
              imageUrl: f.imageUrl,
              descriptionMy:
                byIdx.get(f.index) ||
                String(parsed.scenes?.[localIdx]?.descriptionMy || '').trim() ||
                `အချိန် ${f.timestamp.toFixed(1)}s မြင်ကွင်း`,
              provider: 'groq' as const,
            }));
            return { scenes: mapped, modelUsed: modelId };
          } catch (err) {
            console.warn('[Groq Vision candidate exception]', modelId, err instanceof Error ? err.message.slice(0, 300) : String(err));
            lastGroqErr = err;
            if (isGeminiQuotaExhaustedError(err)) {
              sawGroqQuota = true;
              continue;
            }
          }
        }

        const rawGroqCause =
          lastGroqErr instanceof Error ? lastGroqErr.message.slice(0, 260) : String(lastGroqErr || '').slice(0, 260);
        if (sawGroqQuota) {
          throw new SceneProviderBatchError(
            'groq',
            true,
            `Groq AI Vision Quota / Rate Limit ပြည့်သွားပါသည် — ခေတ္တစောင့်ပြီး ထပ်မံစစ်ဆေးပါ${rawGroqCause ? ` (${rawGroqCause})` : ''}`,
            rawGroqCause
          );
        }
        const info = classifySceneProviderError('groq', lastGroqErr);
        throw new SceneProviderBatchError('groq', false, info.errorMy, rawGroqCause || info.errorMy);
      };

      const batches = partitionFramesIntoBatches(targetFrames, GROQ_VISION_MAX_IMAGES_PER_REQUEST);
      const startBatchIdx = computeResumeBatchIndex(
        targetFrames,
        completedScenes,
        GROQ_VISION_MAX_IMAGES_PER_REQUEST
      );

      let geminiErrorDetail = '';
      let groqErrorDetail = '';

      // Bounded loop across remaining batches — NEVER enters infinite retry loops
      for (let bIdx = startBatchIdx; bIdx < batches.length; bIdx++) {
        const batch = batches[bIdx];
        // Skip frames already completed inside a partial batch
        const doneSet = new Set(completedScenes.map((s) => s.index));
        const pendingFrames = batch.filter((f) => !doneSet.has(f.index));
        if (pendingFrames.length === 0) continue;

        let batchSucceeded = false;

        if (activeProvider === 'gemini') {
          try {
            // Optional realistic failover test: allow batch 0 to succeed on Gemini when >1 batches exist, then simulate 429 on batch 1 (or batch 0 if single batch)
            if (simulateGeminiQuota && (batches.length === 1 || bIdx > startBatchIdx)) {
              throw new SceneProviderBatchError(
                'gemini',
                true,
                'Gemini API 429 Quota ပြည့်သွားပါသည် (RESOURCE_EXHAUSTED)',
                '429 RESOURCE_EXHAUSTED: Simulated quota limit'
              );
            }
            const batchScenes = await runGeminiSceneBatch(pendingFrames);
            completedScenes = mergeScenesChronologically(completedScenes, batchScenes);
            persistCheckpoint('in_progress');
            batchSucceeded = true;

            emitEvent({
              type: 'progress',
              activeProvider: 'gemini',
              statusMy: PROVIDER_STATUS_MY.geminiActive,
              fallbackUsed,
              scenes: completedScenes,
              completedCount: completedScenes.length,
              totalCount: targetFrames.length,
            });
          } catch (gErr) {
            const pErr =
              gErr instanceof SceneProviderBatchError
                ? gErr
                : new SceneProviderBatchError('gemini', isGeminiQuotaExhaustedError(gErr), classifySceneProviderError('gemini', gErr).errorMy);
            geminiErrorDetail = pErr.errorMy;

            // Automatic Fallback to Groq Vision when Gemini hits 429 RESOURCE_EXHAUSTED or daily quota
            if (pErr.isQuota && groqKey) {
              activeProvider = 'groq';
              fallbackUsed = true;
              persistCheckpoint('in_progress', '', pErr.errorMy);
              emitEvent({
                type: 'provider_switch',
                activeProvider: 'groq',
                statusMy: PROVIDER_STATUS_MY.switchingToGroq,
                fallbackUsed: true,
                scenes: completedScenes,
                completedCount: completedScenes.length,
                totalCount: targetFrames.length,
              });
            } else {
              persistCheckpoint('error', '', pErr.errorMy);
              const errMsg = groqKey ? pErr.errorMy : `${pErr.errorMy} (GROQ_API_KEY မရှိသဖြင့် Fallback မလုပ်နိုင်ပါ)`;
              if (wantsStream) {
                emitEvent({
                  type: 'error',
                  activeProvider,
                  fallbackUsed,
                  errorMy: errMsg,
                  scenes: completedScenes,
                  completedCount: completedScenes.length,
                  totalCount: targetFrames.length,
                  resumable: true,
                });
                res.end();
              } else {
                res.status(pErr.isQuota ? 429 : 502).json({
                  errorMy: errMsg,
                  activeProvider,
                  fallbackUsed,
                  scenes: completedScenes,
                  completedCount: completedScenes.length,
                  totalCount: targetFrames.length,
                  resumable: true,
                });
              }
              return;
            }
          }
        }

        if (!batchSucceeded && activeProvider === 'groq') {
          try {
            const { scenes: groqScenes, modelUsed } = await runGroqVisionBatch(pendingFrames);
            groqVisionModelUsed = modelUsed;
            completedScenes = mergeScenesChronologically(completedScenes, groqScenes);
            persistCheckpoint('in_progress');
            batchSucceeded = true;

            emitEvent({
              type: 'progress',
              activeProvider: 'groq',
              statusMy: PROVIDER_STATUS_MY.switchingToGroq,
              fallbackUsed: true,
              groqVisionModel: modelUsed,
              scenes: completedScenes,
              completedCount: completedScenes.length,
              totalCount: targetFrames.length,
            });
          } catch (qErr) {
            const pErr =
              qErr instanceof SceneProviderBatchError
                ? qErr
                : new SceneProviderBatchError('groq', isGeminiQuotaExhaustedError(qErr), classifySceneProviderError('groq', qErr).errorMy);
            groqErrorDetail = pErr.errorMy;
            persistCheckpoint('error', '', pErr.errorMy);

            const combinedErrMy = geminiErrorDetail
              ? `${PROVIDER_STATUS_MY.bothUnavailable} (${geminiErrorDetail} · ${groqErrorDetail})`
              : pErr.errorMy;

            if (wantsStream) {
              emitEvent({
                type: 'error',
                activeProvider: 'groq',
                fallbackUsed: true,
                groqVisionModel: groqVisionModelUsed,
                errorMy: combinedErrMy,
                geminiError: geminiErrorDetail || undefined,
                groqError: groqErrorDetail || undefined,
                scenes: completedScenes,
                completedCount: completedScenes.length,
                totalCount: targetFrames.length,
                resumable: true,
              });
              res.end();
            } else {
              res.status(pErr.isQuota ? 429 : 502).json({
                errorMy: combinedErrMy,
                activeProvider: 'groq',
                fallbackUsed: true,
                groqVisionModel: groqVisionModelUsed,
                geminiError: geminiErrorDetail || undefined,
                groqError: groqErrorDetail || undefined,
                scenes: completedScenes,
                completedCount: completedScenes.length,
                totalCount: targetFrames.length,
                resumable: true,
              });
            }
            return;
          }
        }
      }

      // Synthesize concise chronological Myanmar Story Analysis from all verified scenes + transcript
      let storyAnalysisMy = completedScenes.map((s) => s.descriptionMy).join(' ').trim();
      const summaryInput = `Chronological video scenes (${completedScenes.length}):\n${completedScenes
        .map((s) => `- [${s.timestamp.toFixed(1)}s] ${s.descriptionMy}`)
        .join('\n')}${transcriptText ? `\n\nTranscript highlights:\n${transcriptText.slice(0, 1800)}` : ''}\n\nWrite a cohesive 2-3 sentence Myanmar chronological Story Analysis summarizing the characters (preserving verified character names, nicknames, titles/ranks, honorifics, and family relationships consistently, or accurate observable roles if unnamed), conflict, key events, and emotional arc faithfully without inventing unseen names or events.`;

      let tryGroqStorySummary = activeProvider === 'groq';
      if (activeProvider === 'gemini' && !simulateGeminiQuota && geminiClientBeta) {
        try {
          const sumRes = await geminiClientBeta.models.generateContent({
            model: 'gemini-4-hydrogen',
            contents: summaryInput,
          });
          if (sumRes?.text?.trim()) {
            storyAnalysisMy = sumRes.text.trim();
          }
        } catch (sumErr) {
          if (isGeminiQuotaExhaustedError(sumErr) && groqKey && !groqInvalidKeys.has(groqKey)) {
            tryGroqStorySummary = true;
          }
        }
      }

      if (tryGroqStorySummary && groqKey && !groqInvalidKeys.has(groqKey)) {
        try {
          const textModel = 'llama-3.3-70b-versatile';
          const gSumRes = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${groqKey}`,
            },
            body: JSON.stringify({
              model: textModel,
              messages: [
                {
                  role: 'system',
                  content:
                    'Write a cohesive 2-3 sentence Myanmar (Burmese) chronological story summary strictly grounded in the provided scenes and transcript.',
                },
                { role: 'user', content: summaryInput },
              ],
              temperature: 0.25,
              max_completion_tokens: 400,
            }),
          });
          if (gSumRes.status === 401 || gSumRes.status === 403) {
            groqInvalidKeys.add(groqKey);
          } else if (gSumRes.ok) {
            const gSumJson = (await gSumRes.json()) as {
              choices?: Array<{ message?: { content?: string } }>;
            };
            const textOut = String(gSumJson.choices?.[0]?.message?.content || '').trim();
            if (textOut) {
              storyAnalysisMy = textOut;
              activeProvider = 'groq';
              fallbackUsed = true;
            }
          }
        } catch {
          // Keep chronological scene summary already built from verified scenes
        }
      }

      fallbackUsed = completedScenes.some((s) => s.provider === 'groq') || Boolean(groqVisionModelUsed);
      if (!fallbackUsed && completedScenes.some((s) => s.provider === 'gemini')) {
        activeProvider = 'gemini';
      }

      persistCheckpoint('completed', storyAnalysisMy);

      const finalPayload = {
        activeProvider,
        providerStatusMy: formatSceneProviderStatusMy(activeProvider, 'completed'),
        fallbackUsed,
        groqVisionModel: groqVisionModelUsed,
        scenes: completedScenes,
        storyAnalysisMy,
        transcript: transcriptText,
        segments: transcriptSegmentsInput,
        completedCount: completedScenes.length,
        totalCount: targetFrames.length,
        resumable: false,
      };

      if (wantsStream) {
        emitEvent({ type: 'complete', ...finalPayload });
        res.end();
      } else {
        res.json(finalPayload);
      }
    } catch (error) {
      console.error('Analyze scenes error:', error);
      const errorMy = 'ဗီဒီယို Scene စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည် — ထပ်မံကြိုးစားပါ';
      if (wantsStream && !res.writableEnded) {
        res.write(`${JSON.stringify({ type: 'error', errorMy })}\n`);
        res.end();
      } else {
        res.status(500).json({ errorMy });
      }
    }
  });

  // 8b. Video Content-Driven Thumbnail Analysis (extracts real candidate frames & identifies subject/headline)
  app.post('/api/analyze-thumbnail', async (req: Request, res: Response) => {
    try {
      const sessionId = String(req.body?.sessionId || '');
      if (!sessionId) {
        res.status(400).json({ errorMy: 'Session ID မတွေ့ပါ — ဗီဒီယိုကို ဦးစွာထည့်သွင်းပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      const sourcePath = path.join(dir, 'source.mp4');
      if (!fs.existsSync(sourcePath)) {
        res.status(404).json({ errorMy: 'စစ်ဆေးရန် ဗီဒီယိုဖိုင် မတွေ့ပါ — အဆင့် ၁ တွင် ဗီဒီယိုထည့်သွင်းပါ' });
        return;
      }

      const aspectRatio: ThumbnailAspectRatio = normalizeThumbnailAspectRatio(
        typeof req.body?.aspectRatio === 'string' ? req.body.aspectRatio : '16:9'
      );
      const transcript = String(req.body?.transcript || '').trim();
      const scriptMy = String(req.body?.scriptMy || '').trim();
      const videoTitle = String(req.body?.videoTitle || '').trim();

      const meta = await probeVideo(sourcePath);
      const candidateTimestamps = computeCandidateFrameTimestamps(meta.duration, 4);

      // Extract real JPEG frames from the source video at candidate timestamps
      const frameUrls: string[] = [];
      const frameBuffers: Array<{ index: number; timestamp: number; bytes: Buffer; url: string }> = [];

      for (let i = 0; i < candidateTimestamps.length; i++) {
        const ts = candidateTimestamps[i];
        const frameName = `thumb_cand_${i}.jpg`;
        const framePath = path.join(dir, frameName);
        await execFileAsync('ffmpeg', [
          '-y',
          '-ss',
          ts.toFixed(2),
          '-i',
          sourcePath,
          '-vframes',
          '1',
          '-vf',
          'scale=480:-2',
          '-q:v',
          '3',
          framePath,
        ]);
        if (fs.existsSync(framePath)) {
          const bytes = fs.readFileSync(framePath);
          const url = `/api/session/${sessionId}/file/${frameName}?v=${Date.now()}`;
          frameUrls.push(url);
          frameBuffers.push({ index: frameBuffers.length, timestamp: ts, bytes, url });
        }
      }

      if (frameBuffers.length === 0) {
        res.status(500).json({ errorMy: 'ဗီဒီယိုမှ ရုပ်ပုံဖရိန်များ ထုတ်ယူ၍မရပါ' });
        return;
      }

      const usedTimestamps = frameBuffers.map((f) => f.timestamp);
      const usedUrls = frameBuffers.map((f) => f.url);

      // Default heuristic fallback picks the frame with richest visual entropy (largest JPEG payload)
      let sharpestIdx = 0;
      let maxBytes = -1;
      frameBuffers.forEach((f, idx) => {
        if (f.bytes.length > maxBytes) {
          maxBytes = f.bytes.length;
          sharpestIdx = idx;
        }
      });

      const cleanTitleFallback =
        videoTitle.replace(/\s*\([^)]*\)/g, '').trim() || 'အထူးရုပ်ရှင်အနှစ်ချုပ်';

      const ai = createGeminiClient();
      if (!ai) {
        const heuristic = sanitizeThumbnailAnalysisResponse(
          {
            bestFrameIndex: sharpestIdx,
            subjectCategory: 'surprising_scene',
            subjectSummaryMy: 'ဗီဒီယိုအတွင်းမှ အထင်ရှားဆုံး မြင်ကွင်းဖရိန်',
            headlineMy: cleanTitleFallback,
            focusX: 50,
            focusY: 45,
            accentTheme: 'gold',
          },
          usedTimestamps,
          usedUrls,
          aspectRatio,
          cleanTitleFallback,
          false
        );
        res.json(heuristic);
        return;
      }

      const contextLines = [
        videoTitle ? `Video Title / Filename: ${videoTitle}` : '',
        transcript ? `Transcript excerpt: ${transcript.slice(0, 600)}` : '',
        scriptMy ? `Myanmar Recap Script excerpt: ${scriptMy.slice(0, 500)}` : '',
      ]
        .filter(Boolean)
        .join('\n');

      const analysisPrompt = `Analyze ONLY the attached candidate video frames (${frameBuffers.length} real frames extracted at timestamps ${usedTimestamps.map((t, i) => `#${i}=${t}s`).join(', ')}).
${contextLines ? `\nVideo Context:\n${contextLines}\n` : ''}
Target Platform Aspect Ratio: ${aspectRatio}.

STRICT CONTENT-DRIVEN THUMBNAIL RULES:
1. Identify the main subject ACTUALLY visible in the video:
   - Must be exactly one of: "person", "product", "food", "travel_scene", "tech_device", "action_moment", "surprising_scene".
2. Pick "bestFrameIndex" (0 to ${frameBuffers.length - 1}): the single sharpest, most attractive, expressive, scroll-stopping frame directly from these attached video images.
3. Describe what is ACTUALLY shown in that chosen frame in "subjectSummaryMy" (1 concise Myanmar sentence). Do NOT invent people, products, faces, or objects that are not visible in the video frames.
4. Write "headlineMy": a short, bold, clickable Myanmar headline (STRICTLY <= 24 characters total) that directly matches what this specific video is about. Avoid generic clickbait phrases unrelated to the frames.
5. Set "focusX" (15..85) and "focusY" (15..85) as percentage coordinates of the main subject's center in the chosen frame so ${aspectRatio} cropping centers tightly on the real subject.
6. Set "textPosition" to "top" or "bottom" on whichever edge leaves the main subject unobstructed.
7. Pick "accentTheme" ("gold" | "crimson" | "electric_blue" | "emerald") for maximum high-contrast legibility against the frame's colors.`;

      const visionParts = frameBuffers.flatMap((fb, idx) => [
        { text: `Candidate Frame #${idx} (at ${fb.timestamp}s):` },
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: fb.bytes.toString('base64'),
          },
        },
      ]);
      visionParts.push({ text: analysisPrompt });

      const aiBeta = createGeminiClient('v1beta') || ai;
      const visionConfig = {
        systemInstruction:
          'You are a visual video thumbnail director. Analyze only the provided video frames cleanly. Never hallucinate faces, items, or products absent from the frames. Return valid JSON matching the schema.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            bestFrameIndex: { type: Type.INTEGER },
            subjectCategory: { type: Type.STRING },
            subjectSummaryMy: { type: Type.STRING },
            headlineMy: { type: Type.STRING },
            focusX: { type: Type.NUMBER },
            focusY: { type: Type.NUMBER },
            textPosition: { type: Type.STRING },
            accentTheme: { type: Type.STRING },
          },
          required: [
            'bestFrameIndex',
            'subjectCategory',
            'subjectSummaryMy',
            'headlineMy',
            'focusX',
            'focusY',
            'textPosition',
            'accentTheme',
          ],
        },
      };

      const visionCandidates: Array<{ client: GoogleGenAI; apiVersion: 'v1beta' | 'v1'; model: string }> = [
        { client: aiBeta, apiVersion: 'v1beta', model: 'gemini-3.1-flash-lite' },
        { client: aiBeta, apiVersion: 'v1beta', model: 'gemini-4-hydrogen' },
      ];

      let visionResponse: Awaited<ReturnType<GoogleGenAI['models']['generateContent']>> | null = null;
      let usedVision = false;
      for (const vc of visionCandidates) {
        const quotaKey = `quota:${vc.model}`;
        const notFoundKey = `notfound:${vc.apiVersion}:${vc.model}`;
        if (geminiCooldowns.isCoolingDown(quotaKey) || geminiCooldowns.isCoolingDown(notFoundKey)) {
          continue;
        }

        try {
          const timeoutPromise = new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('Vision analysis timeout')), 12000)
          );
          visionResponse = await Promise.race([
            vc.client.models.generateContent({
              model: vc.model,
              contents: { parts: visionParts },
              config: visionConfig,
            }),
            timeoutPromise,
          ]);
          if (visionResponse?.text) {
            usedVision = true;
            break;
          }
        } catch (vcErr) {
          if (isQuotaRateLimitError(vcErr)) {
            const retrySec = extractRetryAfterSeconds(vcErr) || 60;
            geminiCooldowns.markCoolingDown(quotaKey, retrySec);
          } else if (isModelNotFoundError(vcErr)) {
            geminiCooldowns.markCoolingDown(notFoundKey, 6 * 3600);
          }
          // Quietly fall through to next available vision model or local sharpest-frame selection
        }
      }

      let rawJson: RawVisionThumbnailResponse = {
        bestFrameIndex: sharpestIdx,
        subjectCategory: 'surprising_scene',
        subjectSummaryMy: 'ဗီဒီယိုအတွင်းမှ အထင်ရှားဆုံး မြင်ကွင်းဖရိန်',
        headlineMy: cleanTitleFallback,
        focusX: 50,
        focusY: 45,
        accentTheme: 'gold',
      };

      if (usedVision && visionResponse?.text) {
        try {
          const cleanedJson = visionResponse.text
            .trim()
            .replace(/^```json\s*/i, '')
            .replace(/^```\s*/i, '')
            .replace(/\s*```$/i, '')
            .trim();
          rawJson = JSON.parse(cleanedJson) as RawVisionThumbnailResponse;
        } catch {
          usedVision = false;
        }
      }

      const sanitized = sanitizeThumbnailAnalysisResponse(
        rawJson,
        usedTimestamps,
        usedUrls,
        aspectRatio,
        cleanTitleFallback,
        usedVision
      );

      res.json(sanitized);
    } catch (error) {
      console.error('Analyze thumbnail error:', error);
      res.status(500).json({ errorMy: 'ဗီဒီယိုအကြောင်းအရာ စစ်ဆေးပြီး Thumbnail ဖန်တီးရာတွင် အမှားဖြစ်ပွားပါသည်' });
    }
  });

  // 8c. Automatic Background Detection for Hardcoded Text, Logo, Watermark & Fixed Graphics (No Manual Mask Editing)
  app.post('/api/detect-auto-blur', async (req: Request, res: Response) => {
    try {
      const sessionId = String(req.body?.sessionId || '');
      if (!sessionId) {
        res.status(400).json({ errorMy: 'Session ID မတွေ့ပါ — ဗီဒီယိုကို ဦးစွာထည့်သွင်းပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      const sourcePath = path.join(dir, 'source.mp4');
      if (!fs.existsSync(sourcePath)) {
        res.status(404).json({ errorMy: 'စစ်ဆေးရန် ဗီဒီယိုဖိုင် မတွေ့ပါ' });
        return;
      }

      const meta = await probeVideo(sourcePath);
      const dur = Math.max(1, meta.duration);
      const sampleTimes = [0.15, 0.5, 0.85].map((r) => Math.max(0.05, Math.min(dur - 0.1, dur * r)));

      const jpegFrames: Buffer[] = [];
      const ppmFrames: Uint8Array[] = [];

      for (let i = 0; i < sampleTimes.length; i++) {
        const ts = sampleTimes[i];
        const jpgPath = path.join(dir, `ab_frame_${i}.jpg`);
        const ppmPath = path.join(dir, `ab_frame_${i}.ppm`);
        try {
          await execFileAsync('ffmpeg', [
            '-y',
            '-ss',
            ts.toFixed(2),
            '-i',
            sourcePath,
            '-vframes',
            '1',
            '-vf',
            'scale=640:-2',
            '-q:v',
            '4',
            jpgPath,
          ]);
          if (fs.existsSync(jpgPath)) {
            jpegFrames.push(fs.readFileSync(jpgPath));
            fs.rmSync(jpgPath, { force: true });
          }
          await execFileAsync('ffmpeg', [
            '-y',
            '-ss',
            ts.toFixed(2),
            '-i',
            sourcePath,
            '-vframes',
            '1',
            '-vf',
            'scale=160:90',
            ppmPath,
          ]);
          if (fs.existsSync(ppmPath)) {
            ppmFrames.push(fs.readFileSync(ppmPath));
            fs.rmSync(ppmPath, { force: true });
          }
        } catch {
          // Continue with remaining frames
        }
      }

      let detectedRegions: AutoBlurRegion[] = [];
      const ai = createGeminiClient('v1beta');

      if (ai && jpegFrames.length > 0) {
        const detectionPrompt = `Inspect these ${jpegFrames.length} frames sampled across the uploaded video.
Detect ONLY existing hardcoded/baked-in elements overlaid on the video:
- "text": hardcoded subtitles, captions, channel titles, or text bars
- "logo": TV station bugs or channel logos
- "watermark": social handles, TikTok/CapCut/app watermarks, or website URLs
- "graphic": fixed graphic banners, borders, or corner stickers

Return tight normalized bounding boxes in percentages (0..100) relative to the video frame:
- xPct: left edge percentage (0..100)
- yPct: top edge percentage (0..100)
- widthPct: box width percentage (2..95)
- heightPct: box height percentage (2..45)
- kind: "text" | "logo" | "watermark" | "graphic"

Do NOT invent overlays if none are visible; return an empty "regions" array when clean.`;

        const parts = jpegFrames.flatMap((buf, idx) => [
          { text: `Frame ${idx + 1}:` },
          { inlineData: { mimeType: 'image/jpeg', data: buf.toString('base64') } },
        ]);
        parts.push({ text: detectionPrompt });

        const candidates = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
        for (const model of candidates) {
          const quotaKey = `quota:${model}`;
          const notFoundKey = `notfound:v1beta:${model}`;
          if (geminiCooldowns.isCoolingDown(quotaKey) || geminiCooldowns.isCoolingDown(notFoundKey)) {
            continue;
          }
          try {
            const timeoutPromise = new Promise<never>((_, reject) =>
              setTimeout(() => reject(new Error('Auto-blur vision timeout')), 12000)
            );
            const resp = await Promise.race([
              ai.models.generateContent({
                model,
                contents: { parts },
                config: {
                  systemInstruction:
                    'You are a precise computer-vision overlay detector. Output strict JSON listing only real hardcoded text, logos, watermarks, or fixed graphic overlays visible inside the frames.',
                  responseMimeType: 'application/json',
                  responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                      regions: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            xPct: { type: Type.NUMBER },
                            yPct: { type: Type.NUMBER },
                            widthPct: { type: Type.NUMBER },
                            heightPct: { type: Type.NUMBER },
                            kind: { type: Type.STRING },
                          },
                          required: ['xPct', 'yPct', 'widthPct', 'heightPct', 'kind'],
                        },
                      },
                    },
                    required: ['regions'],
                  },
                },
              }),
              timeoutPromise,
            ]);
            if (resp?.text) {
              const cleaned = resp.text
                .trim()
                .replace(/^```json\s*/i, '')
                .replace(/^```\s*/i, '')
                .replace(/\s*```$/i, '')
                .trim();
              const parsed = JSON.parse(cleaned) as { regions?: unknown };
              detectedRegions = sanitizeAutoBlurRegions(parsed.regions);
              break;
            }
          } catch (err) {
            if (isQuotaRateLimitError(err)) {
              geminiCooldowns.markCoolingDown(quotaKey, extractRetryAfterSeconds(err) || 60);
            } else if (isModelNotFoundError(err)) {
              geminiCooldowns.markCoolingDown(notFoundKey, 6 * 3600);
            }
          }
        }
      }

      if (detectedRegions.length === 0 && ppmFrames.length >= 2) {
        detectedRegions = detectStaticOverlayRegionsFromPpmFrames(ppmFrames);
      }

      // Built-in sample demo clip fallback so sample preview visibly showcases auto-blur on corner watermark + lower subtitle zone
      if (detectedRegions.length === 0 && fs.existsSync(path.join(dir, 'is_sample.flag'))) {
        detectedRegions = sanitizeAutoBlurRegions([
          { id: 'auto_wm_1', xPct: 74, yPct: 6, widthPct: 20, heightPct: 9, kind: 'watermark' },
          { id: 'auto_txt_1', xPct: 22, yPct: 83, widthPct: 56, heightPct: 10, kind: 'text' },
        ]);
      }

      fs.writeFileSync(path.join(dir, 'auto_blur_regions.json'), JSON.stringify(detectedRegions), 'utf8');
      res.json({
        regions: detectedRegions,
        width: meta.width,
        height: meta.height,
      });
    } catch (error) {
      console.error('Detect auto-blur error:', error);
      res.json({ regions: [] });
    }
  });

  // 8d. Automatic Silence / Audio-less Segment Detection for Auto-Cut
  app.post('/api/detect-silences', async (req: Request, res: Response) => {
    try {
      const sessionId = String(req.body?.sessionId || '');
      if (!sessionId) {
        res.status(400).json({ errorMy: 'Session ID မတွေ့ပါ — ဗီဒီယိုကို ဦးစွာထည့်သွင်းပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      const sourcePath = path.join(dir, 'source.mp4');
      if (!fs.existsSync(sourcePath)) {
        res.status(404).json({ errorMy: 'စစ်ဆေးရန် ဗီဒီယိုဖိုင် မတွေ့ပါ' });
        return;
      }

      const cfg = sanitizeAutoSilenceCutConfig({
        ...((req.body && typeof req.body === 'object') ? req.body : {}),
        enabled: true,
      });
      const meta = await probeVideo(sourcePath);

      if (!meta.hasAudio) {
        const emptyPlan = computeKeepAudioSegmentsFromSilences(meta.duration, [], {
          ...cfg,
          enabled: false,
        });
        res.json({
          hasAudio: false,
          config: cfg,
          plan: emptyPlan,
          messageMy: 'ဤဗီဒီယိုတွင် Audio Track မပါဝင်ပါ',
        });
        return;
      }

      const silences = await detectAudioSilencesWithConfig(
        sourcePath,
        cfg.noiseThresholdDb,
        cfg.minSilenceDuration
      );
      const plan = computeKeepAudioSegmentsFromSilences(meta.duration, silences, cfg);

      res.json({
        hasAudio: true,
        config: cfg,
        plan,
      });
    } catch (error) {
      console.error('Detect silences error:', error);
      res.status(500).json({
        errorMy: 'ဗီဒီယိုထဲမှ အသံမပါသော အပိုင်းများ စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်',
      });
    }
  });

  // 9. Step 6, 7, 8, 9: Final Video Render (Audio Crossfade + Logo Overlay + Animated Captions + 4K Export + Thumbnail)
  app.post(
    '/api/render-video',
    upload.fields([
      { name: 'logo', maxCount: 1 },
      { name: 'thumbnail', maxCount: 1 },
    ]),
    async (req: Request, res: Response) => {
      try {
        const sessionId = String(req.body?.sessionId || '');
        if (!sessionId) {
          res.status(400).json({ errorMy: 'Session ID မတွေ့ပါ' });
          return;
        }

        const dir = getSessionDir(sessionId);
        const sourcePath = path.join(dir, 'source.mp4');
        if (!fs.existsSync(sourcePath)) {
          res.status(404).json({ errorMy: 'အရင်းအမြစ် ဗီဒီယိုဖိုင် မတွေ့ပါ' });
          return;
        }

        const tool = (req.body?.tool || 'recap') as StudioTool;
        const resolution = (req.body?.resolution || '1080p') as ExportResolution;
        const musicMood = (req.body?.musicMood || 'thriller') as MusicMood;
        const crossfadeSec = Math.min(4, Math.max(0.5, Number(req.body?.crossfadeSeconds || 2)));
        const sfxEnabled = String(req.body?.sfxEnabled || 'true') === 'true';
        const captionsEnabled = resolveCaptionsEnabledFlag(req.body?.captionsEnabled, true);
        const logoEnabled = String(req.body?.logoEnabled || 'false') === 'true';
        const logoScale = Math.min(35, Math.max(6, Number(req.body?.logoScale || 14)));
        const subPos = JSON.parse(String(req.body?.subPos || '{"x":50,"y":82}')) as { x: number; y: number };
        const logoPos = JSON.parse(String(req.body?.logoPos || '{"x":86,"y":12}')) as { x: number; y: number };
        const captions = JSON.parse(String(req.body?.captions || '[]')) as CaptionSegment[];
        const burnSubtitles = shouldBurnSubtitlesInRender(captionsEnabled, captions);
        let captionDecoration: Record<string, unknown> | null = null;
        if (typeof req.body?.captionDecoration === 'string' && req.body.captionDecoration.trim()) {
          try {
            captionDecoration = JSON.parse(req.body.captionDecoration) as Record<string, unknown>;
          } catch {
            captionDecoration = null;
          }
        }
        const thumbnailTitle = truncateThumbnailTitle(String(req.body?.thumbnailTitle || 'အံ့ဩစရာဇာတ်သိမ်း'));
        const thumbnailAspectRatio = normalizeThumbnailAspectRatio(
          typeof req.body?.thumbnailAspectRatio === 'string' ? req.body.thumbnailAspectRatio : '16:9'
        );
        const thumbDims = getThumbnailDimensions(thumbnailAspectRatio);

        const files = req.files as Record<string, Express.Multer.File[]> | undefined;
        const logoFile = files?.logo?.[0];
        const uploadedThumb = files?.thumbnail?.[0];

        const meta = await probeVideo(sourcePath);
        const isPortrait = meta.height > meta.width;
        const outWidth = resolution === '4k' ? (isPortrait ? 2160 : 3840) : isPortrait ? 1080 : 1920;
        const outHeight = resolution === '4k' ? (isPortrait ? 3840 : 2160) : isPortrait ? 1920 : 1080;

        const timelinePlanPath = path.join(dir, 'timeline_plan.json');
        let timelineSegments: VideoTimelineSegment[] = [];
        if (typeof req.body?.timelineSegments === 'string' && req.body.timelineSegments.trim()) {
          try {
            timelineSegments = JSON.parse(req.body.timelineSegments) as VideoTimelineSegment[];
          } catch {
            timelineSegments = [];
          }
        } else if (fs.existsSync(timelinePlanPath)) {
          try {
            timelineSegments = JSON.parse(fs.readFileSync(timelinePlanPath, 'utf8')) as VideoTimelineSegment[];
          } catch {
            timelineSegments = [];
          }
        }

        const ttsPath = path.join(dir, 'tts_final.wav');
        const hasTts = fs.existsSync(ttsPath) && (tool === 'recap' || tool === 'dubbing');
        if (hasTts) {
          await validateAudibleSpeechFile(ttsPath, 'Render TTS Audio Validation');
        }
        const isDurationLockedDubbing =
          tool === 'dubbing' &&
          hasTts &&
          (timelineSegments.length === 0 ||
            timelineSegments.every((s) => Math.abs((s.setptsFactor ?? 1.0) - 1.0) < 0.002));

        let autoSilenceCutConfig: AutoSilenceCutConfig = {
          ...DEFAULT_AUTO_SILENCE_CUT_CONFIG,
          enabled: true,
        };
        if (typeof req.body?.autoSilenceCutConfig === 'string' && req.body.autoSilenceCutConfig.trim()) {
          try {
            autoSilenceCutConfig = sanitizeAutoSilenceCutConfig({
              ...JSON.parse(req.body.autoSilenceCutConfig),
              enabled: true,
            });
          } catch {
            autoSilenceCutConfig = { ...DEFAULT_AUTO_SILENCE_CUT_CONFIG, enabled: true };
          }
        }
        let silenceCutPlan: SilenceCutPlan | null = null;
        if (meta.hasAudio) {
          const detectedSilences = await detectAudioSilencesWithConfig(
            sourcePath,
            autoSilenceCutConfig.noiseThresholdDb,
            autoSilenceCutConfig.minSilenceDuration
          );
          silenceCutPlan = computeKeepAudioSegmentsFromSilences(
            meta.duration,
            detectedSilences,
            autoSilenceCutConfig
          );
          // Protect active dubbed Burmese speech intervals so Auto Silence Cut NEVER chops spoken words!
          if (isDurationLockedDubbing && silenceCutPlan?.didCut) {
            const dubbedSpeechIntervals = timelineSegments
              .filter((s) => s.kind === 'speaking' && (s.aiVoiceDuration ?? 0) > 0)
              .map((s) => ({
                start: s.outputStart ?? s.start,
                end: s.outputEnd ?? s.end,
              }));
            if (dubbedSpeechIntervals.length > 0) {
              silenceCutPlan = protectSpeechIntervalsInKeptSegments(
                silenceCutPlan.keptSegments,
                dubbedSpeechIntervals,
                meta.duration
              );
            }
          }
        }

        const effectiveCaptions =
          silenceCutPlan?.didCut && tool !== 'recap'
            ? remapCaptionsForSilenceCut(captions, silenceCutPlan.keptSegments)
            : captions;
        const effectiveBurnSubtitles = shouldBurnSubtitlesInRender(captionsEnabled, effectiveCaptions);

        // Generate ASS subtitle file only when captions burn-in is enabled and non-empty
        const assPath = path.join(dir, 'captions.ass');
        if (effectiveBurnSubtitles) {
          const assContent = generateAssSubtitles(
            effectiveCaptions,
            outWidth,
            outHeight,
            subPos,
            captionDecoration
          );
          fs.writeFileSync(assPath, assContent, 'utf8');
        }

        // Build silence-preserving FFmpeg render graph
        const inputs: string[] = ['-y', '-i', sourcePath];
        let nextInputIdx = 1;

        let logoIdx = -1;
        if (logoEnabled && logoFile && fs.existsSync(logoFile.path)) {
          inputs.push('-i', logoFile.path);
          logoIdx = nextInputIdx++;
        }

        // ONLY legacy non-1.0x timelines use segmented video trim/concat;
        // duration-locked dubbing preserves 100% original video speed (1.0x) and exact original duration!
        const useSegmentedRender =
          !isDurationLockedDubbing &&
          tool === 'dubbing' &&
          hasTts &&
          timelineSegments.length > 0 &&
          timelineSegments.some(
            (s) => s.kind === 'speaking' && fs.existsSync(path.join(dir, `tts_${s.id}.wav`))
          );

        const filterParts: string[] = [];
        const escapedAssPath = assPath.replace(/\\/g, '/').replace(/:/g, '\\:');

        let dur = Math.max(0.5, meta.duration);
        let joinedAudioLabel = '';
        let singleTtsIdx = -1;

        let autoBlurConfig = DEFAULT_AUTO_BLUR_CONFIG;
        if (typeof req.body?.autoBlurConfig === 'string' && req.body.autoBlurConfig.trim()) {
          try {
            autoBlurConfig = sanitizeAutoBlurConfig(JSON.parse(req.body.autoBlurConfig));
          } catch {
            autoBlurConfig = DEFAULT_AUTO_BLUR_CONFIG;
          }
        }
        let autoBlurRegions: AutoBlurRegion[] = [];
        if (typeof req.body?.autoBlurRegions === 'string' && req.body.autoBlurRegions.trim()) {
          try {
            autoBlurRegions = sanitizeAutoBlurRegions(JSON.parse(req.body.autoBlurRegions));
          } catch {
            autoBlurRegions = [];
          }
        } else {
          const cachedBlurPath = path.join(dir, 'auto_blur_regions.json');
          if (fs.existsSync(cachedBlurPath)) {
            try {
              autoBlurRegions = sanitizeAutoBlurRegions(
                JSON.parse(fs.readFileSync(cachedBlurPath, 'utf8'))
              );
            } catch {
              autoBlurRegions = [];
            }
          }
        }

        let cutAudioLabel = '';

        if (isDurationLockedDubbing) {
          // Duration-locked Myanmar Dubbing: keep 1.0x speed (and optionally trim silent windows identically on video + TTS)
          inputs.push('-i', ttsPath);
          singleTtsIdx = nextInputIdx++;

          let preScaleLabel = '[v_timed]';
          if (silenceCutPlan?.didCut) {
            dur = Math.max(0.5, silenceCutPlan.trimmedDuration);
            filterParts.push(
              ...buildSilenceCutFfmpegFilter({
                keptSegments: silenceCutPlan.keptSegments,
                includeSourceAudio: false,
                externalAudioInputLabel: `[${singleTtsIdx}:a]`,
                videoInputLabel: '[0:v]',
                outVideoLabel: '[v_timed]',
                outExternalAudioLabel: '[a_tts_cut]',
              })
            );
            joinedAudioLabel = '[a_tts_cut]';
          } else {
            dur = Math.max(0.5, meta.duration);
            filterParts.push(`[0:v]format=yuv420p,setsar=1[v_timed]`);
          }

          const blurFilters = buildAutoBlurFfmpegFilter({
            inputLabel: preScaleLabel,
            outputLabel: '[v_blurred]',
            videoWidth: meta.width,
            videoHeight: meta.height,
            regions: autoBlurRegions,
            config: autoBlurConfig,
          });
          if (blurFilters.length > 0) {
            filterParts.push(...blurFilters);
            preScaleLabel = '[v_blurred]';
          }

          filterParts.push(
            `${preScaleLabel}scale=${outWidth}:${outHeight}:force_original_aspect_ratio=decrease,pad=${outWidth}:${outHeight}:(ow-iw)/2:(oh-ih)/2:color=#090b10,setsar=1${effectiveBurnSubtitles ? `,subtitles='${escapedAssPath}'` : ''}[v_sub]`
          );
        } else if (useSegmentedRender) {
          // Segmented render: speed-adjust ONLY speaking segments to match per-segment AI voice;
          // optionally drop silent segments when Auto Silence Cut is enabled!
          const speakingOnlySegs = silenceCutPlan?.didCut
            ? timelineSegments.filter((s) => s.kind === 'speaking')
            : timelineSegments;
          const activeTimelineSegments =
            speakingOnlySegs.length > 0 ? speakingOnlySegs : timelineSegments;
          const segCount = activeTimelineSegments.length;
          let computedTotalDur = 0;

          if (segCount === 1) {
            filterParts.push(`[0:v]fps=25,format=yuv420p,setsar=1[vin_0]`);
          } else {
            const splitLabels = activeTimelineSegments.map((_, i) => `[vin_${i}]`).join('');
            filterParts.push(`[0:v]fps=25,format=yuv420p,setsar=1,split=${segCount}${splitLabels}`);
          }

          const concatPairs: string[] = [];
          for (let i = 0; i < segCount; i++) {
            const seg = activeTimelineSegments[i];
            const safeMaxStart = Math.max(0, meta.duration - 0.25);
            const segStart = Math.max(0, Math.min(safeMaxStart, Number(seg.start || 0)));
            const segEnd = Math.min(meta.duration, Math.max(segStart + 0.2, Number(seg.end || meta.duration)));
            const origSegDur = Math.max(0.2, segEnd - segStart);
            const segWav = path.join(dir, `tts_${seg.id}.wav`);

            if (seg.kind === 'speaking' && fs.existsSync(segWav)) {
              const voiceDur = await probeAudioDuration(segWav);
              const setpts = Math.min(10.0, Math.max(0.1, voiceDur / origSegDur));
              const segInputIdx = nextInputIdx++;
              inputs.push('-i', segWav);

              filterParts.push(
                `[vin_${i}]trim=start=${segStart.toFixed(3)}:end=${segEnd.toFixed(3)},setpts=${setpts.toFixed(6)}*(PTS-STARTPTS),fps=25[sv_${i}]`
              );
              filterParts.push(
                `[${segInputIdx}:a]aresample=48000,aformat=channel_layouts=mono,asetpts=PTS-STARTPTS,apad=whole_dur=${voiceDur.toFixed(3)},atrim=0:${voiceDur.toFixed(3)}[sa_${i}]`
              );
              computedTotalDur += voiceDur;
            } else {
              // SILENCE SEGMENT: 1.0x original playback speed + completely empty AI voice!
              filterParts.push(
                `[vin_${i}]trim=start=${segStart.toFixed(3)}:end=${segEnd.toFixed(3)},setpts=PTS-STARTPTS,fps=25[sv_${i}]`
              );
              filterParts.push(
                `anullsrc=r=48000:cl=mono:d=${origSegDur.toFixed(3)}[sa_${i}]`
              );
              computedTotalDur += origSegDur;
            }
            concatPairs.push(`[sv_${i}][sa_${i}]`);
          }

          dur = Math.max(0.5, computedTotalDur);

          let joinedVideoLabel = '[v_joined]';
          if (segCount === 1) {
            joinedVideoLabel = '[sv_0]';
            filterParts.push(`[sa_0]acopy[a_tts]`);
          } else {
            filterParts.push(
              `${concatPairs.join('')}concat=n=${segCount}:v=1:a=1[v_joined][a_tts]`
            );
          }

          const blurFilters = buildAutoBlurFfmpegFilter({
            inputLabel: joinedVideoLabel,
            outputLabel: '[v_blurred]',
            videoWidth: meta.width,
            videoHeight: meta.height,
            regions: autoBlurRegions,
            config: autoBlurConfig,
          });
          let preScaleLabel = joinedVideoLabel;
          if (blurFilters.length > 0) {
            filterParts.push(...blurFilters);
            preScaleLabel = '[v_blurred]';
          }

          filterParts.push(
            `${preScaleLabel}scale=${outWidth}:${outHeight}:force_original_aspect_ratio=decrease,pad=${outWidth}:${outHeight}:(ow-iw)/2:(oh-ih)/2:color=#090b10,setsar=1${effectiveBurnSubtitles ? `,subtitles='${escapedAssPath}'` : ''}[v_sub]`
          );
          joinedAudioLabel = '[a_tts]';
        } else {
          // Recap / Caption-only single-stream path (with optional Auto Silence Cut trim + concat)
          let aiVoiceDuration = 0;
          if (hasTts) {
            inputs.push('-i', ttsPath);
            singleTtsIdx = nextInputIdx++;
            aiVoiceDuration = await probeAudioDuration(ttsPath);
          }

          let sourceDurForSync = meta.duration;
          let videoInputForTiming = '[0:v]';
          let alreadyNormalizedCut = false;

          if (silenceCutPlan?.didCut) {
            const needsSrcAudio = tool === 'captions' && meta.hasAudio;
            filterParts.push(
              ...buildSilenceCutFfmpegFilter({
                keptSegments: silenceCutPlan.keptSegments,
                includeSourceAudio: needsSrcAudio,
                videoInputLabel: '[0:v]',
                outVideoLabel: '[v_cut]',
                outAudioLabel: '[a_cut]',
              })
            );
            sourceDurForSync = silenceCutPlan.trimmedDuration;
            videoInputForTiming = '[v_cut]';
            alreadyNormalizedCut = true;
            if (needsSrcAudio) {
              cutAudioLabel = '[a_cut]';
            }
          }

          const videoSyncPlan = hasTts
            ? computeVideoSpeedSyncPlan(sourceDurForSync, aiVoiceDuration)
            : null;
          dur = videoSyncPlan ? videoSyncPlan.aiVoiceDuration : Math.max(0.5, sourceDurForSync);

          // Normalize pixel format & SAR consistently before Auto Blur crop/boxblur/overlay
          let preScaleLabel = '[v_timed]';
          if (videoSyncPlan) {
            filterParts.push(
              `${videoInputForTiming}setpts=${videoSyncPlan.setptsFactor.toFixed(6)}*PTS,fps=25,format=yuv420p,setsar=1[v_timed]`
            );
          } else if (alreadyNormalizedCut) {
            preScaleLabel = '[v_cut]';
          } else {
            filterParts.push(`[0:v]format=yuv420p,setsar=1[v_timed]`);
          }

          const blurFilters = buildAutoBlurFfmpegFilter({
            inputLabel: preScaleLabel,
            outputLabel: '[v_blurred]',
            videoWidth: meta.width,
            videoHeight: meta.height,
            regions: autoBlurRegions,
            config: autoBlurConfig,
          });
          if (blurFilters.length > 0) {
            filterParts.push(...blurFilters);
            preScaleLabel = '[v_blurred]';
          }

          filterParts.push(
            `${preScaleLabel}scale=${outWidth}:${outHeight}:force_original_aspect_ratio=decrease,pad=${outWidth}:${outHeight}:(ow-iw)/2:(oh-ih)/2:color=#090b10,setsar=1${effectiveBurnSubtitles ? `,subtitles='${escapedAssPath}'` : ''}[v_sub]`
          );
        }

        // Synthesize smooth ambient BGM bed matching final combined duration
        let bgmIdx = -1;
        const safeCrossfade = Math.min(crossfadeSec, Math.max(0.2, dur * 0.4));
        if (musicMood !== 'none' && tool !== 'captions') {
          const bgmPath = path.join(dir, 'bgm_bed.wav');
          const baseFreq = musicMood === 'thriller' ? 98 : musicMood === 'action' ? 130.8 : 110;
          const harmFreq = musicMood === 'thriller' ? 146.8 : musicMood === 'action' ? 196 : 164.8;
          await execFileAsync('ffmpeg', [
            '-y',
            '-f',
            'lavfi',
            '-i',
            `sine=frequency=${baseFreq}:duration=${dur.toFixed(3)}`,
            '-f',
            'lavfi',
            '-i',
            `sine=frequency=${harmFreq}:duration=${dur.toFixed(3)}`,
            '-filter_complex',
            `[0:a]volume=0.14[a0];[1:a]volume=0.09[a1];[a0][a1]amix=inputs=2:duration=first,lowpass=f=650,afade=t=in:st=0:d=${safeCrossfade.toFixed(2)},afade=t=out:st=${Math.max(0.1, dur - safeCrossfade).toFixed(2)}:d=${safeCrossfade.toFixed(2)}[out]`,
            '-map',
            '[out]',
            bgmPath,
          ]);
          inputs.push('-i', bgmPath);
          bgmIdx = nextInputIdx++;
        }

        // Optional subtle transition SFX chime/whoosh at midpoint
        let sfxIdx = -1;
        if (sfxEnabled && tool === 'recap' && dur >= 2) {
          const sfxPath = path.join(dir, 'sfx_bed.wav');
          const mid = Math.max(0.6, Math.min(dur - 0.95, dur / 2));
          await execFileAsync('ffmpeg', [
            '-y',
            '-f',
            'lavfi',
            '-i',
            `anoisesrc=color=pink:duration=0.9`,
            '-filter_complex',
            `[0:a]bandpass=f=480:width_type=h:w=320,afade=t=in:st=0:d=0.35,afade=t=out:st=0.45:d=0.45,volume=0.18,adelay=${Math.round(mid * 1000)}|${Math.round(mid * 1000)},apad=whole_dur=${dur.toFixed(3)},atrim=0:${dur.toFixed(3)}[out]`,
            '-map',
            '[out]',
            sfxPath,
          ]);
          inputs.push('-i', sfxPath);
          sfxIdx = nextInputIdx++;
        }

        let finalVideoLabel = 'v_sub';
        if (logoIdx >= 0) {
          const logoWidthPx = Math.round((logoScale / 100) * outWidth);
          const lx = `max(12\\,min(W-w-12\\,${Math.round((logoPos.x / 100) * outWidth)}-w/2))`;
          const ly = `max(12\\,min(H-h-12\\,${Math.round((logoPos.y / 100) * outHeight)}-h/2))`;
          filterParts.push(`[${logoIdx}:v]scale=${logoWidthPx}:-1[logo_scaled]`);
          filterParts.push(`[v_sub][logo_scaled]overlay=x=${lx}:y=${ly}[v_out]`);
          finalVideoLabel = 'v_out';
        }

        // Smooth Audio Crossfade & Ducking Pipeline synced to final combined timeline
        let finalAudioLabel = '';
        if (tool === 'captions') {
          if (meta.hasAudio) {
            const srcAudio = cutAudioLabel || '[0:a]';
            filterParts.push(`${srcAudio}afade=t=in:st=0:d=0.25,afade=t=out:st=${Math.max(0.1, dur - 0.35).toFixed(2)}:d=0.35,atrim=0:${dur.toFixed(3)}[a_out]`);
            finalAudioLabel = 'a_out';
          }
        } else {
          const audioMixInputs: string[] = [];
          if (joinedAudioLabel) {
            audioMixInputs.push(joinedAudioLabel);
          } else if (hasTts && singleTtsIdx >= 0) {
            filterParts.push(`[${singleTtsIdx}:a]aresample=48000,afade=t=in:st=0:d=0.03,apad=whole_dur=${dur.toFixed(3)},atrim=0:${dur.toFixed(3)}[a_tts]`);
            audioMixInputs.push('[a_tts]');
          }
          if (bgmIdx >= 0) {
            const bgmGain = hasTts ? 0.28 : 0.75;
            filterParts.push(`[${bgmIdx}:a]aresample=48000,volume=${bgmGain},atrim=0:${dur.toFixed(3)}[a_bgm]`);
            audioMixInputs.push('[a_bgm]');
          }
          if (sfxIdx >= 0) {
            filterParts.push(`[${sfxIdx}:a]aresample=48000,atrim=0:${dur.toFixed(3)}[a_sfx]`);
            audioMixInputs.push('[a_sfx]');
          }
          if (audioMixInputs.length === 0 && meta.hasAudio) {
            filterParts.push(`[0:a]aresample=48000,afade=t=in:st=0:d=0.25,atrim=0:${dur.toFixed(3)}[a_out]`);
            finalAudioLabel = 'a_out';
          } else if (audioMixInputs.length === 1) {
            filterParts.push(`${audioMixInputs[0]}acopy[a_out]`);
            finalAudioLabel = 'a_out';
          } else if (audioMixInputs.length > 1) {
            filterParts.push(
              `${audioMixInputs.join('')}amix=inputs=${audioMixInputs.length}:duration=longest:dropout_transition=${safeCrossfade.toFixed(2)},dynaudnorm=f=150:g=15,atrim=0:${dur.toFixed(3)}[a_out]`
            );
            finalAudioLabel = 'a_out';
          }
        }

        const outputPath = path.join(dir, `final_${resolution}.mp4`);
        const ffmpegArgs = [
          ...inputs,
          '-filter_complex',
          filterParts.join(';'),
          '-map',
          `[${finalVideoLabel}]`,
          ...(finalAudioLabel ? ['-map', `[${finalAudioLabel}]`, '-c:a', 'aac', '-b:a', '192k'] : ['-an']),
          '-c:v',
          'libx264',
          '-preset',
          resolution === '4k' ? 'ultrafast' : 'veryfast',
          '-crf',
          resolution === '4k' ? '20' : '21',
          '-pix_fmt',
          'yuv420p',
          '-t',
          dur.toFixed(3),
          '-movflags',
          '+faststart',
          outputPath,
        ];

        await execFileAsync('ffmpeg', ffmpegArgs);

        // Save or generate content-driven thumbnail preserving exact chosen platform aspect ratio
        const thumbPath = path.join(dir, 'thumbnail.jpg');
        const thumbScaleCrop = `scale=${thumbDims.width}:${thumbDims.height}:force_original_aspect_ratio=increase,crop=${thumbDims.width}:${thumbDims.height}`;
        if (uploadedThumb && fs.existsSync(uploadedThumb.path)) {
          await execFileAsync('ffmpeg', [
            '-y',
            '-i',
            uploadedThumb.path,
            '-vf',
            thumbScaleCrop,
            '-q:v',
            '2',
            thumbPath,
          ]);
        } else {
          try {
            await execFileAsync('ffmpeg', [
              '-y',
              '-ss',
              String(Math.min(2, dur * 0.25)),
              '-i',
              outputPath,
              '-vframes',
              '1',
              '-vf',
              thumbScaleCrop,
              '-q:v',
              '2',
              thumbPath,
            ]);
          } catch {
            // Fallback to first keyframe if mid-video seek missed a frame on short renders
            await execFileAsync('ffmpeg', [
              '-y',
              '-i',
              outputPath,
              '-vframes',
              '1',
              '-vf',
              thumbScaleCrop,
              '-q:v',
              '2',
              thumbPath,
            ]);
          }
        }

        res.json({
          outputVideoUrl: `/api/session/${sessionId}/file/final_${resolution}.mp4`,
          thumbnailUrl: `/api/session/${sessionId}/file/thumbnail.jpg?v=${Date.now()}`,
          thumbnailTitle,
          thumbnailAspectRatio,
          resolution,
          silenceCutPlan,
        });
      } catch (error) {
        console.error('Render error:', error);
        res.status(500).json({ errorMy: 'ဗီဒီယို အပြီးသတ်ထုတ်လုပ်ရာတွင် အမှားဖြစ်ပွားပါသည်' });
      }
    }
  );

  // 9b. Fast Thumbnail Update Endpoint (updates saved thumbnail.jpg when user switches aspect ratio in Step 6)
  app.post('/api/render-thumbnail', upload.single('thumbnail'), async (req: Request, res: Response) => {
    try {
      const sessionId = String(req.body?.sessionId || '');
      if (!sessionId || !req.file) {
        res.status(400).json({ errorMy: 'Thumbnail ဖိုင် သို့မဟုတ် Session ID မတွေ့ပါ' });
        return;
      }
      const dir = getSessionDir(sessionId);
      const thumbnailAspectRatio = normalizeThumbnailAspectRatio(
        typeof req.body?.thumbnailAspectRatio === 'string' ? req.body.thumbnailAspectRatio : '16:9'
      );
      const thumbDims = getThumbnailDimensions(thumbnailAspectRatio);
      const thumbPath = path.join(dir, 'thumbnail.jpg');

      await execFileAsync('ffmpeg', [
        '-y',
        '-i',
        req.file.path,
        '-vf',
        `scale=${thumbDims.width}:${thumbDims.height}:force_original_aspect_ratio=increase,crop=${thumbDims.width}:${thumbDims.height}`,
        '-q:v',
        '2',
        thumbPath,
      ]);

      res.json({
        thumbnailUrl: `/api/session/${sessionId}/file/thumbnail.jpg?v=${Date.now()}`,
        thumbnailAspectRatio,
      });
    } catch (error) {
      console.error('Render thumbnail error:', error);
      res.status(500).json({ errorMy: 'Thumbnail ပုံ အသစ်ပြောင်းလဲရာတွင် အမှားဖြစ်ပွားပါသည်' });
    }
  });

  // 10. Step 10: Send finished video + viral thumbnail directly to user's Telegram bot
  app.post('/api/telegram/send', async (req: Request, res: Response) => {
    try {
      const botToken = getTelegramBotToken();
      if (!botToken) {
        res.status(400).json({
          missingKey: 'TELEGRAM_BOT_TOKEN',
          errorMy: 'TELEGRAM_BOT_TOKEN မသတ်မှတ်ရသေးပါ — Server Environment Variable တွင် ထည့်သွင်းပါ',
        });
        return;
      }

      const sessionId = String(req.body?.sessionId || '');
      const chatId = String(req.body?.chatId || '').trim();
      const resolution = (req.body?.resolution || '1080p') as ExportResolution;
      const thumbnailTitle = truncateThumbnailTitle(String(req.body?.thumbnailTitle || 'AlphaRecap Studio'));

      if (!sessionId || !chatId) {
        res.status(400).json({ errorMy: 'Telegram Chat ID ထည့်သွင်းပေးပါ' });
        return;
      }

      const dir = getSessionDir(sessionId);
      const videoPath = path.join(dir, `final_${resolution}.mp4`);
      const thumbPath = path.join(dir, 'thumbnail.jpg');

      if (!fs.existsSync(videoPath)) {
        res.status(404).json({ errorMy: 'ပေးပို့ရန် အပြီးသတ် ဗီဒီယိုဖိုင် မတွေ့သေးပါ — ဦးစွာ ဗီဒီယိုထုတ်လုပ်ပါ' });
        return;
      }

      // Send thumbnail photo first if available
      if (fs.existsSync(thumbPath)) {
        const thumbBytes = fs.readFileSync(thumbPath);
        const photoRes = await withTransientRetry(() => {
          const photoForm = new FormData();
          photoForm.append('chat_id', chatId);
          photoForm.append('caption', `🎬 ${thumbnailTitle}\n✨ AlphaRecap Studio မှ ဖန်တီးထားသော Viral Thumbnail`);
          photoForm.append('photo', new Blob([thumbBytes], { type: 'image/jpeg' }), 'thumbnail.jpg');
          return fetch(`https://api.telegram.org/bot${botToken}/sendPhoto`, {
            method: 'POST',
            body: photoForm,
          });
        });
        if (!photoRes.ok) {
          const errText = await photoRes.text();
          console.error('Telegram sendPhoto failed:', errText);
          res.status(400).json({ errorMy: 'Telegram သို့ Thumbnail ပို့ရာတွင် မအောင်မြင်ပါ — Chat ID နှင့် Bot /start လုပ်ထားမှု စစ်ဆေးပါ' });
          return;
        }
      }

      // Send finished MP4 video
      const videoBytes = fs.readFileSync(videoPath);
      const videoRes = await withTransientRetry(() => {
        const videoForm = new FormData();
        videoForm.append('chat_id', chatId);
        videoForm.append('caption', `🔥 ${thumbnailTitle} (${resolution.toUpperCase()})`);
        videoForm.append('supports_streaming', 'true');
        videoForm.append('video', new Blob([videoBytes], { type: 'video/mp4' }), `alpharecap_${resolution}.mp4`);
        return fetch(`https://api.telegram.org/bot${botToken}/sendVideo`, {
          method: 'POST',
          body: videoForm,
        });
      });

      if (!videoRes.ok) {
        const errText = await videoRes.text();
        console.error('Telegram sendVideo failed:', errText);
        res.status(400).json({ errorMy: 'Telegram သို့ ဗီဒီယိုပေးပို့ရာတွင် မအောင်မြင်ပါ — Chat ID မှန်ကန်ကြောင်း စစ်ဆေးပါ' });
        return;
      }

      res.json({
        ok: true,
        messageMy: 'ဗီဒီယိုနှင့် Viral Thumbnail ကို Telegram Bot သို့ အောင်မြင်စွာ ပေးပို့ပြီးပါပြီ!',
      });
    } catch (error) {
      console.error('Telegram send error:', error);
      res.status(500).json({ errorMy: 'Telegram ချိတ်ဆက်ပေးပို့ရာတွင် အမှားဖြစ်ပွားပါသည်' });
    }
  });

  // 11. Credit purchase confirmation (KBZPay MMK & PromptPay THB — one-time, never expires)
  app.post('/api/credits/purchase', (req: Request, res: Response) => {
    const packageId = String(req.body?.packageId || '');
    const paymentMethod = String(req.body?.paymentMethod || '');
    const referenceNo = String(req.body?.referenceNo || '').trim();

    const pkg = CREDIT_PACKAGES.find((p) => p.id === packageId);
    if (!pkg) {
      res.status(400).json({ errorMy: 'Credit Package ရွေးချယ်မှု မမှန်ကန်ပါ' });
      return;
    }
    if (paymentMethod !== 'kbzpay' && paymentMethod !== 'promptpay') {
      res.status(400).json({ errorMy: 'KBZPay သို့မဟုတ် PromptPay ငွေပေးချေမှုနည်းလမ်း ရွေးချယ်ပါ' });
      return;
    }
    if (referenceNo.length < 6) {
      res.status(400).json({ errorMy: 'ငွေလွှဲပြေစာ နံပါတ် (Transaction ID) အနည်းဆုံး ၆ လုံး ထည့်သွင်းပါ' });
      return;
    }

    res.json({
      ok: true,
      addedCredits: pkg.credits,
      packageName: pkg.nameMy,
      messageMy: `${pkg.credits} Credits ကို ဝယ်ယူဖြည့်သွင်းပြီးပါပြီ (သက်တမ်းကုန်ဆုံးခြင်း မရှိပါ)`,
    });
  });

  // 12. Immediate ephemeral cleanup when user closes or navigates away
  app.post('/api/session/cleanup', (req: Request, res: Response) => {
    const sessionId = String(req.body?.sessionId || req.query?.sessionId || '');
    cleanupSessionDir(sessionId);
    res.json({ ok: true });
  });

  // Structured JSON error middleware for /api/* (e.g. Multer errors never leak HTML 500 pages)
  app.use('/api', (err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        res.status(413).json({ errorMy: 'ဗီဒီယိုဖိုင် အရွယ်အစား 2GB ထက် ကျော်လွန်နေပါသည်' });
        return;
      }
      res.status(400).json({ errorMy: `ဖိုင်တင်သွင်းမှု အမှား (${err.code}) — ထပ်မံကြိုးစားပါ` });
      return;
    }
    console.error('Unhandled /api error:', err);
    res.status(500).json({ errorMy: 'ဆာဗာ လုပ်ဆောင်ချက်အတွင်း အမှားဖြစ်ပွားပါသည်' });
  });

  // Serve Vite in dev or dist/ in production
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`AlphaRecap Studio server listening on http://localhost:${PORT}`);
  });
  server.requestTimeout = 0;
  server.headersTimeout = 120000;
}

startServer().catch((err) => {
  console.error('Failed to start AlphaRecap Studio server:', err);
  process.exit(1);
});

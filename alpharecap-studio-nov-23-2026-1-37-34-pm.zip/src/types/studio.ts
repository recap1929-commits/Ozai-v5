export type StudioTool = 'recap' | 'dubbing' | 'captions';

export type VoiceGender = 'male' | 'female';

export type TtsEngineId = 'edge-tts' | 'gemini-tts';

export type EdgeVoiceId = 'my-MM-NilarNeural' | 'my-MM-ThihaNeural';

export type MyanmarVoiceId =
  | 'street_bro'
  | 'thriller_narrator'
  | 'dramatic_story'
  | 'documentary_deep'
  | 'anime_energetic'
  | 'horror_whisper'
  | 'comedy_chill'
  | 'news_anchor'
  | 'romance_warm'
  | 'trailer_epic';

export interface GeminiFreeVoiceOption {
  id: MyanmarVoiceId;
  nameMy: string;
  tagMy: string;
  descMy: string;
  sampleTextMy: string;
  femaleDirective: string;
  maleDirective: string;
  preferExpressiveModel?: boolean;
}

export type WizardStep = 1 | 2 | 3 | 4 | 5 | 6;

export type VoiceSpeed = number | 'slow' | 'normal' | 'fast' | '2x';

export type CaptionAnimationStyle = 'pop' | 'glow' | 'slide';

export type CaptionFontSizePreset = 'small' | 'medium' | 'large';

export interface CaptionDecorationConfig {
  fontSizePreset: CaptionFontSizePreset;
  fontSizeScale: number; // 0.7..1.7
  textColor: string; // #RRGGBB
  borderEnabled: boolean;
  borderThickness: number; // 1..10
  borderColor: string; // #RRGGBB
  blurBgEnabled: boolean;
  blurIntensity: number; // 0..24 px
  bgOpacity: number; // 0..100 %
  bgColor: string; // #RRGGBB
  bgCornerRadius: number; // 0..28 px
}

export type AutoBlurStyle = 'blur' | 'pixelate' | 'solid';

export interface AutoBlurRegion {
  id: string;
  xPct: number; // 0..100 relative to original video width
  yPct: number; // 0..100 relative to original video height
  widthPct: number; // 0..100
  heightPct: number; // 0..100
  kind: 'text' | 'logo' | 'watermark' | 'graphic';
}

export interface AutoBlurConfig {
  enabled: boolean;
  strength: number; // 10..100
  style: AutoBlurStyle;
  solidColor: string; // #RRGGBB
}

export type MusicMood = 'thriller' | 'action' | 'emotional' | 'none';

export type ExportResolution = '1080p' | '4k';

export type ThumbnailAspectRatio = '16:9' | '9:16' | '1.91:1' | '1:1';

export type ThumbnailSubjectCategory =
  | 'person'
  | 'product'
  | 'food'
  | 'travel_scene'
  | 'tech_device'
  | 'action_moment'
  | 'surprising_scene';

export type ThumbnailTextPosition = 'top' | 'bottom';

export type ThumbnailAccentTheme = 'gold' | 'crimson' | 'electric_blue' | 'emerald';

export interface ThumbnailAnalysis {
  frameUrl: string;
  bestFrameIndex: number;
  frameTimestamp: number;
  subjectCategory: ThumbnailSubjectCategory;
  subjectLabelMy: string;
  subjectSummaryMy: string;
  headlineMy: string;
  focusX: number;
  focusY: number;
  textPosition: ThumbnailTextPosition;
  accentTheme: ThumbnailAccentTheme;
  aspectRatio: ThumbnailAspectRatio;
  usedVisionModel: boolean;
}

export type PaymentMethod = 'kbzpay' | 'promptpay';

export interface CaptionSegment {
  id: string;
  start: number;
  end: number;
  text: string;
  emoji: string;
  originalText?: string;
}

export type SceneAnalysisProvider = 'gemini' | 'groq';

export type RecapStoryStage =
  | 'opening_hook'
  | 'story_background'
  | 'character_intro'
  | 'main_conflict'
  | 'story_development'
  | 'important_dialogue'
  | 'twists_reveals'
  | 'climax'
  | 'full_ending';

export interface SceneSummary {
  index: number;
  timestamp: number;
  imageUrl: string;
  descriptionMy: string;
  provider?: SceneAnalysisProvider;
  sceneId?: string;
  startTime?: number;
  endTime?: number;
  characters?: string[];
  actions?: string[];
  dialogueRef?: string;
  storyEvent?: string;
}

export interface SceneAnalysisData {
  scenes: SceneSummary[];
  storyAnalysisMy: string;
  activeProvider?: SceneAnalysisProvider;
  providerStatusMy?: string;
  fallbackUsed?: boolean;
  groqVisionModel?: string | null;
  completedCount?: number;
  totalCount?: number;
  resumable?: boolean;
}

export interface OverlayPosition {
  x: number; // percentage 0..100
  y: number; // percentage 0..100
}

export interface CreditPackage {
  id: string;
  nameMy: string;
  credits: number;
  priceMmk: number;
  priceThb: number;
  descriptionMy: string;
}

export interface PipelineProgress {
  step: number;
  totalSteps: number;
  labelMy: string;
  percent: number;
}

export interface ServerCapabilities {
  ffmpegAvailable: boolean;
  ytDlpAvailable: boolean;
  geminiConfigured: boolean;
  groqConfigured: boolean;
  telegramConfigured: boolean;
  edgeTtsAvailable?: boolean;
  defaultTtsEngine?: TtsEngineId;
  defaultEdgeVoice?: EdgeVoiceId;
}

export type SegmentKind = 'speaking' | 'silence';

export interface TranscriptSegment {
  id: string;
  kind?: SegmentKind;
  start: number;
  end: number;
  text: string;
}

export interface VideoTimelineSegment {
  id: string;
  kind: SegmentKind;
  start: number;
  end: number;
  duration: number;
  text: string;
  myanmarText: string;
  emoji: string;
  voiceGender?: VoiceGender;
  aiVoiceDuration: number;
  setptsFactor: number;
  videoPlaybackRate: number;
  outputStart: number;
  outputEnd: number;
}

export interface AutoSilenceCutConfig {
  enabled: boolean;
  noiseThresholdDb: number; // -55 .. -18 dB
  minSilenceDuration: number; // 0.15 .. 3.0 s
  paddingSeconds: number; // 0 .. 0.3 s
}

export interface KeepAudioSegment {
  start: number;
  end: number;
  duration: number;
}

export interface SilenceCutPlan {
  keptSegments: KeepAudioSegment[];
  removedSilences: Array<{ start: number; end: number; duration: number; midpoint: number }>;
  originalDuration: number;
  trimmedDuration: number;
  removedDuration: number;
  didCut: boolean;
}

export interface RecapSceneMapping {
  beatId: string;
  sceneId: string;
  startTime: number;
  endTime: number;
  storyStage: RecapStoryStage;
  characterRefs: string[];
  storyEvent: string;
  narrationText: string;
  dialogueText?: string;
  narrationStart?: number;
  narrationEnd?: number;
  actualTtsDuration?: number;
  targetTtsDuration?: number;
  tempoApplied?: number;
  alignmentStatus?: 'aligned' | 'compressed_mild' | 'expanded_or_retimed' | 'overflow_warning' | 'missing_audio';
}

export type RecapQualityCheckKey =
  | 'story_accuracy'
  | 'character_consistency'
  | 'dialogue_integration'
  | 'scene_alignment'
  | 'timestamp_continuity'
  | 'tts_duration_target'
  | 'video_speed_lock'
  | 'full_ending'
  | 'burmese_quality';

export interface RecapQualityCheckItem {
  key: RecapQualityCheckKey;
  passed: boolean;
  severity: 'pass' | 'warning' | 'critical';
  messageMy: string;
}

export interface RecapQualityValidation {
  passed: boolean;
  canRender: boolean;
  score: number;
  originalVideoDuration: number;
  targetRecapDuration: number;
  actualTtsDuration: number;
  durationDiffSeconds: number;
  coverageRatio: number;
  videoSpeedLocked: number;
  fullEndingCovered: boolean;
  checks: RecapQualityCheckItem[];
  warnings: string[];
  criticalErrors: string[];
}

export interface SyncSummary {
  tool?: StudioTool;
  segmentCount: number;
  speakingSegmentCount?: number;
  silenceSegmentCount?: number;
  preservedSilenceDuration?: number;
  silenceCutRemovedSeconds?: number;
  silenceCutRemovedCount?: number;
  originalVideoDuration: number;
  aiVoiceDuration: number;
  finalVideoDuration?: number;
  videoPlaybackRate: number;
  voiceSpeed: VoiceSpeed;
  voiceGender?: VoiceGender;
  ttsEngine?: TtsEngineId;
  voiceId?: EdgeVoiceId;
  targetRecapDuration?: number;
  durationDiffSeconds?: number;
  durationExpandedPasses?: number;
  recapSceneMappings?: RecapSceneMapping[];
  qualityValidation?: RecapQualityValidation;
}



import type {
  RecapQualityCheckItem,
  RecapQualityValidation,
  RecapSceneMapping,
  RecapStoryStage,
  SceneSummary,
  VoiceSpeed,
} from '../types/studio';
import type { LockedVideoRecapScheduleResult, RecapBeat } from './audioSync';
import { resolveVoiceSpeedNumeric } from './audioSync';

export function computeRecapTargetDurationSeconds(videoDurationSeconds: number): number {
  const safe = Math.max(1, Number.isFinite(videoDurationSeconds) ? videoDurationSeconds : 12);
  return Number((safe * 0.9).toFixed(2));
}

export interface RecapGeneratedSegment {
  id: string;
  myanmarText: string;
  emoji: string;
}

export interface TimestampedTranscriptItem {
  start: number;
  end: number;
  text: string;
}

export interface VerifiedCharacterProfile {
  canonicalName: string;
  aliases: string[];
  roleOrRelation?: string;
  evidenceSource: 'transcript' | 'scene' | 'metadata';
}

export interface RecapMixedPromptInput {
  durationSeconds: number;
  transcript: string;
  timestampedSegments?: TimestampedTranscriptItem[];
  voiceStyleName: string;
  voiceStyleTag: string;
  voiceStyleDesc: string;
  speedNote: string;
  beatListText: string;
  beatCount: number;
  scenes?: SceneSummary[];
  storyAnalysisMy?: string;
  verifiedCharacters?: VerifiedCharacterProfile[];
}

export interface RecapDurationEstimate {
  estimatedDurationSeconds: number;
  targetDurationSeconds: number;
  coverageRatio: number;
  totalSyllables: number;
  perSegment: Array<{
    id: string;
    estimatedSeconds: number;
    targetSeconds: number;
    syllables: number;
    fillRatio: number;
  }>;
}

export interface RecapExpansionCandidate {
  beat: RecapBeat;
  currentText: string;
  currentEmoji: string;
  estimatedSeconds: number;
  targetSeconds: number;
  matchingTranscriptLines: string[];
  matchingSceneNotes: string[];
  previousBeatText: string;
  nextBeatText: string;
}

export interface RecapValidationResult {
  segments: RecapGeneratedSegment[];
  estimatedDurationSeconds: number;
  targetDurationSeconds: number;
  coverageRatio: number;
  dialogueLineCount: number;
  removedDuplicateCount: number;
  warnings: string[];
}

const MYANMAR_SYLLABLES_PER_SECOND = 4.5;
const ENGLISH_WORDS_PER_SECOND = 2.4;

function formatClock(sec: number): string {
  const safe = Math.max(0, Number.isFinite(sec) ? sec : 0);
  const mins = Math.floor(safe / 60);
  const rem = safe - mins * 60;
  return `${String(mins).padStart(2, '0')}:${rem.toFixed(2).padStart(5, '0')}`;
}

/**
 * Strips non-spoken structural labels (e.g. "Narration:", "Dialogue:") and markdown clutter
 * while preserving natural Burmese prose and quoted character dialogue.
 */
export function cleanRecapSpokenText(rawText: string): string {
  return String(rawText || '')
    .replace(/^(?:\*{0,2}(?:Narration|Dialogue|Voiceover|Storyteller|Host|Scene)\s*:\*{0,2}\s*)+/gim, '')
    .replace(/(?:^|\s)\*{0,2}(?:Narration|Dialogue|Voiceover|Storyteller)\s*:\*{0,2}\s*/gi, ' ')
    .replace(/\[(?:music|applause|laughter|silence|noise|sfx|sound)\]/gi, ' ')
    .replace(/[*_`~#<>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Counts Myanmar spoken syllables linguistically:
 * - Counts Myanmar consonants/independent vowels (U+1000..U+102A, U+103F, U+104E)
 *   excluding coda consonants with asat (U+103A) and stacked conjunct preceding virama (U+1039).
 * - Counts Myanmar digits and non-Myanmar alphanumeric words proportionally.
 */
export function countSpokenUnits(text: string): {
  myanmarSyllables: number;
  myanmarDigits: number;
  latinWords: number;
  sentencePauses: number;
} {
  const clean = cleanRecapSpokenText(text);
  if (!clean) {
    return { myanmarSyllables: 0, myanmarDigits: 0, latinWords: 0, sentencePauses: 0 };
  }

  let myanmarSyllables = 0;
  let myanmarDigits = 0;

  for (let i = 0; i < clean.length; i++) {
    const code = clean.charCodeAt(i);
    if (code >= 0x1040 && code <= 0x1049) {
      myanmarDigits += 1;
      continue;
    }
    const isBaseLetter =
      (code >= 0x1000 && code <= 0x102a) || code === 0x103f || code === 0x104e;
    if (!isBaseLetter) continue;

    const nextCode = i + 1 < clean.length ? clean.charCodeAt(i + 1) : 0;
    // Skip coda consonant killed by asat (်) or first consonant of stacked virama (္)
    if (nextCode === 0x103a || nextCode === 0x1039) {
      continue;
    }
    myanmarSyllables += 1;
  }

  const latinMatches = clean.match(/[A-Za-z0-9]+/g);
  const latinWords = latinMatches ? latinMatches.length : 0;

  const pauseMatches = clean.match(/[။!?]+|\.\s/g);
  const sentencePauses = Math.max(1, pauseMatches ? pauseMatches.length : 1);

  return { myanmarSyllables, myanmarDigits, latinWords, sentencePauses };
}

/**
 * Estimates spoken duration (seconds) for a Myanmar recap text snippet at a given VoiceSpeed.
 */
export function estimateMyanmarTextDurationSeconds(
  text: string,
  voiceSpeed: VoiceSpeed = 'normal'
): { estimatedSeconds: number; syllables: number } {
  const units = countSpokenUnits(text);
  const effectiveSyllables = units.myanmarSyllables + units.myanmarDigits * 1.4;
  if (effectiveSyllables === 0 && units.latinWords === 0) {
    return { estimatedSeconds: 0, syllables: 0 };
  }

  const baseSpeechSec =
    effectiveSyllables / MYANMAR_SYLLABLES_PER_SECOND +
    units.latinWords / ENGLISH_WORDS_PER_SECOND;
  const pauseSec = Math.min(2.5, units.sentencePauses * 0.22);
  const speedFactor = Math.max(0.5, resolveVoiceSpeedNumeric(voiceSpeed));

  const estimatedSeconds = Number(((baseSpeechSec + pauseSec) / speedFactor).toFixed(2));
  return {
    estimatedSeconds,
    syllables: Math.round(effectiveSyllables + units.latinWords * 2),
  };
}

/**
 * Evaluates how close generated recap segments come to the 90% target duration
 * (SOURCE VIDEO DURATION * 0.90), broken down per beat.
 */
export function estimateRecapNarrationCoverage(
  beats: RecapBeat[],
  segments: RecapGeneratedSegment[],
  videoDurationSeconds: number,
  voiceSpeed: VoiceSpeed = 'normal'
): RecapDurationEstimate {
  const safeVideoDur = Math.max(1, Number.isFinite(videoDurationSeconds) ? videoDurationSeconds : 12);
  const targetDurationSeconds = computeRecapTargetDurationSeconds(safeVideoDur);
  const segById = new Map(segments.map((s) => [s.id, s]));

  let totalEst = 0;
  let totalSyllables = 0;

  const perSegment = beats.map((beat, idx) => {
    const seg = segById.get(beat.id) || segments[idx];
    const text = seg?.myanmarText || '';
    const { estimatedSeconds, syllables } = estimateMyanmarTextDurationSeconds(text, voiceSpeed);
    const beatTargetSec = Number((beat.duration * 0.9).toFixed(2));
    totalEst += estimatedSeconds;
    totalSyllables += syllables;
    const fillRatio = beatTargetSec > 0 ? Number((estimatedSeconds / beatTargetSec).toFixed(3)) : 1;
    return {
      id: beat.id,
      estimatedSeconds,
      targetSeconds: beatTargetSec,
      syllables,
      fillRatio,
    };
  });

  const estimatedDurationSeconds = Number(totalEst.toFixed(2));
  const coverageRatio =
    targetDurationSeconds > 0
      ? Number((estimatedDurationSeconds / targetDurationSeconds).toFixed(3))
      : 1;

  return {
    estimatedDurationSeconds,
    targetDurationSeconds,
    coverageRatio,
    totalSyllables,
    perSegment,
  };
}

/**
 * Formats timestamped transcript segments cleanly for Gemini recap context,
 * preserving chronological timestamps and removing consecutive duplicate Whisper echoes.
 */
export function formatTimestampedTranscriptContext(
  rawSegments: TimestampedTranscriptItem[],
  durationSeconds: number,
  maxLines = 120
): string {
  if (!Array.isArray(rawSegments) || rawSegments.length === 0) return '';
  const safeDur = Math.max(1, Number.isFinite(durationSeconds) ? durationSeconds : 12);

  const cleaned = rawSegments
    .map((s) => ({
      start: Math.max(0, Math.min(safeDur, Number(s.start || 0))),
      end: Math.max(0, Math.min(safeDur, Number(s.end || safeDur))),
      text: String(s.text || '').replace(/\s+/g, ' ').trim(),
    }))
    .filter((s) => s.text.length > 0)
    .sort((a, b) => a.start - b.start);

  const deduped: TimestampedTranscriptItem[] = [];
  for (const item of cleaned) {
    const prev = deduped[deduped.length - 1];
    if (prev && prev.text.toLowerCase() === item.text.toLowerCase()) {
      prev.end = Math.max(prev.end, item.end);
      continue;
    }
    deduped.push(item);
  }

  const capped = deduped.slice(0, Math.max(1, maxLines));
  return capped
    .map((s) => `[${formatClock(s.start)} -> ${formatClock(s.end)}] "${s.text}"`)
    .join('\n');
}

/**
 * Detects whether a transcript contains meaningful spoken content vs placeholder/empty text.
 */
export function hasSubstantiveTranscript(
  transcript: string,
  segments?: TimestampedTranscriptItem[]
): boolean {
  const joined = [
    String(transcript || '').trim(),
    ...(Array.isArray(segments) ? segments.map((s) => String(s.text || '').trim()) : []),
  ]
    .join(' ')
    .replace(/Visual scene sequence|Scene part \d+ \([^)]*\)/gi, '')
    .replace(/[\p{P}\p{S}\s]/gu, '')
    .trim();
  return joined.length >= 8;
}

const NON_CHARACTER_CAPITALIZED_WORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'but', 'if', 'so', 'yet', 'for', 'nor', 'at', 'by', 'in', 'of', 'on', 'to', 'up',
  'wait', 'stop', 'look', 'listen', 'run', 'help', 'please', 'sorry', 'thanks', 'thank', 'yes', 'no', 'okay', 'ok',
  'hey', 'hi', 'hello', 'bye', 'goodbye', 'what', 'where', 'when', 'why', 'who', 'how', 'which', 'whose',
  'this', 'that', 'these', 'those', 'here', 'there', 'now', 'then', 'today', 'tonight', 'tomorrow', 'yesterday',
  'man', 'woman', 'sir', 'madam', 'maam', 'bro', 'dude', 'friend', 'guys', 'everybody', 'everyone', 'someone', 'nobody',
  'god', 'lord', 'scene', 'beat', 'narration', 'dialogue', 'narrator', 'voiceover', 'storyteller', 'speaker',
  'audio', 'music', 'sfx', 'note', 'video', 'uploaded', 'visual', 'unknown', 'suspect', 'detective', 'character',
]);

function isPlausibleCharacterToken(candidate: string): boolean {
  const clean = String(candidate || '').trim();
  if (clean.length < 2 || clean.length > 36) return false;
  const parts = clean.split(/\s+/);
  if (parts.length > 3) return false;
  if (parts.length === 1) {
    return !NON_CHARACTER_CAPITALIZED_WORDS.has(parts[0].toLowerCase());
  }
  // Allow titled multi-word names like "Detective Miller" while rejecting trailing stopwords
  return !NON_CHARACTER_CAPITALIZED_WORDS.has(parts[parts.length - 1].toLowerCase());
}

/**
 * Extracts ONLY evidence-backed character names, nicknames, professional titles/ranks,
 * honorifics, and relationships directly from the transcript, scenes, and metadata.
 * Never guesses or invents unverified identities.
 */
export function extractVerifiedCharacterClues(params: {
  transcript?: string;
  timestampedSegments?: TimestampedTranscriptItem[];
  scenes?: SceneSummary[];
  storyAnalysisMy?: string;
  videoTitle?: string;
  explicitCharacters?: Array<string | { canonicalName?: string; aliases?: string[]; roleOrRelation?: string }>;
}): VerifiedCharacterProfile[] {
  const {
    transcript = '',
    timestampedSegments = [],
    scenes = [],
    storyAnalysisMy = '',
    videoTitle = '',
    explicitCharacters = [],
  } = params;

  const profileMap = new Map<string, VerifiedCharacterProfile>();

  const registerProfile = (
    rawName: string,
    evidenceSource: VerifiedCharacterProfile['evidenceSource'],
    roleOrRelation?: string,
    extraAliases: string[] = []
  ) => {
    const clean = String(rawName || '').replace(/\s+/g, ' ').trim();
    if (!clean || !isPlausibleCharacterToken(clean)) return;
    const key = clean.toLowerCase();
    const existing = profileMap.get(key);
    if (existing) {
      for (const al of extraAliases) {
        const a = String(al || '').trim();
        if (a && a.toLowerCase() !== key && !existing.aliases.includes(a)) {
          existing.aliases.push(a);
        }
      }
      if (!existing.roleOrRelation && roleOrRelation) {
        existing.roleOrRelation = roleOrRelation;
      }
      return;
    }
    profileMap.set(key, {
      canonicalName: clean,
      aliases: extraAliases.filter((a) => String(a || '').trim() && a.toLowerCase() !== key),
      ...(roleOrRelation ? { roleOrRelation } : {}),
      evidenceSource,
    });
  };

  for (const item of explicitCharacters) {
    if (typeof item === 'string') {
      registerProfile(item, 'metadata');
    } else if (item && typeof item === 'object' && item.canonicalName) {
      registerProfile(
        item.canonicalName,
        'metadata',
        item.roleOrRelation,
        Array.isArray(item.aliases) ? item.aliases : []
      );
    }
  }

  const transcriptCorpus = [
    transcript,
    ...timestampedSegments.map((s) => s.text),
  ]
    .filter(Boolean)
    .join('\n');

  if (transcriptCorpus.trim()) {
    // 1. Explicit speaker turns: "Marcus: ..." or "Dr. Lin: ..."
    const speakerRe = /(?:^|\n)\s*((?:(?:Detective|Inspector|Captain|Officer|Sergeant|Dr\.?|Doctor|Prof\.?|Professor|Agent|Chief|Mr\.?|Mrs\.?|Ms\.?|Miss|Uncle|Aunt|Boss)\s+)?[A-Z][a-zA-Z]{1,18}(?:\s+[A-Z][a-zA-Z]{1,18})?)\s*:\s+/g;
    for (const m of transcriptCorpus.matchAll(speakerRe)) {
      registerProfile(m[1], 'transcript');
    }

    // 2. Titled character names in dialogue: "Detective Miller", "Captain Park", "Dr. Chen", "Uncle Ben"
    const titledRe = /\b(Detective|Inspector|Captain|Officer|Sergeant|Doctor|Dr\.?|Professor|Prof\.?|Agent|Chief|Mr\.?|Mrs\.?|Ms\.?|Miss|Uncle|Aunt|Brother|Sister|Boss|Master|King|Queen|Prince|Princess)\s+([A-Z][a-zA-Z]{1,18})\b/g;
    for (const m of transcriptCorpus.matchAll(titledRe)) {
      const fullTitled = `${m[1]} ${m[2]}`.replace(/\s+/g, ' ').trim();
      registerProfile(fullTitled, 'transcript', m[1], [m[2]]);
    }

    // 3. Direct vocatives in dialogue: "Wait, Elena!" / "Listen to me, Marcus." / "Hey Sarah, ..."
    const trailingVocativeRe = /,\s*([A-Z][a-zA-Z]{2,15})(?=[!?.])/g;
    for (const m of transcriptCorpus.matchAll(trailingVocativeRe)) {
      registerProfile(m[1], 'transcript');
    }
    const leadingVocativeRe = /(?:^|[.!?]\s+)(?:Hey|Hi|Wait|Stop|Listen|Look|Run|Careful|Sorry|Please|Tell me),?\s+([A-Z][a-zA-Z]{2,15})(?=[,!?.])/g;
    for (const m of transcriptCorpus.matchAll(leadingVocativeRe)) {
      registerProfile(m[1], 'transcript');
    }
  }

  // 4. Titled or explicit English proper names appearing in verified scene descriptions / story overview
  const sceneCorpus = [
    ...scenes.map((s) => String(s.descriptionMy || '')),
    String(storyAnalysisMy || ''),
    String(videoTitle || ''),
  ]
    .filter(Boolean)
    .join('\n');

  if (sceneCorpus.trim()) {
    const sceneNamedRe = /\b([A-Z][a-zA-Z]{2,16}(?:\s+[A-Z][a-zA-Z]{2,16})?)\b/g;
    for (const m of sceneCorpus.matchAll(sceneNamedRe)) {
      const candidate = m[1].trim();
      if (!NON_CHARACTER_CAPITALIZED_WORDS.has(candidate.toLowerCase()) && !/^(Midnight|Overpass|Studio|AlphaRecap|Part)$/i.test(candidate)) {
        // Only register capitalized tokens from scene notes if also seen in transcript OR explicitly preceded by role/title
        if (transcriptCorpus.toLowerCase().includes(candidate.toLowerCase())) {
          registerProfile(candidate, 'scene');
        }
      }
    }
  }

  return Array.from(profileMap.values()).slice(0, 12);
}

/**
 * Formats verified characters and forms of address for Movie Recap prompts.
 */
export function formatCharacterRosterPromptBlock(profiles: VerifiedCharacterProfile[]): string {
  if (!Array.isArray(profiles) || profiles.length === 0) return '';
  const lines = profiles.map((p) => {
    const aliasText = p.aliases.length > 0 ? ` | aliases/address: ${p.aliases.join(', ')}` : '';
    const roleText = p.roleOrRelation ? ` | title/role: ${p.roleOrRelation}` : '';
    return `- "${p.canonicalName}"${roleText}${aliasText} (verified from ${p.evidenceSource})`;
  });
  return `Verified Character Names & Forms of Address (use consistently instead of generic "သူ/သူမ/သူတို့/အဲဒီလူ"):\n${lines.join('\n')}`;
}

export const RECAP_STORY_STAGE_LABELS: Record<RecapStoryStage, { en: string; my: string }> = {
  opening_hook: { en: '1. Opening Hook', my: '၁။ အစပိုင်း ဆွဲဆောင်မှု' },
  story_background: { en: '2. Story Background', my: '၂။ ဇာတ်လမ်းနောက်ခံ' },
  character_intro: { en: '3. Character Introduction', my: '၃။ ဇာတ်ကောင်မိတ်ဆက်' },
  main_conflict: { en: '4. Main Conflict', my: '၄။ အဓိက ပဋိပက္ခ' },
  story_development: { en: '5. Detailed Story Development', my: '၅။ ဇာတ်လမ်းအသေးစိတ် တိုးတက်မှု' },
  important_dialogue: { en: '6. Important Character Dialogues', my: '၆။ အရေးပါသော စကားပြောခန်းများ' },
  twists_reveals: { en: '7. Twists and Reveals', my: '၇။ အလှည့်အပြောင်းနှင့် ဖော်ထုတ်ချက်များ' },
  climax: { en: '8. Climax', my: '၈။ အထွတ်အထိပ် အခန်း' },
  full_ending: { en: '9. Full Ending and Resolution', my: '၉။ ဇာတ်သိမ်းအပြည့်အစုံ' },
};

export function assignRecapStoryStages(beats: RecapBeat[]): RecapStoryStage[] {
  const count = beats.length;
  return beats.map((b, idx) => {
    if (b.storyStage) return b.storyStage;
    if (count <= 1 || idx === count - 1) return 'full_ending';
    if (idx === 0) return 'opening_hook';
    if (count === 2) return 'full_ending';
    const ratio = idx / (count - 1);
    if (ratio < 0.14) return 'story_background';
    if (ratio < 0.25) return 'character_intro';
    if (ratio < 0.38) return 'main_conflict';
    if (ratio < 0.56) return 'story_development';
    if (ratio < 0.7) return 'important_dialogue';
    if (ratio < 0.84) return 'twists_reveals';
    return 'climax';
  });
}

/**
 * Builds the upgraded MIXED (Professional Narration + Important Character Dialogues)
 * DETAILED + FULL ENDING Movie Recap prompt with preserved transcript timestamps,
 * scene-locked IDs/timecodes, TARGET_WORDS (never MAX_WORDS), 90% duration targeting,
 * 1.0x locked video speed pacing, character identity consistency rules, and anti-hallucination guards.
 */
export function buildRecapMixedNarrationPrompt(input: RecapMixedPromptInput): {
  systemInstruction: string;
  prompt: string;
  targetDurationSeconds: number;
} {
  const targetDurationSeconds = computeRecapTargetDurationSeconds(input.durationSeconds);

  const sceneContextText =
    Array.isArray(input.scenes) && input.scenes.length > 0
      ? input.scenes
          .slice(0, 28)
          .map((sc, i) => {
            const sceneTag = sc.sceneId || `scene_${i + 1}`;
            const windowStr =
              typeof sc.startTime === 'number' && typeof sc.endTime === 'number'
                ? `${formatClock(sc.startTime)} -> ${formatClock(sc.endTime)}`
                : formatClock(Number(sc.timestamp || 0));
            const charTag =
              Array.isArray(sc.characters) && sc.characters.length > 0
                ? ` | characters: ${sc.characters.join(', ')}`
                : '';
            const actTag =
              Array.isArray(sc.actions) && sc.actions.length > 0
                ? ` | actions: ${sc.actions.join(', ')}`
                : '';
            const dlgTag = sc.dialogueRef ? ` | dialogueRef: "${sc.dialogueRef}"` : '';
            return `- [${sceneTag} | ${windowStr}] ${String(sc.storyEvent || sc.descriptionMy || '').trim()}${charTag}${actTag}${dlgTag}`;
          })
          .join('\n')
      : '';

  const timestampedTranscript =
    Array.isArray(input.timestampedSegments) && input.timestampedSegments.length > 0
      ? formatTimestampedTranscriptContext(input.timestampedSegments, input.durationSeconds)
      : '';

  const verifiedCharacters =
    Array.isArray(input.verifiedCharacters) && input.verifiedCharacters.length > 0
      ? input.verifiedCharacters
      : extractVerifiedCharacterClues({
          transcript: input.transcript,
          timestampedSegments: input.timestampedSegments,
          scenes: input.scenes,
          storyAnalysisMy: input.storyAnalysisMy,
        });
  const characterRosterBlock = formatCharacterRosterPromptBlock(verifiedCharacters);

  const systemInstruction =
    'You are an expert Myanmar Movie Recap writer and dramatic storyteller. Write a DETAILED, FULL-ENDING MIXED recap blending natural conversational spoken Burmese narration with important original character dialogues. Follow the source video chronologically through all 9 narrative stages (Opening Hook, Story Background, Character Introduction, Main Conflict, Detailed Story Development, Important Character Dialogues, Twists & Reveals, Climax, and Full Ending & Resolution) locked to original scene timestamps at 1.0x video speed. Preserve real character names, nicknames, family relationships, professional titles/ranks, and honorifics consistently across the entire script instead of overusing generic pronouns ("သူ", "သူမ", "သူတို့", "အဲဒီလူ"). When a name is unknown, use the most accurate observable role description ("ရဲအရာရှိ", "ဆရာဝန်", "အမျိုးသမီးတစ်ဦး", "သူ့အစ်ကို") and never invent unverified identities. Treat TARGET_WORDS as a pacing target for the ~90% video narration duration (NOT a restrictive maximum cap), never copy sample lines verbatim, never output labels like "Narration:" or "Dialogue:", and never exceed 24 characters for thumbnailTitleMy.';

  const prompt = `Write a NEW FULL DETAILED Myanmar movie recap narration covering the ${input.durationSeconds.toFixed(2)}s video chronologically from Opening Hook to Climax and Full Ending & Resolution.
Configuration: Recap Style = DETAILED | Ending Style = FULL ENDING | Target Narration Duration = ~${targetDurationSeconds.toFixed(2)} seconds (~90% of ${input.durationSeconds.toFixed(2)}s, Video Speed LOCKED at 1.0x) | Story Expansion = AUTO EXPAND | Language = Natural Spoken Burmese | Important Character Dialogues = ENABLED.
Selected Voice Persona Style: ${input.voiceStyleName} (${input.voiceStyleTag}) — ${input.voiceStyleDesc}
${timestampedTranscript ? `\nTimestamped Original Audio Transcript Segments:\n${timestampedTranscript}\n` : input.transcript ? `\nOriginal Audio Transcript Context:\n"${input.transcript}"\n` : ''}
${characterRosterBlock ? `\n${characterRosterBlock}\n` : ''}
${input.storyAnalysisMy ? `\nChronological Story Overview:\n${input.storyAnalysisMy}\n` : ''}
${sceneContextText ? `\nVerified Chronological Scene Breakdown:\n${sceneContextText}\n` : ''}
${input.speedNote}

## DETAILED 9-STAGE STORYTELLING ARCHITECTURE (FULL ENDING REQUIRED)
Cover the movie chronologically across these 9 narrative stages (matching each beat's assigned stage and scene window):
1. Opening Hook — hook viewers immediately with the opening tension/situation from the earliest scene.
2. Story Background — establish the setting, context, and situation shown in the video.
3. Character Introduction — introduce key characters clearly with their real names/titles/roles.
4. Main Conflict — explain what triggered the central problem or confrontation.
5. Detailed Story Development — follow cause-and-effect events step by step without skipping middle scenes.
6. Important Character Dialogues — weave meaningful spoken lines directly into the story flow.
7. Twists and Reveals — clearly explain surprising turns, betrayals, secrets, or discoveries.
8. Climax — build dramatic tension naturally through the peak confrontation.
9. Full Ending and Resolution — explain the COMPLETE ending and final outcome truthfully (NEVER stop on a vague cliffhanger or cut the resolution short).

## MOVIE RECAP – MIXED NARRATION & NATURAL CHARACTER DIALOGUE INTEGRATION RULES
1. STYLE = MIXED (Professional Storytelling Narration + Important Original Character Dialogues):
   - Combine vivid natural spoken Burmese storytelling, character reactions, emotions, motivations, and smooth transitions WITH important spoken character conversations.
   - Do NOT flatten the movie into a dry narration-only summary that skips meaningful conversations.
2. PRIORITIZE PLOT-MOVING CHARACTER DIALOGUE WHEN PRESENT IN THE TRANSCRIPT:
   - Important questions and answers.
   - Arguments, conflicts, and confrontations.
   - Threats and warnings.
   - Emotional conversations and turning points.
   - Confessions, revelations, promises, and critical character decisions.
   - Funny or memorable lines.
3. NATURAL CONVERSATIONAL BURMESE FORMAT:
   - Use natural, engaging spoken Burmese (avoid robotic literal translation or stiff bureaucratic phrasing).
   - Rewrite translated character lines into natural, expressive spoken Burmese inside quotes (e.g., '...').
   - Weave narration and quoted dialogue smoothly into ONE continuous spoken script (NO "Narration:" / "Dialogue:" labels, NO stage tags, NO separate track).
   - Never copy or reuse phrasing from prompt instructions — adapt ONLY real events and lines from this video's transcript and scenes.
4. CHARACTER NAME & IDENTITY CONSISTENCY (STRICT):
   - Analyze the original video scenes, subtitles, dialogue transcripts, and story context to identify real character names and forms of address.
   - Whenever a character's real name or established nickname is known, USE THAT NAME consistently instead of repeatedly defaulting to generic pronouns such as "သူ", "သူမ", "သူတို့", or "အဲဒီလူ".
   - Preserve exact names and forms of address from the original movie: character names, nicknames, family titles/relationships, professional titles/ranks, and honorifics.
   - Maintain consistent identity across the entire recap — never randomly rename a character mid-recap or confuse two different characters.
   - When a character's name is unknown, use the most accurate observable description (e.g., "ရဲအရာရှိ", "ဆရာဝန်", "အမျိုးသမီးတစ်ဦး", "သူ့အစ်ကို").
   - Strictly NEVER invent character names, relationships, titles, or identities that cannot be verified from the video or transcript context.
   - Keep Burmese storytelling natural: repeat a character's name whenever clarity requires it while avoiding awkward mechanical repetition.
   - Before outputting final JSON, verify that every character name, identity, relationship, and form of address stays 100% consistent with the original source context.
5. STRICT ANTI-HALLUCINATION RULE:
   - Strictly DO NOT invent or fabricate character dialogue that does not exist in the transcript.
   - If dialogue transcription is missing or unclear for a scene, write a faithful description of the observable scene and character reactions instead.
6. TARGET_WORDS & 90% DURATION BUDGET (ORIGINAL VIDEO SPEED LOCKED AT 1.0X):
   - Because the original video stays strictly locked at 1.0x speed, each beat's narration MUST stay anchored to its real scene window [start -> end] and aim close to ~90% of that window (~${targetDurationSeconds.toFixed(2)}s total).
   - Each beat lists a TARGET_WORDS pacing guideline (it is a target length, NOT a restrictive maximum cap). Fill under-detailed beats with real story continuity and important dialogue, and avoid exceeding a beat's scene window so later scenes never drift out of sync.
   - Character dialogues count directly toward this single narration duration.
7. CHRONOLOGICAL CONTINUITY:
   - Match transcript timestamps accurately to their scenes and preserve strict start-to-finish chronological order without repeating events across beats.

Story Beats Covering Full Video:
${input.beatListText}

Requirements:
1. "segments": Array with EXACTLY ${input.beatCount} items matching each input beat id in order. Each item MUST have: id (string matching input id), myanmarText (clean spoken Burmese blending storytelling narration + quoted character dialogue with consistent character names/titles and NO "Narration:"/"Dialogue:" prefixes), emoji (1 matching emoji like 🔥, 😱, 🎬, 💬).
2. "thumbnailTitleMy": A viral Myanmar thumbnail title STRICTLY under 25 characters (maximum 24 characters).`;

  return { systemInstruction, prompt, targetDurationSeconds };
}

/**
 * Determines whether the initial Movie Recap script is significantly under the 90% target
 * AND selects ONLY the underfilled beats that have genuine source transcript/scene evidence
 * to expand chronologically without fabricating or duplicating content.
 */
export function selectRecapBeatsForAutoExpansion(params: {
  beats: RecapBeat[];
  segments: RecapGeneratedSegment[];
  videoDurationSeconds: number;
  voiceSpeed: VoiceSpeed;
  timestampedSegments?: TimestampedTranscriptItem[];
  scenes?: SceneSummary[];
  transcript?: string;
  storyAnalysisMy?: string;
}): {
  shouldExpand: boolean;
  estimate: RecapDurationEstimate;
  candidates: RecapExpansionCandidate[];
} {
  const {
    beats,
    segments,
    videoDurationSeconds,
    voiceSpeed,
    timestampedSegments = [],
    scenes = [],
    transcript = '',
    storyAnalysisMy = '',
  } = params;

  const estimate = estimateRecapNarrationCoverage(
    beats,
    segments,
    videoDurationSeconds,
    voiceSpeed
  );

  // Never fabricate content when there is neither transcript nor visual scene evidence
  const hasEvidence =
    hasSubstantiveTranscript(transcript, timestampedSegments) ||
    scenes.some((s) => String(s.descriptionMy || '').trim().length >= 8) ||
    String(storyAnalysisMy || '').trim().length >= 16;

  if (!hasEvidence || beats.length === 0) {
    return { shouldExpand: false, estimate, candidates: [] };
  }

  // Trigger expansion only when meaningfully short of the 90% target
  const deficitSeconds = estimate.targetDurationSeconds - estimate.estimatedDurationSeconds;
  const isUnderTarget =
    estimate.coverageRatio < 0.78 ||
    (estimate.targetDurationSeconds >= 12 && deficitSeconds >= 3.0);

  if (!isUnderTarget) {
    return { shouldExpand: false, estimate, candidates: [] };
  }

  const segById = new Map(segments.map((s) => [s.id, s]));
  const candidates: RecapExpansionCandidate[] = [];

  for (let i = 0; i < beats.length; i++) {
    const beat = beats[i];
    const perEst = estimate.perSegment[i];
    if (!perEst || perEst.fillRatio >= 0.85) continue;

    const matchingTranscriptLines = timestampedSegments
      .filter((t) => t.end > beat.start - 0.5 && t.start < beat.end + 0.5 && String(t.text || '').trim())
      .map((t) => `[${formatClock(t.start)} -> ${formatClock(t.end)}] "${t.text.trim()}"`);

    const matchingSceneNotes = scenes
      .filter((sc) => sc.timestamp >= beat.start - 1.0 && sc.timestamp <= beat.end + 1.0 && String(sc.descriptionMy || '').trim())
      .map((sc) => `[${formatClock(sc.timestamp)}] ${sc.descriptionMy.trim()}`);

    const beatHasContext =
      matchingTranscriptLines.length > 0 ||
      matchingSceneNotes.length > 0 ||
      hasSubstantiveTranscript(beat.contextText);

    if (!beatHasContext) continue;

    candidates.push({
      beat,
      currentText: segById.get(beat.id)?.myanmarText || segments[i]?.myanmarText || '',
      currentEmoji: segById.get(beat.id)?.emoji || segments[i]?.emoji || '🎬',
      estimatedSeconds: perEst.estimatedSeconds,
      targetSeconds: perEst.targetSeconds,
      matchingTranscriptLines,
      matchingSceneNotes,
      previousBeatText: i > 0 ? segById.get(beats[i - 1].id)?.myanmarText || segments[i - 1]?.myanmarText || '' : '',
      nextBeatText: i + 1 < beats.length ? segById.get(beats[i + 1].id)?.myanmarText || segments[i + 1]?.myanmarText || '' : '',
    });
  }

  return {
    shouldExpand: candidates.length > 0,
    estimate,
    candidates,
  };
}

/**
 * Builds a targeted Gemini prompt that expands ONLY underfilled beats using missed story explanations
 * and unincluded transcript dialogues, preserving neighboring beats without duplication or fabrication.
 */
export function buildRecapAutoExpansionPrompt(params: {
  durationSeconds: number;
  targetDurationSeconds: number;
  currentEstimatedSeconds: number;
  candidates: RecapExpansionCandidate[];
  storyAnalysisMy?: string;
  verifiedCharacters?: VerifiedCharacterProfile[];
}): { systemInstruction: string; prompt: string } {
  const {
    durationSeconds,
    targetDurationSeconds,
    currentEstimatedSeconds,
    candidates,
    storyAnalysisMy = '',
    verifiedCharacters = [],
  } = params;

  const characterRosterBlock = formatCharacterRosterPromptBlock(verifiedCharacters);

  const candidateBlock = candidates
    .map((c) => {
      const lines = [
        `### Beat id="${c.beat.id}" [${c.beat.start.toFixed(2)}s -> ${c.beat.end.toFixed(2)}s]`,
        `Current Est Duration: ${c.estimatedSeconds.toFixed(2)}s | Target: ~${c.targetSeconds.toFixed(2)}s (TARGET_WORDS=${c.beat.maxMyanmarWords})`,
        `Current Myanmar Draft: "${c.currentText}"`,
      ];
      if (c.previousBeatText) {
        lines.push(`Previous Beat (DO NOT repeat its content): "${c.previousBeatText}"`);
      }
      if (c.nextBeatText) {
        lines.push(`Next Beat (DO NOT repeat its content): "${c.nextBeatText}"`);
      }
      if (c.matchingTranscriptLines.length > 0) {
        lines.push(`Source Transcript in This Window:\n${c.matchingTranscriptLines.join('\n')}`);
      } else if (c.beat.contextText) {
        lines.push(`Beat Source Context: "${c.beat.contextText}"`);
      }
      if (c.matchingSceneNotes.length > 0) {
        lines.push(`Visual Scene Evidence:\n${c.matchingSceneNotes.join('\n')}`);
      }
      return lines.join('\n');
    })
    .join('\n\n');

  const systemInstruction =
    'You are refining an under-length Myanmar Movie Recap script to reach ~90% of the source video duration. Expand ONLY the listed underfilled beats by integrating missed story context, character reactions, and important transcript dialogues that were omitted. Maintain strict chronological order and consistent character names/titles/forms of address instead of repeating generic pronouns ("သူ", "သူမ", "သူတို့", "အဲဒီလူ"), never duplicate sentences or quotes from adjacent beats, never invent dialogue or character identities missing from the source, and output clean spoken Burmese with no "Narration:"/"Dialogue:" prefixes.';

  const prompt = `The initial Myanmar Movie Recap draft for a ${durationSeconds.toFixed(2)}s video currently estimates ${currentEstimatedSeconds.toFixed(2)}s vs the ~${targetDurationSeconds.toFixed(2)}s (90%) target.

Expand ONLY the ${candidates.length} underfilled beat(s) listed below so each reaches close to its TARGET_WORDS and target beat seconds naturally:
${characterRosterBlock ? `\n${characterRosterBlock}\n` : ''}
${storyAnalysisMy ? `\nStory Context:\n${storyAnalysisMy}\n` : ''}
${candidateBlock}

Strict Rules:
1. Return "segments" containing ONLY the exact ${candidates.length} beat id(s) listed above in chronological order.
2. Add missing story explanations, character motivations/reactions, and any important unincluded transcript dialogue (in conversational Burmese quotes '...').
3. Maintain strict Character Name & Identity Consistency: use established character names/nicknames/titles/relationships consistently instead of repeating "သူ", "သူမ", "သူတို့", or "အဲဒီလူ". Never invent unverified names.
4. NEVER repeat or paraphrase lines already covered in Previous Beat or Next Beat.
5. NEVER fabricate dialogue if no transcript speech exists in that beat's window — expand only with observable scene details and story continuity.
6. Keep output clean spoken Burmese (NO "Narration:", NO "Dialogue:", NO markdown).`;

  return { systemInstruction, prompt };
}

export interface CharacterConsistencyAudit {
  knownNames: string[];
  usedKnownNames: string[];
  missedKnownNames: string[];
  genericPronounCount: number;
  pronounHeavyBeatIds: string[];
  needsConsistencyPass: boolean;
}

const GENERIC_BURMESE_PRONOUN_RE = /(?:^|[\s'"“”‘’])(သူတို့|သူမ|အဲဒီလူ|အဲ့ဒီလူ|ထိုသူ|သူက|သူ့ကို|သူ့အား|သူ့|သူ)(?=[\s'"“”‘’။,.!?ကကိုမှာကနေတွင်နဲ့နှင့်မှလည်းပဲ]|$)/g;

/**
 * Audits a generated Movie Recap script for character name & identity consistency:
 * checks whether verified character names/nicknames/titles are preserved consistently
 * and identifies beats overly reliant on generic pronouns ("သူ", "သူမ", "သူတို့", "အဲဒီလူ").
 */
export function auditRecapCharacterConsistency(
  segments: RecapGeneratedSegment[],
  verifiedCharacters: VerifiedCharacterProfile[]
): CharacterConsistencyAudit {
  const knownNames = verifiedCharacters.map((c) => c.canonicalName).filter(Boolean);
  const fullText = segments.map((s) => String(s.myanmarText || '')).join(' ');
  const fullLower = fullText.toLowerCase();

  const usedKnownNames: string[] = [];
  const missedKnownNames: string[] = [];

  for (const profile of verifiedCharacters) {
    const terms = [profile.canonicalName, ...profile.aliases].filter(Boolean);
    const matched = terms.some((t) => fullLower.includes(t.toLowerCase()));
    if (matched) {
      usedKnownNames.push(profile.canonicalName);
    } else {
      missedKnownNames.push(profile.canonicalName);
    }
  }

  let genericPronounCount = 0;
  const pronounHeavyBeatIds: string[] = [];

  for (const seg of segments) {
    const txt = String(seg.myanmarText || '');
    const pronounMatches = txt.match(GENERIC_BURMESE_PRONOUN_RE);
    const countInBeat = pronounMatches ? pronounMatches.length : 0;
    genericPronounCount += countInBeat;

    const beatLower = txt.toLowerCase();
    const mentionsAnyKnown = verifiedCharacters.some((profile) =>
      [profile.canonicalName, ...profile.aliases].some(
        (term) => term && beatLower.includes(term.toLowerCase())
      )
    );
    if (countInBeat >= 2 && !mentionsAnyKnown) {
      pronounHeavyBeatIds.push(seg.id);
    }
  }

  const needsConsistencyPass =
    verifiedCharacters.length > 0 &&
    (missedKnownNames.length > 0 ||
      pronounHeavyBeatIds.length >= Math.max(2, Math.ceil(segments.length * 0.4)));

  return {
    knownNames,
    usedKnownNames,
    missedKnownNames,
    genericPronounCount,
    pronounHeavyBeatIds,
    needsConsistencyPass,
  };
}

/**
 * Builds a pre-final verification & refinement prompt to make character names, nicknames,
 * relationships, professional ranks, and forms of address consistent throughout the recap.
 */
export function buildRecapCharacterConsistencyPrompt(params: {
  beats: RecapBeat[];
  segments: RecapGeneratedSegment[];
  verifiedCharacters: VerifiedCharacterProfile[];
  audit: CharacterConsistencyAudit;
  timestampedSegments?: TimestampedTranscriptItem[];
  scenes?: SceneSummary[];
}): { systemInstruction: string; prompt: string } {
  const {
    beats,
    segments,
    verifiedCharacters,
    audit,
    timestampedSegments = [],
    scenes = [],
  } = params;

  const rosterBlock = formatCharacterRosterPromptBlock(verifiedCharacters);
  const beatSummary = segments
    .map((seg, idx) => {
      const b = beats[idx];
      const windowLabel = b ? `[${b.start.toFixed(2)}s -> ${b.end.toFixed(2)}s]` : '';
      return `- Beat id="${seg.id}" ${windowLabel}: "${seg.myanmarText}"`;
    })
    .join('\n');

  const transcriptLines = formatTimestampedTranscriptContext(timestampedSegments, 3600, 60);
  const sceneNotes = scenes
    .slice(0, 16)
    .map((sc) => `- [${formatClock(Number(sc.timestamp || 0))}] ${String(sc.descriptionMy || '').trim()}`)
    .join('\n');

  const systemInstruction =
    'You are performing a pre-final Character Name & Identity Consistency pass on a Myanmar Movie Recap script. Preserve every scene event, chronological order, quoted character dialogue, and overall ~90% narration length, while fixing repetitive generic pronouns ("သူ", "သူမ", "သူတို့", "အဲဒီလူ") to use verified character names, nicknames, family relationships, professional titles, or honorifics consistently. Never invent unverified names or confuse characters.';

  const prompt = `Review and refine this Myanmar Movie Recap draft ONLY for Character Name & Identity Consistency before final delivery.

${rosterBlock}
${audit.missedKnownNames.length > 0 ? `\nVerified characters missing or under-identified in draft: ${audit.missedKnownNames.join(', ')}` : ''}
${audit.pronounHeavyBeatIds.length > 0 ? `\nBeats relying heavily on generic pronouns: ${audit.pronounHeavyBeatIds.join(', ')}` : ''}
${transcriptLines ? `\nSource Transcript Reference:\n${transcriptLines}\n` : ''}
${sceneNotes ? `\nSource Scene Reference:\n${sceneNotes}\n` : ''}
Current Draft Beats (${segments.length} beats):
${beatSummary}

Consistency Verification Rules:
1. Whenever a character's real name, nickname, title, rank, honorific, or relationship is known from the verified roster/transcript/scenes, use it consistently instead of repeating "သူ", "သူမ", "သူတို့", or "အဲဒီလူ".
2. Keep character identities 100% consistent across all beats — never swap names or mix up two characters.
3. For truly unnamed characters, use accurate observable role descriptions (e.g., "ရဲအရာရှိ", "ဆရာဝန်", "အမျိုးသမီးတစ်ဦး", "သူ့အစ်ကို") and NEVER invent names.
4. Keep natural Burmese storytelling cadence: repeat names for clarity when needed without awkward mechanical repetition.
5. Preserve existing plot points, chronological order, quoted conversational dialogues, and approximate length per beat.
6. Return "segments" with EXACTLY ${segments.length} items matching each input beat id in order (with myanmarText and emoji).`;

  return { systemInstruction, prompt };
}

function normalizeClauseForDedup(clause: string): string {
  return cleanRecapSpokenText(clause)
    .replace(/[\s'"“”‘’။,.!?…\-:;()]/g, '')
    .toLowerCase();
}

/**
 * Validates and cleans final recap segments before returning from /api/generate-script:
 * - Preserves exact beat order & IDs
 * - Strips structural label leaks ("Narration:", "Dialogue:")
 * - Removes duplicated clauses/dialogue lines across beats
 * - Ensures every beat has non-empty spoken Burmese fallback
 */
export function validateAndRefineRecapSegments(params: {
  beats: RecapBeat[];
  rawSegments: Array<{ id?: string; myanmarText?: string; emoji?: string }>;
  videoDurationSeconds: number;
  voiceSpeed: VoiceSpeed;
}): RecapValidationResult {
  const { beats, rawSegments, videoDurationSeconds, voiceSpeed } = params;
  const byId = new Map<string, { myanmarText?: string; emoji?: string }>();
  for (const seg of rawSegments) {
    if (seg?.id) {
      byId.set(String(seg.id), seg);
    }
  }

  const seenClauses = new Set<string>();
  let removedDuplicateCount = 0;
  let dialogueLineCount = 0;
  const warnings: string[] = [];

  const refined: RecapGeneratedSegment[] = beats.map((beat, idx) => {
    const candidate = byId.get(beat.id) || rawSegments[idx];
    const cleaned = cleanRecapSpokenText(candidate?.myanmarText || '');
    const emoji = String(candidate?.emoji || '🎬').trim() || '🎬';

    // Split on Burmese/Latin sentence boundaries while keeping delimiters
    const rawClauses = cleaned
      .split(/(?<=[။!?])\s+/)
      .map((s) => s.trim())
      .filter(Boolean);

    const keptClauses: string[] = [];
    for (const clause of rawClauses) {
      const key = normalizeClauseForDedup(clause);
      if (key.length >= 10 && seenClauses.has(key)) {
        removedDuplicateCount += 1;
        continue;
      }
      if (key.length >= 10) {
        seenClauses.add(key);
      }
      keptClauses.push(clause);
    }

    let finalText = keptClauses.join(' ').trim();
    if (!finalText) {
      finalText = cleaned || String(beat.contextText || '').trim();
      if (cleaned) {
        warnings.push(`Beat ${beat.id} fell back after duplicate filtering`);
      } else {
        warnings.push(`Beat ${beat.id} was empty and used context fallback`);
      }
    }

    if (/['"“”‘’][^'"“”‘’]{2,}['"“”‘’]/.test(finalText)) {
      dialogueLineCount += 1;
    }

    return {
      id: beat.id,
      myanmarText: finalText,
      emoji,
    };
  });

  const estimate = estimateRecapNarrationCoverage(
    beats,
    refined,
    videoDurationSeconds,
    voiceSpeed
  );

  if (estimate.coverageRatio < 0.72) {
    warnings.push(
      `Estimated narration duration (${estimate.estimatedDurationSeconds}s) is below 72% of 90% target (${estimate.targetDurationSeconds}s)`
    );
  }

  return {
    segments: refined,
    estimatedDurationSeconds: estimate.estimatedDurationSeconds,
    targetDurationSeconds: estimate.targetDurationSeconds,
    coverageRatio: estimate.coverageRatio,
    dialogueLineCount,
    removedDuplicateCount,
    warnings,
  };
}

export interface RecapActualDurationAdjustTarget {
  beat: RecapBeat;
  mode: 'expand' | 'tighten';
  currentText: string;
  currentEmoji: string;
  actualTtsSeconds: number;
  targetTtsSeconds: number;
  maxWindowSeconds: number;
  matchingTranscriptLines: string[];
  matchingSceneNotes: string[];
  previousBeatText: string;
  nextBeatText: string;
}

/**
 * Builds an actual-TTS-duration-driven refinement prompt (used AFTER measuring real TTS WAV lengths):
 * expands genuinely underfilled beats with real missed story explanations/dialogue, and tightens
 * overflowing beats so the original video stays 100% locked at 1.0x without cross-scene drift.
 */
export function buildRecapDurationAdjustmentPrompt(params: {
  durationSeconds: number;
  actualTotalTtsSeconds: number;
  targetTotalTtsSeconds: number;
  targets: RecapActualDurationAdjustTarget[];
  storyAnalysisMy?: string;
  verifiedCharacters?: VerifiedCharacterProfile[];
}): { systemInstruction: string; prompt: string } {
  const {
    durationSeconds,
    actualTotalTtsSeconds,
    targetTotalTtsSeconds,
    targets,
    storyAnalysisMy = '',
    verifiedCharacters = [],
  } = params;

  const characterRosterBlock = formatCharacterRosterPromptBlock(verifiedCharacters);

  const targetBlocks = targets
    .map((t) => {
      const actionLabel =
        t.mode === 'expand'
          ? `EXPAND (~${t.actualTtsSeconds.toFixed(2)}s measured -> aim ~${t.targetTtsSeconds.toFixed(2)}s, max window ${t.maxWindowSeconds.toFixed(2)}s)`
          : `TIGHTEN CONCISELY (~${t.actualTtsSeconds.toFixed(2)}s measured exceeded ${t.maxWindowSeconds.toFixed(2)}s scene window -> aim ~${t.targetTtsSeconds.toFixed(2)}s)`;

      const lines = [
        `### Beat id="${t.beat.id}" (${t.beat.sceneId || 'scene'}) [${t.beat.start.toFixed(2)}s -> ${t.beat.end.toFixed(2)}s] — ${actionLabel}`,
        `Current Draft: "${t.currentText}"`,
      ];
      if (t.previousBeatText) {
        lines.push(`Previous Beat (DO NOT repeat): "${t.previousBeatText}"`);
      }
      if (t.nextBeatText) {
        lines.push(`Next Beat (DO NOT repeat): "${t.nextBeatText}"`);
      }
      if (t.matchingTranscriptLines.length > 0) {
        lines.push(`Source Transcript:\n${t.matchingTranscriptLines.join('\n')}`);
      } else if (t.beat.contextText) {
        lines.push(`Scene Context: "${t.beat.contextText}"`);
      }
      if (t.matchingSceneNotes.length > 0) {
        lines.push(`Visual Scene Notes:\n${t.matchingSceneNotes.join('\n')}`);
      }
      return lines.join('\n');
    })
    .join('\n\n');

  const systemInstruction =
    'You are refining specific Myanmar Movie Recap beats based on ACTUAL measured TTS audio durations so narration stays 100% synchronized to a 1.0x locked video (~90% target coverage). For EXPAND beats, add real missed story explanations, character motivations/reactions, and unincluded transcript dialogues without repetition or filler. For TIGHTEN beats, rewrite crisply in natural spoken Burmese keeping core plot events, verified character names, and crucial dialogue quotes while fitting comfortably inside the scene window. Never invent unverified dialogue or names.';

  const prompt = `Measured AI voice total for this ${durationSeconds.toFixed(2)}s video is currently ${actualTotalTtsSeconds.toFixed(2)}s (90% target = ${targetTotalTtsSeconds.toFixed(2)}s; original video speed is LOCKED at 1.0x).

Adjust ONLY the ${targets.length} beat(s) listed below:
${characterRosterBlock ? `\n${characterRosterBlock}\n` : ''}
${storyAnalysisMy ? `\nChronological Story Context:\n${storyAnalysisMy}\n` : ''}
${targetBlocks}

Requirements:
1. Return "segments" containing ONLY the exact ${targets.length} beat id(s) listed above in chronological order (with id, myanmarText, emoji).
2. Zero fabricated dialogue, zero invented character names, zero repeated lines from adjacent beats.
3. Preserve natural spoken conversational Burmese with consistent character names/titles and clean quotes '...' for dialogue.`;

  return { systemInstruction, prompt };
}

/**
 * Distributes a manually edited single-string Myanmar recap script proportionally across
 * scene-anchored beats so per-beat scene windows remain intact even after manual textarea edits.
 */
export function distributeEditedScriptAcrossBeats(
  scriptText: string,
  beats: RecapBeat[],
  existingSegments: RecapGeneratedSegment[] = []
): RecapGeneratedSegment[] {
  const cleaned = cleanRecapSpokenText(scriptText);
  if (beats.length === 0) return [];
  if (!cleaned) {
    return beats.map((b, idx) => ({
      id: b.id,
      myanmarText: existingSegments[idx]?.myanmarText || b.contextText || '',
      emoji: existingSegments[idx]?.emoji || '🎬',
    }));
  }

  const sentences = cleaned
    .split(/(?<=[။!?])\s*/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (sentences.length <= 1 || sentences.length < beats.length) {
    // Split on clause spaces/commas if fewer sentences than beats, or assign sequentially
    const tokens =
      sentences.length >= beats.length
        ? sentences
        : cleaned.split(/\s+/).filter(Boolean);

    if (tokens.length <= beats.length) {
      return beats.map((b, idx) => ({
        id: b.id,
        myanmarText: idx < tokens.length ? tokens[idx] : existingSegments[idx]?.myanmarText || '',
        emoji: existingSegments[idx]?.emoji || '🎬',
      }));
    }

    const totalWeight = beats.reduce((s, b) => s + Math.max(0.5, b.duration), 0);
    let tokenIdx = 0;
    return beats.map((b, idx) => {
      const share = Math.max(1, Math.round((Math.max(0.5, b.duration) / totalWeight) * tokens.length));
      const endIdx = idx === beats.length - 1 ? tokens.length : Math.min(tokens.length, tokenIdx + share);
      const slice = tokens.slice(tokenIdx, Math.max(tokenIdx, endIdx)).join(' ').trim();
      tokenIdx = endIdx;
      return {
        id: b.id,
        myanmarText: slice || existingSegments[idx]?.myanmarText || '',
        emoji: existingSegments[idx]?.emoji || '🎬',
      };
    });
  }

  // Group sentences cleanly by beat duration proportions
  const totalDur = beats.reduce((s, b) => s + Math.max(0.5, b.duration), 0);
  const totalSentenceChars = sentences.reduce((s, line) => s + Math.max(4, line.length), 0);
  const out: RecapGeneratedSegment[] = [];
  let sIdx = 0;
  let accumDur = 0;

  for (let i = 0; i < beats.length; i++) {
    const b = beats[i];
    accumDur += Math.max(0.5, b.duration);
    const targetCumulativeChars = (accumDur / totalDur) * totalSentenceChars;
    const collected: string[] = [];

    if (i === beats.length - 1) {
      while (sIdx < sentences.length) {
        collected.push(sentences[sIdx++]);
      }
    } else {
      let runningChars = sentences.slice(0, sIdx).reduce((sum, l) => sum + Math.max(4, l.length), 0);
      while (sIdx < sentences.length) {
        const remainingBeats = beats.length - 1 - i;
        const remainingSentences = sentences.length - sIdx;
        if (remainingSentences <= remainingBeats && collected.length >= 1) break;
        collected.push(sentences[sIdx]);
        runningChars += Math.max(4, sentences[sIdx].length);
        sIdx += 1;
        if (runningChars >= targetCumulativeChars && collected.length >= 1) break;
      }
    }

    out.push({
      id: b.id,
      myanmarText: collected.join(' ').trim() || existingSegments[i]?.myanmarText || '',
      emoji: existingSegments[i]?.emoji || '🎬',
    });
  }

  return out;
}

/**
 * Extracts quoted character dialogue phrases from mixed Burmese narration+dialogue text.
 */
export function extractQuotedDialogueSegment(text: string): string | undefined {
  const matches = String(text || '').match(/['"“”‘’]([^'"“”‘’]{2,})['"“”‘’]/g);
  if (!matches || matches.length === 0) return undefined;
  return matches.join(' ').trim();
}

/**
 * Builds structured Scene-to-Script & TTS alignment mappings for every Movie Recap beat.
 */
export function buildRecapSceneMappings(params: {
  beats: RecapBeat[];
  segments: RecapGeneratedSegment[];
  scenes?: SceneSummary[];
  verifiedCharacters?: VerifiedCharacterProfile[];
  schedule?: LockedVideoRecapScheduleResult | null;
}): RecapSceneMapping[] {
  const { beats, segments, scenes = [], verifiedCharacters = [], schedule = null } = params;
  const stages = assignRecapStoryStages(beats);
  const segById = new Map(segments.map((s) => [s.id, s]));
  const slotByBeatId = new Map((schedule?.slots || []).map((sl) => [sl.beatId, sl]));

  return beats.map((beat, idx) => {
    const seg = segById.get(beat.id) || segments[idx];
    const slot = slotByBeatId.get(beat.id);
    const narrationText = cleanRecapSpokenText(seg?.myanmarText || '');
    const dialogueText = extractQuotedDialogueSegment(narrationText);

    const matchingScenes = scenes.filter(
      (sc) =>
        (beat.sceneId && sc.sceneId === beat.sceneId) ||
        (sc.timestamp >= beat.start - 0.5 && sc.timestamp <= beat.end + 0.5)
    );

    const lowerText = narrationText.toLowerCase();
    const refsFromText = verifiedCharacters
      .filter((c) => [c.canonicalName, ...c.aliases].some((term) => term && lowerText.includes(term.toLowerCase())))
      .map((c) => c.canonicalName);

    const refsFromScenes = matchingScenes.flatMap((sc) => sc.characters || []);
    const characterRefs = [...new Set([...(beat.characters || []), ...refsFromScenes, ...refsFromText])];

    const storyEvent =
      matchingScenes.map((sc) => sc.storyEvent || sc.descriptionMy).filter(Boolean).join(' ').trim() ||
      beat.sceneDescriptionMy ||
      beat.contextText;

    return {
      beatId: beat.id,
      sceneId: beat.sceneId || matchingScenes[0]?.sceneId || `scene_${idx + 1}`,
      startTime: Number(beat.start.toFixed(2)),
      endTime: Number(beat.end.toFixed(2)),
      storyStage: stages[idx] || 'story_development',
      characterRefs,
      storyEvent,
      narrationText,
      ...(dialogueText ? { dialogueText } : {}),
      ...(slot
        ? {
            narrationStart: slot.actualStart,
            narrationEnd: slot.actualEnd,
            actualTtsDuration: slot.fittedDuration,
            targetTtsDuration: slot.targetBeatDuration,
            tempoApplied: slot.tempoRatio,
            alignmentStatus: slot.alignmentStatus,
          }
        : {}),
    };
  });
}

const BURMESE_CHAR_RE = /[\u1000-\u109F]/g;
const LEAKED_LABEL_RE = /(?:^|\s)\*{0,2}(?:Narration|Dialogue|Voiceover|Storyteller)\s*:\*{0,2}/i;

/**
 * Mandatory Pre-Render Movie Recap Quality Validation Gate:
 * Verifies story accuracy, character consistency, natural dialogue integration, scene alignment,
 * timestamp continuity, actual TTS duration vs 90% target, 1.0x locked video speed, full ending coverage,
 * and Burmese prose quality before final export.
 */
export function validateRecapQuality(params: {
  beats: RecapBeat[];
  segments: RecapGeneratedSegment[];
  mappings: RecapSceneMapping[];
  originalVideoDuration: number;
  actualTtsDuration: number; // 0 if running pre-TTS script validation
  videoPlaybackRate?: number;
  silenceCutApplied?: boolean;
  verifiedCharacters?: VerifiedCharacterProfile[];
  timestampedSegments?: TimestampedTranscriptItem[];
  hasTtsAudio?: boolean;
}): RecapQualityValidation {
  const {
    beats,
    segments,
    mappings,
    originalVideoDuration,
    actualTtsDuration,
    videoPlaybackRate = 1.0,
    silenceCutApplied = false,
    verifiedCharacters = [],
    timestampedSegments = [],
    hasTtsAudio = actualTtsDuration > 0,
  } = params;

  const safeVideoDur = Math.max(1, Number.isFinite(originalVideoDuration) ? originalVideoDuration : 12);
  const targetRecapDuration = computeRecapTargetDurationSeconds(safeVideoDur);
  const measuredOrEst = hasTtsAudio
    ? Math.max(0, actualTtsDuration)
    : estimateRecapNarrationCoverage(beats, segments, safeVideoDur, 'normal').estimatedDurationSeconds;
  const durationDiffSeconds = Number((measuredOrEst - targetRecapDuration).toFixed(2));
  const coverageRatio =
    targetRecapDuration > 0 ? Number((measuredOrEst / targetRecapDuration).toFixed(3)) : 1;

  const checks: RecapQualityCheckItem[] = [];
  const fullText = segments.map((s) => String(s.myanmarText || '').trim()).join(' ').trim();

  // 1. Video Speed Lock (MUST BE STRICTLY 1.0x & NO silence-cut frame removal)
  const speedLockedOk = Math.abs(videoPlaybackRate - 1.0) < 0.005 && !silenceCutApplied;
  checks.push({
    key: 'video_speed_lock',
    passed: speedLockedOk,
    severity: speedLockedOk ? 'pass' : 'critical',
    messageMy: speedLockedOk
      ? 'မူရင်းဗီဒီယိုအမြန်နှုန်းကို 1.0x တွင် အပြည့်အဝ Lock ချထားပါသည်'
      : `မူရင်းဗီဒီယိုအမြန်နှုန်း Lock 1.0x ပျက်ယွင်းနေပါသည် (Playback: ${videoPlaybackRate}x)`,
  });

  // 2. Story Accuracy & Coverage
  const nonEmptyBeats = segments.filter((s) => String(s.myanmarText || '').trim().length >= 6).length;
  const storyAccuracyOk = beats.length > 0 && nonEmptyBeats === beats.length;
  checks.push({
    key: 'story_accuracy',
    passed: storyAccuracyOk,
    severity: storyAccuracyOk ? 'pass' : nonEmptyBeats === 0 ? 'critical' : 'warning',
    messageMy: storyAccuracyOk
      ? `ဇာတ်လမ်းအပိုင်း (${nonEmptyBeats}/${beats.length}) စလုံး ပြည့်စုံစွာ ပါဝင်ပါသည်`
      : `ဇာတ်လမ်းအပိုင်း (${beats.length - nonEmptyBeats}) ခု စာသားလိုအပ်နေပါသည်`,
  });

  // 3. Character Consistency
  const charAudit = auditRecapCharacterConsistency(segments, verifiedCharacters);
  const charOk = verifiedCharacters.length === 0 || !charAudit.needsConsistencyPass;
  checks.push({
    key: 'character_consistency',
    passed: charOk,
    severity: charOk ? 'pass' : 'warning',
    messageMy:
      verifiedCharacters.length === 0
        ? 'ဇာတ်ကောင်နာမည်အထောက်အထား မပါသဖြင့် မြင်တွေ့ရသော အခန်းကဏ္ဍအတိုင်း ရေးသားထားပါသည်'
        : charOk
          ? `ဇာတ်ကောင်နာမည်များ (${charAudit.usedKnownNames.join(', ')}) တစ်သမတ်တည်း ကိုက်ညီပါသည်`
          : `ဇာတ်ကောင်နာမည် ထပ်မံတိကျရန် (${charAudit.missedKnownNames.join(', ') || 'pronoun-heavy beats'}) သတိပြုပါ`,
  });

  // 4. Dialogue Integration
  const hasSpokenTranscript = hasSubstantiveTranscript(
    timestampedSegments.map((t) => t.text).join(' '),
    timestampedSegments
  );
  const quotedCount = segments.filter((s) => /['"“”‘’][^'"“”‘’]{2,}['"“”‘’]/.test(s.myanmarText || '')).length;
  const dialogueOk = !hasSpokenTranscript || quotedCount >= 1;
  checks.push({
    key: 'dialogue_integration',
    passed: dialogueOk,
    severity: dialogueOk ? 'pass' : 'warning',
    messageMy: !hasSpokenTranscript
      ? 'မူရင်းအသံစကားပြော မပါသဖြင့် မြင်ကွင်းအမှန်အတိုင်း ပြန်လည်ပြောပြထားပါသည်'
      : dialogueOk
        ? `အရေးပါသော ဇာတ်ကောင်စကားပြော (${quotedCount} နေရာ) သဘာဝကျစွာ ထည့်သွင်းထားပါသည်`
        : 'မူရင်းစကားပြော ပါဝင်သော်လည်း တိုက်ရိုက်စကားပြောကိုးကားချက် နည်းပါးနေပါသည်',
  });

  // 5. Scene Alignment
  const overflowCount = mappings.filter((m) => m.alignmentStatus === 'overflow_warning').length;
  const missingAudioCount = mappings.filter((m) => m.alignmentStatus === 'missing_audio').length;
  const sceneAlignOk = missingAudioCount === 0 && overflowCount <= Math.max(1, Math.floor(mappings.length * 0.25));
  checks.push({
    key: 'scene_alignment',
    passed: sceneAlignOk,
    severity: missingAudioCount > 0 ? 'critical' : sceneAlignOk ? 'pass' : 'warning',
    messageMy:
      missingAudioCount > 0
        ? `Scene (${missingAudioCount}) ခုတွင် TTS အသံဖိုင် ပျောက်ဆုံးနေပါသည်`
        : overflowCount === 0
          ? `Scene (${mappings.length}) ခုလုံး Timeline အချိန်အကန့်အသတ်အတွင်း တိကျစွာ ကိုက်ညီပါသည်`
          : `Scene (${overflowCount}) ခုတွင် စကားပြောအနည်းငယ် ရှည်နေ၍ အချိန်ညှိပေးထားပါသည်`,
  });

  // 6. Timestamp Continuity (monotonic, non-overlapping, within [0 .. originalVideoDuration])
  let continuityValid = mappings.length > 0;
  let prevNarEnd = -0.01;
  for (const m of mappings) {
    if (m.endTime <= m.startTime || m.startTime < 0 || m.endTime > safeVideoDur + 0.15) {
      continuityValid = false;
      break;
    }
    if (typeof m.narrationStart === 'number' && typeof m.narrationEnd === 'number') {
      if (
        m.narrationStart < prevNarEnd - 0.02 ||
        m.narrationEnd > safeVideoDur + 0.15
      ) {
        continuityValid = false;
        break;
      }
      prevNarEnd = m.narrationEnd;
    }
  }
  checks.push({
    key: 'timestamp_continuity',
    passed: continuityValid,
    severity: continuityValid ? 'pass' : 'critical',
    messageMy: continuityValid
      ? 'Timestamp အစီအစဉ်နှင့် Scene အချိန်ဆက်စပ်မှု မှန်ကန်ပါသည်'
      : 'Timestamp အစီအစဉ် ထပ်နေခြင်း သို့မဟုတ် ဗီဒီယိုကြာချိန်ထက် ကျော်လွန်နေပါသည်',
  });

  // 7. Actual TTS Duration vs 90% Target
  const durationAcceptable = !hasTtsAudio || (coverageRatio >= 0.65 && coverageRatio <= 1.15);
  const durationCriticallyBroken = hasTtsAudio && (actualTtsDuration <= 0.3 || coverageRatio < 0.2);
  checks.push({
    key: 'tts_duration_target',
    passed: durationAcceptable && !durationCriticallyBroken,
    severity: durationCriticallyBroken ? 'critical' : durationAcceptable ? 'pass' : 'warning',
    messageMy: hasTtsAudio
      ? `AI အသံအရှည် ${measuredOrEst.toFixed(1)}s (90% Target: ${targetRecapDuration.toFixed(1)}s · ကွာဟချက် ${durationDiffSeconds >= 0 ? '+' : ''}${durationDiffSeconds.toFixed(1)}s)`
      : `ခန့်မှန်းစကားပြောအရှည် ${measuredOrEst.toFixed(1)}s (90% Target: ${targetRecapDuration.toFixed(1)}s)`,
  });

  // 8. Full Ending Coverage
  const lastBeat = beats[beats.length - 1];
  const lastSeg = segments[segments.length - 1];
  const lastMapping = mappings[mappings.length - 1];
  const fullEndingCovered = Boolean(
    lastBeat &&
      lastSeg &&
      String(lastSeg.myanmarText || '').trim().length >= 8 &&
      (!lastMapping || lastMapping.storyStage === 'full_ending') &&
      lastBeat.end >= safeVideoDur - 1.0
  );
  checks.push({
    key: 'full_ending',
    passed: fullEndingCovered,
    severity: fullEndingCovered ? 'pass' : 'warning',
    messageMy: fullEndingCovered
      ? 'ဇာတ်လမ်းနောက်ဆုံးအခန်းနှင့် Full Ending အပြည့်အစုံ ပါဝင်ပါသည်'
      : 'ဇာတ်သိမ်းပိုင်း (Full Ending) စာသား တိုနေသဖြင့် ထပ်မံစစ်ဆေးပါ',
  });

  // 9. Burmese Language Quality
  const burmeseCount = (fullText.match(BURMESE_CHAR_RE) || []).length;
  const hasLeaks = LEAKED_LABEL_RE.test(fullText);
  const burmeseQualityOk = burmeseCount >= Math.max(8, segments.length * 4) && !hasLeaks;
  checks.push({
    key: 'burmese_quality',
    passed: burmeseQualityOk,
    severity: burmeseCount === 0 ? 'critical' : burmeseQualityOk ? 'pass' : 'warning',
    messageMy: burmeseQualityOk
      ? 'သဘာဝကျသော မြန်မာစကားပြော Recap စတိုင် မှန်ကန်ပါသည်'
      : hasLeaks
        ? 'စာသားထဲတွင် Narration/Dialogue label များ ကျန်ရှိနေပါသည်'
        : 'မြန်မာစကားလုံး ပါဝင်မှု နည်းပါးနေပါသည်',
  });

  const criticalErrors = checks.filter((c) => c.severity === 'critical').map((c) => c.messageMy);
  const warnings = checks.filter((c) => c.severity === 'warning').map((c) => c.messageMy);

  let score = 100;
  for (const c of checks) {
    if (c.severity === 'critical') score -= 30;
    else if (c.severity === 'warning') score -= 8;
  }
  score = Math.max(0, Math.min(100, score));

  const canRender = criticalErrors.length === 0;
  const passed = canRender && warnings.length === 0;

  return {
    passed,
    canRender,
    score,
    originalVideoDuration: Number(safeVideoDur.toFixed(2)),
    targetRecapDuration,
    actualTtsDuration: Number(measuredOrEst.toFixed(2)),
    durationDiffSeconds,
    coverageRatio,
    videoSpeedLocked: Number(videoPlaybackRate.toFixed(2)),
    fullEndingCovered,
    checks,
    warnings,
    criticalErrors,
  };
}


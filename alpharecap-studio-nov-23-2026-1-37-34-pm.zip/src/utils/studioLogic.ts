import type {
  AutoBlurConfig,
  AutoBlurRegion,
  AutoBlurStyle,
  CaptionDecorationConfig,
  CaptionFontSizePreset,
  CaptionSegment,
  CreditPackage,
  EdgeVoiceId,
  MyanmarVoiceId,
  OverlayPosition,
  StudioTool,
  TtsEngineId,
  VideoTimelineSegment,
  VoiceGender,
  VoiceSpeed,
  WizardStep,
} from '../types/studio';

export const MAX_VIDEO_DURATION_SECONDS = 120 * 60; // 120 minutes
export const MAX_THUMBNAIL_TITLE_CHARS = 24; // strictly under 25 characters

export const CREDIT_PACKAGES: CreditPackage[] = [
  {
    id: 'starter',
    nameMy: 'Starter Pack',
    credits: 50,
    priceMmk: 15000,
    priceThb: 149,
    descriptionMy: 'Recap ဗီဒီယို ၅ ပုဒ်အထိ စတင်ဖန်တီးနိုင်သည်',
  },
  {
    id: 'creator',
    nameMy: 'Creator Pro Pack',
    credits: 150,
    priceMmk: 39000,
    priceThb: 379,
    descriptionMy: '4K Export နှင့် Dubbing အတွက် အသင့်တော်ဆုံး',
  },
  {
    id: 'studio',
    nameMy: 'Studio Unlimited Pack',
    credits: 500,
    priceMmk: 115000,
    priceThb: 1090,
    descriptionMy: 'Channel ကြီးများအတွက် သက်တမ်းမကုန် Credit အများဆုံး',
  },
];

export type SupportedPlatform = 'YouTube' | 'TikTok' | 'Facebook' | 'Instagram';

export interface UrlValidationResult {
  valid: boolean;
  platform?: SupportedPlatform;
  errorMy?: string;
}

export function validateVideoUrl(rawUrl: string): UrlValidationResult {
  const trimmed = rawUrl.trim();
  if (!trimmed) {
    return {
      valid: false,
      errorMy: 'ဗီဒီယိုလင့်ခ် ထည့်သွင်းပေးပါ (YouTube, TikTok, Facebook သို့မဟုတ် Instagram)',
    };
  }

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return {
      valid: false,
      errorMy: 'လင့်ခ်ပုံစံ မှားယွင်းနေပါသည် — https:// ဖြင့် စတင်သော လင့်ခ်အပြည့်အစုံ ထည့်ပါ',
    };
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return {
      valid: false,
      errorMy: 'HTTP သို့မဟုတ် HTTPS အများသုံးလင့်ခ်သာ လက်ခံပါသည်',
    };
  }

  const host = parsed.hostname.toLowerCase().replace(/^www\./, '');

  if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'youtu.be') {
    return { valid: true, platform: 'YouTube' };
  }
  if (host === 'tiktok.com' || host.endsWith('.tiktok.com')) {
    return { valid: true, platform: 'TikTok' };
  }
  if (host === 'facebook.com' || host === 'm.facebook.com' || host === 'fb.watch') {
    return { valid: true, platform: 'Facebook' };
  }
  if (host === 'instagram.com' || host.endsWith('.instagram.com')) {
    return { valid: true, platform: 'Instagram' };
  }

  return {
    valid: false,
    errorMy: 'YouTube, TikTok, Facebook နှင့် Instagram Public လင့်ခ်များကိုသာ ပံ့ပိုးပါသည်',
  };
}

export function validateVideoDuration(durationSeconds: number): {
  valid: boolean;
  errorMy?: string;
} {
  if (!Number.isFinite(durationSeconds) || durationSeconds <= 0) {
    return {
      valid: false,
      errorMy: 'ဗီဒီယိုကြာချိန် မမှန်ကန်ပါ',
    };
  }
  if (durationSeconds > MAX_VIDEO_DURATION_SECONDS) {
    return {
      valid: false,
      errorMy: 'ဗီဒီယိုအရှည်သည် အများဆုံး ၁၂၀ မိနစ် (၂ နာရီ) ထက် မကျော်လွန်ရပါ',
    };
  }
  return { valid: true };
}

export function clampOverlayPosition(x: number, y: number): OverlayPosition {
  const clamp = (val: number) => Math.min(92, Math.max(8, Math.round(val * 10) / 10));
  return {
    x: clamp(Number.isFinite(x) ? x : 50),
    y: clamp(Number.isFinite(y) ? y : 50),
  };
}

export function countCharacters(text: string): number {
  if (typeof Intl !== 'undefined' && 'Segmenter' in Intl) {
    const segmenter = new Intl.Segmenter('my', { granularity: 'grapheme' });
    let count = 0;
    for (const _ of segmenter.segment(text)) {
      count += 1;
    }
    return count;
  }
  return Array.from(text).length;
}

export function truncateThumbnailTitle(title: string, maxChars = MAX_THUMBNAIL_TITLE_CHARS): string {
  const normalized = title.replace(/\s+/g, ' ').trim();
  if (!normalized) return '';
  if (typeof Intl !== 'undefined' && 'Segmenter' in Intl) {
    const segmenter = new Intl.Segmenter('my', { granularity: 'grapheme' });
    const graphemes: string[] = [];
    for (const seg of segmenter.segment(normalized)) {
      graphemes.push(seg.segment);
      if (graphemes.length >= maxChars) break;
    }
    return graphemes.join('').trim();
  }
  return Array.from(normalized).slice(0, maxChars).join('').trim();
}

export const VOICE_SPEED_STEPS = [1.0, 1.2, 1.4, 1.6, 1.8, 2.0] as const;

export const VOICE_SPEED_PRESETS = [
  { id: 'slow' as const, labelMy: 'နှေး (Slow)', rateLabel: '0.85x' },
  { id: 'normal' as const, labelMy: 'ပုံမှန် (Normal)', rateLabel: '1.0x' },
  { id: 'fast' as const, labelMy: 'မြန် (Fast)', rateLabel: '1.2x' },
] as const;

export function parseVoiceSpeedInput(raw: unknown): VoiceSpeed {
  if (typeof raw === 'number' && Number.isFinite(raw)) {
    return Math.round(Math.min(2.0, Math.max(0.5, raw)) * 100) / 100;
  }
  const str = String(raw || '').trim().toLowerCase();
  if (str === 'slow' || str === 'normal' || str === 'fast') {
    return str;
  }
  if (str === '2x') return 2.0;
  return normalizeVoiceSpeed(raw);
}

export function normalizeVoiceSpeed(raw: unknown): number {
  if (typeof raw === 'number' && Number.isFinite(raw)) {
    return Math.round(Math.min(2.0, Math.max(1.0, raw)) * 10) / 10;
  }
  const str = String(raw || '').trim().toLowerCase();
  if (str === 'slow') return 0.85;
  if (str === 'normal' || str === '') return 1.0;
  if (str === 'fast') return 1.4;
  if (str === '2x') return 2.0;
  const parsed = Number(str.replace(/x$/i, ''));
  if (Number.isFinite(parsed) && parsed > 0) {
    return Math.round(Math.min(2.0, Math.max(1.0, parsed)) * 10) / 10;
  }
  return 1.0;
}

export function formatVoiceSpeedLabel(speed: VoiceSpeed): string {
  if (speed === 'slow') return 'Slow (0.85x)';
  if (speed === 'fast') return 'Fast (1.2x)';
  if (speed === 'normal') return 'Normal (1.0x)';
  const factor = getVoiceSpeedFactor(speed);
  return `${factor.toFixed(1)}x`;
}

export function getVoiceSpeedFactor(speed: VoiceSpeed): number {
  if (typeof speed === 'number' && Number.isFinite(speed)) {
    return Math.round(Math.min(2.0, Math.max(0.5, speed)) * 100) / 100;
  }
  switch (speed) {
    case 'slow':
      return 0.85;
    case 'fast':
      return 1.22;
    case '2x':
      return 2.0;
    case 'normal':
    default:
      return 1.0;
  }
}

export function normalizeVoiceGender(raw: unknown): VoiceGender | null {
  const str = String(raw || '').trim().toLowerCase();
  if (str === 'male') return 'male';
  if (str === 'female') return 'female';
  return null;
}

export function validateVoiceGenderForTool(
  tool: StudioTool,
  rawGender: unknown
): { valid: boolean; gender: VoiceGender | null; errorMy?: string } {
  if (tool === 'captions') {
    return { valid: true, gender: null };
  }
  const normalized = normalizeVoiceGender(rawGender);
  if (!normalized) {
    return {
      valid: false,
      gender: null,
      errorMy: 'မြန်မာ AI TTS အသံထုတ်လုပ်ရန် အမျိုးသား (Thiha · Male) သို့မဟုတ် အမျိုးသမီး (Nilar · Female) အသံကို ရွေးချယ်ပါ',
    };
  }
  return { valid: true, gender: normalized };
}

export const DEFAULT_TTS_ENGINE: TtsEngineId = 'edge-tts';
export const DEFAULT_EDGE_VOICE_ID: EdgeVoiceId = 'my-MM-NilarNeural';

export const EDGE_BURMESE_VOICES: Record<
  EdgeVoiceId,
  {
    id: EdgeVoiceId;
    gender: VoiceGender;
    displayName: string;
    labelMy: string;
    descMy: string;
    sampleTextMy: string;
  }
> = {
  'my-MM-NilarNeural': {
    id: 'my-MM-NilarNeural',
    gender: 'female',
    displayName: 'Nilar Neural',
    labelMy: 'Nilar (my-MM-NilarNeural · Female)',
    descMy: 'သဘာဝကျပြီး ကြည်လင်ပြတ်သားသော မြန်မာအမျိုးသမီး Neural အသံ (Default · API Key မလို)',
    sampleTextMy: 'မင်္ဂလာပါ။ ကျွန်မက နီလာ ဖြစ်ပါတယ်။ ဒီဇာတ်ကားထဲက အဓိကအဖြစ်အပျက်ကို အတူတူ ကြည့်လိုက်ရအောင်။',
  },
  'my-MM-ThihaNeural': {
    id: 'my-MM-ThihaNeural',
    gender: 'male',
    displayName: 'Thiha Neural',
    labelMy: 'Thiha (my-MM-ThihaNeural · Male)',
    descMy: 'တည်ငြိမ်အားပါပြီး နားထောင်ကောင်းသော မြန်မာအမျိုးသား Neural အသံ (API Key မလို)',
    sampleTextMy: 'မင်္ဂလာပါ ခင်ဗျာ။ ကျွန်တော်က သီဟ ဖြစ်ပါတယ်။ ဒီညရဲ့ လျှို့ဝှက်ဆန်းကြယ် ဇာတ်လမ်းကို စတင်လိုက်ကြရအောင်။',
  },
};

export function assertValidEdgeVoiceId(explicitVoiceId?: unknown): EdgeVoiceId {
  const rawId = String(explicitVoiceId ?? '').trim();
  if (!rawId) return DEFAULT_EDGE_VOICE_ID;
  if (rawId === 'my-MM-NilarNeural' || rawId === 'my-MM-ThihaNeural') {
    return rawId;
  }
  throw new Error(`Unsupported Edge Burmese voice ID: "${rawId}" (never silently switching voices)`);
}

export function resolveEdgeVoiceForGender(
  voiceGender?: VoiceGender | null,
  explicitVoiceId?: unknown
): EdgeVoiceId {
  const rawId = String(explicitVoiceId || '').trim();
  if (rawId) {
    return assertValidEdgeVoiceId(rawId);
  }
  if (voiceGender === 'male') {
    return 'my-MM-ThihaNeural';
  }
  // Nilar is the default Burmese Neural voice
  return DEFAULT_EDGE_VOICE_ID;
}

export function normalizeTtsEngineId(raw?: unknown): TtsEngineId {
  return String(raw || '').trim().toLowerCase() === 'gemini-tts' ? 'gemini-tts' : 'edge-tts';
}

export function formatEdgeVoiceLabelMy(voiceId: EdgeVoiceId): string {
  return EDGE_BURMESE_VOICES[voiceId]?.labelMy || EDGE_BURMESE_VOICES[DEFAULT_EDGE_VOICE_ID].labelMy;
}

export function enforceSingleVoiceForDubbingSegments(
  segments: VideoTimelineSegment[],
  voiceGender: VoiceGender
): VideoTimelineSegment[] {
  return segments.map((seg) =>
    seg.kind === 'speaking'
      ? { ...seg, voiceGender }
      : { ...seg, voiceGender: undefined }
  );
}

export function formatVoiceGenderLabelMy(gender?: VoiceGender | null): string {
  if (gender === 'male') return 'အမျိုးသားအသံ (Thiha · Male)';
  if (gender === 'female') return 'အမျိုးသမီးအသံ (Nilar · Female)';
  return '';
}

export function sanitizeTtsSpeechText(rawText: string): string {
  const withoutTags = String(rawText || '')
    // Remove bracketed/parenthetical non-speech stage cues like [Music], (applause), [sfx]
    .replace(/\[(?:music|applause|laughter|silence|noise|sfx|sound|cheering|sighs?|groans?)\]/gi, ' ')
    .replace(/\((?:music|applause|laughter|silence|noise|sfx|sound|cheering|sighs?|groans?)\)/gi, ' ')
    // Remove emojis / pictographs / variation selectors
    .replace(/[\p{Extended_Pictographic}\uFE0E\uFE0F]/gu, ' ')
    // Remove markdown emphasis/header tokens
    .replace(/[*_`~#<>|]/g, ' ')
    // Remove ASCII/C0 control characters
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Check if any actual letters or digits remain (Unicode letters + Myanmar marks/digits)
  const speakableCore = withoutTags.replace(/[\p{P}\p{S}\s]/gu, '');
  if (!withoutTags || !speakableCore) {
    return '';
  }
  return withoutTags;
}

export function validateEdgeTtsInputText(rawText: string): string {
  const cleaned = sanitizeTtsSpeechText(rawText);
  if (!cleaned) {
    throw new Error('TTS စာသား အလွတ်ဖြစ်နေသဖြင့် အသံထုတ်လုပ်၍မရပါ');
  }
  return cleaned;
}

export function splitTextIntoTtsChunks(rawText: string, maxChars = 850): string[] {
  const cleaned = sanitizeTtsSpeechText(rawText);
  if (!cleaned) return [];
  const limit = Math.max(180, Math.min(2000, Math.round(maxChars)));
  if (cleaned.length <= limit) return [cleaned];

  // Split at sentence endings while preserving sentence punctuation
  const sentences = cleaned
    .split(/(?<=[။.!?])\s+|\n+/)
    .map((s) => s.trim())
    .filter((s) => Boolean(sanitizeTtsSpeechText(s)));

  const chunks: string[] = [];
  let current = '';

  const pushOversizedSentence = (sentence: string) => {
    const words = sentence.split(/\s+/).filter(Boolean);
    let piece = '';
    for (const w of words) {
      const candidate = piece ? `${piece} ${w}` : w;
      if (candidate.length > limit && piece) {
        chunks.push(piece);
        piece = w;
      } else if (w.length > limit) {
        if (piece) {
          chunks.push(piece);
          piece = '';
        }
        const chars = Array.from(w);
        for (let i = 0; i < chars.length; i += limit) {
          const part = chars.slice(i, i + limit).join('').trim();
          if (part) chunks.push(part);
        }
      } else {
        piece = candidate;
      }
    }
    if (piece.trim()) chunks.push(piece.trim());
  };

  for (const sentence of sentences) {
    const candidate = current ? `${current} ${sentence}` : sentence;
    if (candidate.length <= limit) {
      current = candidate;
    } else {
      if (current) {
        chunks.push(current);
        current = '';
      }
      if (sentence.length > limit) {
        pushOversizedSentence(sentence);
      } else {
        current = sentence;
      }
    }
  }
  if (current) chunks.push(current);

  return chunks.filter((c) => Boolean(sanitizeTtsSpeechText(c)));
}

export interface AudioVolumeStats {
  maxVolumeDb: number | null;
  meanVolumeDb: number | null;
}

export function parseFfmpegVolumeStats(stderr: string): AudioVolumeStats {
  const text = String(stderr || '');
  const maxMatch = text.match(/max_volume:\s*(-inf|-?\d+(?:\.\d+)?)\s*dB/i);
  const meanMatch = text.match(/mean_volume:\s*(-inf|-?\d+(?:\.\d+)?)\s*dB/i);
  const parseDb = (raw?: string): number | null => {
    if (!raw) return null;
    if (raw.toLowerCase() === '-inf') return -Infinity;
    const n = Number(raw);
    return Number.isFinite(n) ? n : null;
  };
  return {
    maxVolumeDb: parseDb(maxMatch?.[1]),
    meanVolumeDb: parseDb(meanMatch?.[1]),
  };
}

export function isAudibleNonSilentStats(
  stats: AudioVolumeStats,
  durationSeconds: number
): { valid: boolean; reason?: string } {
  if (!Number.isFinite(durationSeconds) || durationSeconds < 0.15) {
    return { valid: false, reason: `Audio duration too short (${durationSeconds}s)` };
  }
  if (stats.maxVolumeDb === null || !Number.isFinite(stats.maxVolumeDb) || stats.maxVolumeDb <= -75) {
    return {
      valid: false,
      reason: `Generated audio is silent or invalid (max_volume=${stats.maxVolumeDb} dB)`,
    };
  }
  if (stats.meanVolumeDb !== null && (!Number.isFinite(stats.meanVolumeDb) || stats.meanVolumeDb <= -85)) {
    return {
      valid: false,
      reason: `Generated audio mean level too low (mean_volume=${stats.meanVolumeDb} dB)`,
    };
  }
  return { valid: true };
}

export const GEMINI_FREE_VOICES: ReadonlyArray<{
  id: MyanmarVoiceId;
  nameMy: string;
  tagMy: string;
  descMy: string;
  sampleTextMy: string;
  femaleDirective: string;
  maleDirective: string;
  preferExpressiveModel?: boolean;
}> = [
  {
    id: 'street_bro',
    nameMy: 'ရန်ကုန်လမ်းဘေးစကားပြော (Street Slang)',
    tagMy: 'Recap · Viral',
    descMy: 'YouTube / TikTok Movie Recap များအတွက် သွက်လက်ဆွဲဆောင်မှုရှိသော စကားပြောပုံစံ',
    sampleTextMy: 'ဟေ့ကောင်တွေ ဒီညကတော့ တကယ်မလွယ်ဘူးနော်။ အလှည့်အပြောင်းကြီးက အခုမှ စမှာ!',
    femaleDirective:
      'Speak as a lively, charismatic young FEMALE Myanmar (Burmese) woman narrator with a clear, energetic feminine voice and engaging YouTube movie-recapper tone.',
    maleDirective:
      'Speak as a lively, charismatic young MALE Myanmar (Burmese) man narrator with a distinct confident masculine voice and energetic YouTube street-slang movie-recapper tone.',
  },
  {
    id: 'thriller_narrator',
    nameMy: 'သည်းထိတ်ရင်ဖို ဇာတ်ကြောင်းပြန် (Suspense)',
    tagMy: 'Mystery',
    descMy: 'လျှို့ဝှက်ဆန်းကြယ်နှင့် မှုခင်း Action ဇာတ်ကားများအတွက် စိတ်လှုပ်ရှားဖွယ်ရာ အသံ',
    sampleTextMy: 'မိုးရွာနေတဲ့ညမှာ စုံထောက်ကြီး တစ်ယောက်တည်း စောင့်နေတယ်။ နောက်ကွယ်က လျှို့ဝှက်ချက်က ဘာလဲ။',
    femaleDirective:
      'Speak as an expressive adult FEMALE Myanmar (Burmese) woman narrator with a clear feminine voice, suspenseful and captivating cinematic mystery storyteller tone.',
    maleDirective:
      'Speak as an expressive adult MALE Myanmar (Burmese) man narrator with a deep, confident masculine voice and suspenseful cinematic mystery storyteller tone.',
  },
  {
    id: 'dramatic_story',
    nameMy: 'ခံစားချက်ဇာတ်လမ်းပြော (Dramatic Story)',
    tagMy: 'Drama',
    descMy: 'ဒရာမာနှင့် ဇာတ်ရှိန်မြင့် ဇာတ်ဝင်ခန်းများအတွက် ခံစားမှုအပြည့် အသံ',
    sampleTextMy: 'ဘယ်သူမှ မထင်မှတ်ထားတဲ့ အချိန်မှာ သူတို့နှစ်ယောက်ရဲ့ ကံကြမ္မာက အပြီးတိုင် ပြောင်းလဲသွားခဲ့တယ်။',
    femaleDirective:
      'Speak as a warm, expressive adult FEMALE Myanmar (Burmese) woman narrator with a natural feminine vocal pitch and deeply emotional drama storyteller tone.',
    maleDirective:
      'Speak as a warm, expressive adult MALE Myanmar (Burmese) man narrator with a rich masculine vocal pitch and heartfelt drama storyteller tone.',
  },
  {
    id: 'documentary_deep',
    nameMy: 'မှတ်တမ်းရုပ်ရှင် ခန့်ညားသံ (Documentary)',
    tagMy: 'Docu',
    descMy: 'သမိုင်း၊ သိပ္ပံနှင့် မှတ်တမ်းဗီဒီယိုများအတွက် တည်ငြိမ်ခန့်ညားသော ပုံပြောသံ',
    sampleTextMy: 'ရာစုနှစ်ပေါင်းများစွာ တိမ်မြုပ်နေခဲ့တဲ့ ရှေးဟောင်းမြို့တော်ကြီးရဲ့ လျှို့ဝှက်ချက်ကို အခု ဖော်ထုတ်လိုက်ပါပြီ။',
    femaleDirective:
      'Speak as an authoritative, poised adult FEMALE Myanmar (Burmese) documentary narrator with a resonant, measured, cinematic voice.',
    maleDirective:
      'Speak as an authoritative, resonant adult MALE Myanmar (Burmese) documentary narrator with a deep, calm, cinematic baritone voice.',
  },
  {
    id: 'anime_energetic',
    nameMy: 'Anime & Action တက်ကြွသံ (High-Energy)',
    tagMy: 'Anime',
    descMy: 'Anime, Gaming နှင့် Fight Scene များအတွက် အားမာန်အပြည့် တက်ကြွမြူးကြွသော အသံ',
    sampleTextMy: 'အခုချိန်ကစပြီး ငါ့ရဲ့ တကယ့်စွမ်းအားအစစ်ကို ထုတ်ပြဖို့ အချိန်တန်ပြီ!',
    femaleDirective:
      'Speak as an energetic, bright young FEMALE Myanmar (Burmese) anime and action narrator with high enthusiasm and punchy dramatic emphasis.',
    maleDirective:
      'Speak as an energetic, spirited young MALE Myanmar (Burmese) anime and action narrator with bold intensity and dynamic pacing.',
    preferExpressiveModel: true,
  },
  {
    id: 'horror_whisper',
    nameMy: 'သရဲ/ညသန်းခေါင် ခြောက်ခြားသံ (Dark Horror)',
    tagMy: 'Horror',
    descMy: 'သရဲဇာတ်လမ်း၊ ခြောက်ခြားဖွယ်ရာနှင့် ညဘက်ဇာတ်လမ်းပြောများအတွက် အေးစက်နက်ရှိုင်းသံ',
    sampleTextMy: 'ညသန်းခေါင်ယံ တံခါးခေါက်သံ ကြားရင် ဘယ်တော့မှ ထွက်မကြည့်ပါနဲ့။ အပြင်မှာ လူသားမဟုတ်ဘူး။',
    femaleDirective:
      'Speak as an eerie, low-voiced adult FEMALE Myanmar (Burmese) horror storyteller with hushed tension, chilling atmosphere, and slow dramatic pauses.',
    maleDirective:
      'Speak as an eerie, grave adult MALE Myanmar (Burmese) horror storyteller with a dark, hushed baritone, chilling suspense, and deliberate pauses.',
    preferExpressiveModel: true,
  },
  {
    id: 'comedy_chill',
    nameMy: 'ဟာသနှင့် ပေါ့ပါးဖျော်ဖြေသံ (Witty Comedy)',
    tagMy: 'Comedy',
    descMy: 'ဟာသကားများ၊ Meme နှင့် ပေါ့ပေါ့ပါးပါး Entertainment ဗီဒီယိုများအတွက် ရွှင်လန်းသံ',
    sampleTextMy: 'အမလေးဟယ်! ဒီလောက်ထိ လွဲချော်သွားမယ်လို့တော့ ဘယ်သူမှ ထင်မထားမိဘူး။',
    femaleDirective:
      'Speak as a cheerful, playful young FEMALE Myanmar (Burmese) comedy host with bright inflection, witty timing, and friendly conversational charm.',
    maleDirective:
      'Speak as a cheerful, witty young MALE Myanmar (Burmese) comedy host with upbeat inflection, playful comedic timing, and relaxed charm.',
  },
  {
    id: 'news_anchor',
    nameMy: 'သတင်းနှင့် ဗဟုသုတ ပြတ်သားသံ (Crisp Explainer)',
    tagMy: 'Explainer',
    descMy: 'Tech, Business နှင့် ရှင်းလင်းတင်ပြချက် ဗီဒီယိုများအတွက် ကြည်လင်ပြတ်သားသော အသံ',
    sampleTextMy: 'ဒီနေ့မှာတော့ နည်းပညာလောကကို အပြောင်းအလဲ ဖြစ်စေမယ့် အရေးကြီးအချက် သုံးခုကို ရှင်းပြပေးပါမယ်။',
    femaleDirective:
      'Speak as a polished, articulate adult FEMALE Myanmar (Burmese) news anchor and tech explainer with crystal-clear diction and steady cadence.',
    maleDirective:
      'Speak as a polished, articulate adult MALE Myanmar (Burmese) news anchor and tech explainer with crisp broadcast diction and steady authority.',
  },
  {
    id: 'romance_warm',
    nameMy: 'နွေးထွေး ချိုသာ ပုံပြောသံ (Soft Romance)',
    tagMy: 'Romance',
    descMy: 'အချစ်ဇာတ်လမ်း၊ K-Drama နှင့် ကြည်နူးဖွယ် ဇာတ်လမ်းများအတွက် ညင်သာချိုမြသော အသံ',
    sampleTextMy: 'နှစ်တွေ ဘယ်လောက်ကြာသွားပါစေ သူမရဲ့ အပြုံးလေးကတော့ ရင်ထဲမှာ အမြဲတမ်း ရှိနေဆဲပါ။',
    femaleDirective:
      'Speak as a gentle, tender, melodic young FEMALE Myanmar (Burmese) romance storyteller with a soft, affectionate, heartwarming tone.',
    maleDirective:
      'Speak as a gentle, sincere, smooth adult MALE Myanmar (Burmese) romance storyteller with a warm, affectionate, soothing tone.',
  },
  {
    id: 'trailer_epic',
    nameMy: 'ရုပ်ရှင် Trailer ကြေညာသံ (Epic Trailer)',
    tagMy: 'Trailer',
    descMy: 'Teaser နှင့် Blockbuster ရုပ်ရှင်မိတ်ဆက်များအတွက် အသံဩဇာပြည့်ဝသော ကြေညာသံ',
    sampleTextMy: 'မျှော်လင့်ချက်အားလုံး ပျောက်ဆုံးသွားတဲ့ ကမ္ဘာကြီးမှာ နောက်ဆုံးသူရဲကောင်းတစ်ဦး ပေါ်ထွက်လာပြီ။',
    femaleDirective:
      'Speak as a commanding, theatrical adult FEMALE Myanmar (Burmese) movie trailer voiceover artist with epic cinematic power and resonant gravitas.',
    maleDirective:
      'Speak as a booming, commanding adult MALE Myanmar (Burmese) movie trailer voiceover artist with epic blockbuster gravitas and dramatic punch.',
    preferExpressiveModel: true,
  },
];

export function normalizeMyanmarVoiceId(raw?: unknown): MyanmarVoiceId {
  const key = String(raw || '').trim();
  const matched = GEMINI_FREE_VOICES.find((v) => v.id === key);
  return matched ? matched.id : 'street_bro';
}

export function getGeminiFreeVoice(voiceStyle?: unknown) {
  const normalized = normalizeMyanmarVoiceId(voiceStyle);
  return GEMINI_FREE_VOICES.find((v) => v.id === normalized) ?? GEMINI_FREE_VOICES[0];
}

export function buildTtsVoicePersonaDirective(
  voiceGender: VoiceGender,
  voiceStyle: MyanmarVoiceId = 'street_bro'
): string {
  const voice = getGeminiFreeVoice(voiceStyle);
  return voiceGender === 'female' ? voice.femaleDirective : voice.maleDirective;
}

export function calculateCreditCost(
  tool: StudioTool,
  is4k: boolean,
  durationSeconds = 60
): number {
  const baseCost = tool === 'recap' ? 10 : tool === 'dubbing' ? 8 : 5;
  const durationMultiplier = durationSeconds > 1800 ? 2 : 1; // > 30 mins adds scaling
  const ultraHdCost = is4k ? 4 : 0;
  return baseCost * durationMultiplier + ultraHdCost;
}

export function getActiveCaptionAtTime(
  captions: CaptionSegment[],
  currentTimeSeconds: number
): CaptionSegment | null {
  for (const seg of captions) {
    if (currentTimeSeconds >= seg.start && currentTimeSeconds <= seg.end) {
      return seg;
    }
  }
  return null;
}

export function formatTimecode(seconds: number): string {
  const safe = Math.max(0, Math.floor(Number.isFinite(seconds) ? seconds : 0));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  if (hrs > 0) {
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function wrapWavHeaderIfNeeded(
  audioBytes: Uint8Array,
  sampleRate = 24000,
  channels = 1,
  bitsPerSample = 16
): Uint8Array {
  // Check for RIFF header
  if (
    audioBytes.length >= 12 &&
    audioBytes[0] === 0x52 && // R
    audioBytes[1] === 0x49 && // I
    audioBytes[2] === 0x46 && // F
    audioBytes[3] === 0x46 // F
  ) {
    return audioBytes;
  }

  const byteRate = (sampleRate * channels * bitsPerSample) / 8;
  const blockAlign = (channels * bitsPerSample) / 8;
  const dataSize = audioBytes.length;
  const header = new ArrayBuffer(44);
  const view = new DataView(header);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, channels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);
  writeStr(36, 'data');
  view.setUint32(40, dataSize, true);

  const combined = new Uint8Array(44 + dataSize);
  combined.set(new Uint8Array(header), 0);
  combined.set(audioBytes, 44);
  return combined;
}

export function formatAssTime(seconds: number): string {
  const safe = Math.max(0, seconds);
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = Math.floor(safe % 60);
  const centis = Math.floor((safe - Math.floor(safe)) * 100);
  return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(centis).padStart(2, '0')}`;
}

export function formatSrtTime(seconds: number): string {
  const safeMs = Math.max(0, Math.round((Number.isFinite(seconds) ? seconds : 0) * 1000));
  const hrs = Math.floor(safeMs / 3_600_000);
  const mins = Math.floor((safeMs % 3_600_000) / 60_000);
  const secs = Math.floor((safeMs % 60_000) / 1000);
  const ms = safeMs % 1000;
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
}

export const CAPTION_FONT_SIZE_PRESETS: Record<CaptionFontSizePreset, number> = {
  small: 0.82,
  medium: 1.0,
  large: 1.35,
};

export const DEFAULT_CAPTION_DECORATION: CaptionDecorationConfig = {
  fontSizePreset: 'medium',
  fontSizeScale: 1.0,
  textColor: '#FFFFFF',
  borderEnabled: true,
  borderThickness: 2,
  borderColor: '#090B10',
  blurBgEnabled: true,
  blurIntensity: 10,
  bgOpacity: 72,
  bgColor: '#090B10',
  bgCornerRadius: 12,
};

export function normalizeHexColor(raw: unknown, fallback = '#FFFFFF'): string {
  const str = String(raw || '').trim();
  const full = str.match(/^#([0-9a-fA-F]{6})$/);
  if (full) return `#${full[1].toUpperCase()}`;
  const short = str.match(/^#([0-9a-fA-F]{3})$/);
  if (short) {
    const [r, g, b] = short[1].split('');
    return `#${r}${r}${g}${g}${b}${b}`.toUpperCase();
  }
  return fallback;
}

export function sanitizeCaptionDecoration(
  raw?: Partial<CaptionDecorationConfig> | null
): CaptionDecorationConfig {
  const d = raw || {};
  const scaleRaw = Number(d.fontSizeScale);
  const fontSizeScale = Number.isFinite(scaleRaw)
    ? Math.round(Math.min(1.7, Math.max(0.7, scaleRaw)) * 100) / 100
    : DEFAULT_CAPTION_DECORATION.fontSizeScale;

  const fontSizePreset: CaptionFontSizePreset =
    d.fontSizePreset === 'small' || d.fontSizePreset === 'medium' || d.fontSizePreset === 'large'
      ? d.fontSizePreset
      : fontSizeScale <= 0.9
        ? 'small'
        : fontSizeScale >= 1.2
          ? 'large'
          : 'medium';

  const thickRaw = Number(d.borderThickness);
  const borderThickness = Number.isFinite(thickRaw)
    ? Math.round(Math.min(10, Math.max(1, thickRaw)) * 10) / 10
    : DEFAULT_CAPTION_DECORATION.borderThickness;

  const blurRaw = Number(d.blurIntensity);
  const blurIntensity = Number.isFinite(blurRaw)
    ? Math.round(Math.min(24, Math.max(0, blurRaw)))
    : DEFAULT_CAPTION_DECORATION.blurIntensity;

  const opacityRaw = Number(d.bgOpacity);
  const bgOpacity = Number.isFinite(opacityRaw)
    ? Math.round(Math.min(100, Math.max(0, opacityRaw)))
    : DEFAULT_CAPTION_DECORATION.bgOpacity;

  const radiusRaw = Number(d.bgCornerRadius);
  const bgCornerRadius = Number.isFinite(radiusRaw)
    ? Math.round(Math.min(28, Math.max(0, radiusRaw)))
    : DEFAULT_CAPTION_DECORATION.bgCornerRadius;

  return {
    fontSizePreset,
    fontSizeScale,
    textColor: normalizeHexColor(d.textColor, DEFAULT_CAPTION_DECORATION.textColor),
    borderEnabled:
      typeof d.borderEnabled === 'boolean' ? d.borderEnabled : DEFAULT_CAPTION_DECORATION.borderEnabled,
    borderThickness,
    borderColor: normalizeHexColor(d.borderColor, DEFAULT_CAPTION_DECORATION.borderColor),
    blurBgEnabled:
      typeof d.blurBgEnabled === 'boolean' ? d.blurBgEnabled : DEFAULT_CAPTION_DECORATION.blurBgEnabled,
    blurIntensity,
    bgOpacity,
    bgColor: normalizeHexColor(d.bgColor, DEFAULT_CAPTION_DECORATION.bgColor),
    bgCornerRadius,
  };
}

export function hexToRgba(hex: string, opacityPercent: number): string {
  const clean = normalizeHexColor(hex, '#090B10').slice(1);
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  const alpha = Math.min(1, Math.max(0, opacityPercent / 100));
  return `rgba(${r}, ${g}, ${b}, ${Number(alpha.toFixed(3))})`;
}

export function hexToAssColor(hex: string, opacityPercent = 100): string {
  const clean = normalizeHexColor(hex, '#FFFFFF').slice(1);
  const r = clean.slice(0, 2);
  const g = clean.slice(2, 4);
  const b = clean.slice(4, 6);
  // ASS alpha: 00 = fully opaque, FF = fully transparent
  const alphaNum = Math.round((1 - Math.min(100, Math.max(0, opacityPercent)) / 100) * 255);
  const aa = alphaNum.toString(16).padStart(2, '0').toUpperCase();
  return `&H${aa}${b}${g}${r}`;
}

export const CAPTION_BOX_MAX_WIDTH_PCT = 72;
export const CAPTION_MAX_LINES = 2;
export const CAPTION_LINE_HEIGHT = 1.45;
export const CAPTION_BOTTOM_SAFETY_MARGIN_PCT = 9;
export const CAPTION_SIDE_SAFETY_MARGIN_PCT = 4;

const graphemeSegmenter =
  typeof Intl !== 'undefined' && typeof (Intl as { Segmenter?: unknown }).Segmenter === 'function'
    ? new Intl.Segmenter('my', { granularity: 'grapheme' })
    : null;

function splitGraphemes(input: string): string[] {
  if (!input) return [];
  if (graphemeSegmenter) {
    const out: string[] = [];
    for (const seg of graphemeSegmenter.segment(input)) {
      out.push(seg.segment);
    }
    return out;
  }
  return Array.from(input);
}

/**
 * Estimates maximum readable graphemes per line inside a caption box constrained to 72% of video width.
 */
export function estimateCaptionCharsPerLine(
  videoWidth = 1280,
  videoHeight = 720,
  fontSizeScale = 1.0
): number {
  const safeW = Math.max(160, Number.isFinite(videoWidth) && videoWidth > 0 ? videoWidth : 1280);
  const safeH = Math.max(160, Number.isFinite(videoHeight) && videoHeight > 0 ? videoHeight : 720);
  const safeScale = Math.min(1.7, Math.max(0.7, Number.isFinite(fontSizeScale) ? fontSizeScale : 1.0));
  const fontSize = Math.max(20, Math.round(safeH * 0.045 * safeScale));
  const usableBoxWidth = safeW * (CAPTION_BOX_MAX_WIDTH_PCT / 100) * 0.88;
  const approxCharAdvance = fontSize * 0.92;
  const estimated = Math.floor(usableBoxWidth / Math.max(12, approxCharAdvance));
  return Math.min(26, Math.max(12, estimated));
}

/**
 * Wraps caption text cleanly at word / clause / grapheme boundaries so no line exceeds maxCharsPerLine.
 */
export function wrapCaptionTextToLines(text: string, maxCharsPerLine = 32): string[] {
  const safeLimit = Math.max(8, Math.floor(maxCharsPerLine || 32));
  const paragraphs = String(text || '')
    .split(/\r?\n/)
    .map((p) => p.replace(/\s+/g, ' ').trim())
    .filter(Boolean);

  if (paragraphs.length === 0) return [];

  const allLines: string[] = [];

  for (const para of paragraphs) {
    const words = para.split(' ').filter(Boolean);
    let currentLine = '';
    let currentLen = 0;

    const pushTokenHard = (token: string) => {
      const graphemes = splitGraphemes(token);
      for (let i = 0; i < graphemes.length; i += safeLimit) {
        const piece = graphemes.slice(i, i + safeLimit).join('');
        if (currentLine) {
          allLines.push(currentLine);
          currentLine = '';
          currentLen = 0;
        }
        if (i + safeLimit >= graphemes.length) {
          currentLine = piece;
          currentLen = splitGraphemes(piece).length;
        } else {
          allLines.push(piece);
        }
      }
    };

    for (const word of words) {
      const wordLen = splitGraphemes(word).length;
      if (!currentLine) {
        if (wordLen <= safeLimit) {
          currentLine = word;
          currentLen = wordLen;
        } else {
          pushTokenHard(word);
        }
      } else if (currentLen + 1 + wordLen <= safeLimit) {
        currentLine = `${currentLine} ${word}`;
        currentLen += 1 + wordLen;
      } else {
        allLines.push(currentLine);
        currentLine = '';
        currentLen = 0;
        if (wordLen <= safeLimit) {
          currentLine = word;
          currentLen = wordLen;
        } else {
          pushTokenHard(word);
        }
      }
    }

    if (currentLine) {
      allLines.push(currentLine);
    }
  }

  return allLines;
}

/**
 * Enforces LONG CAPTION READABILITY RULES:
 * - Maximum 2 lines per single caption box.
 * - Any caption longer than 2 lines is automatically split into multiple sequential captions
 *   with proportional new timestamps inside its original [start, end] window.
 */
export function splitLongCaptionsToMaxTwoLines(
  captions: CaptionSegment[],
  options?: {
    videoWidth?: number;
    videoHeight?: number;
    fontSizeScale?: number;
    maxCharsPerLine?: number;
    maxLines?: number;
  }
): CaptionSegment[] {
  const maxLines = Math.max(1, Math.min(2, options?.maxLines ?? CAPTION_MAX_LINES));
  const charsPerLine =
    options?.maxCharsPerLine ??
    estimateCaptionCharsPerLine(
      options?.videoWidth ?? 1280,
      options?.videoHeight ?? 720,
      options?.fontSizeScale ?? 1.0
    );

  const result: CaptionSegment[] = [];

  for (const cap of captions) {
    const rawText = String(cap.text || '').trim();
    if (!rawText) continue;

    const lines = wrapCaptionTextToLines(rawText, charsPerLine);
    if (lines.length === 0) continue;

    const lineChunks: string[][] = [];
    for (let i = 0; i < lines.length; i += maxLines) {
      lineChunks.push(lines.slice(i, i + maxLines));
    }

    if (lineChunks.length === 1) {
      result.push({
        ...cap,
        text: lineChunks[0].join('\n'),
      });
      continue;
    }

    const start = Number(cap.start || 0);
    const end = Math.max(start + 0.2, Number(cap.end || start + 2));
    const totalDur = end - start;
    const weights = lineChunks.map((chunk) => Math.max(2, countCharacters(chunk.join(' '))));
    const totalWeight = weights.reduce((sum, w) => sum + w, 0);

    let cursor = start;
    lineChunks.forEach((chunk, idx) => {
      const partDur = (weights[idx] / totalWeight) * totalDur;
      const chunkStart = Math.round(cursor * 1000) / 1000;
      const chunkEnd =
        idx === lineChunks.length - 1
          ? Math.round(end * 1000) / 1000
          : Math.round(Math.min(end, cursor + partDur) * 1000) / 1000;
      cursor = chunkEnd;
      result.push({
        id: `${cap.id}_p${idx + 1}`,
        start: chunkStart,
        end: Math.max(chunkStart + 0.15, chunkEnd),
        text: chunk.join('\n'),
        emoji: cap.emoji,
        ...(cap.originalText ? { originalText: cap.originalText } : {}),
      });
    });
  }

  return result;
}

export function generateSrtSubtitles(captions: CaptionSegment[]): string {
  const valid = captions.filter((c) => String(c.text || '').trim().length > 0 && c.end > c.start);
  if (valid.length === 0) return '';

  return (
    valid
      .map((c, idx) => {
        const startSrt = formatSrtTime(c.start);
        const endSrt = formatSrtTime(c.end);
        const lineText = `${String(c.text).trim()}${c.emoji ? ' ' + c.emoji.trim() : ''}`;
        return `${idx + 1}\n${startSrt} --> ${endSrt}\n${lineText}`;
      })
      .join('\n\n') + '\n'
  );
}

export function splitScriptIntoTimedCaptions(
  scriptMy: string,
  totalDuration: number
): CaptionSegment[] {
  const normalized = String(scriptMy || '').replace(/\r?\n+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!normalized) return [];

  const safeDur = Math.max(1.0, Number.isFinite(totalDuration) ? totalDuration : 12);
  const rawChunks = normalized
    .split(/(?<=[။.!?])\s*|\s*;\s*/)
    .map((s) => s.trim())
    .filter(Boolean);

  const chunks: string[] = [];
  for (const part of rawChunks) {
    if (countCharacters(part) > 75) {
      const words = part.split(' ').filter(Boolean);
      const mid = Math.ceil(words.length / 2);
      const firstHalf = words.slice(0, mid).join(' ').trim();
      const secondHalf = words.slice(mid).join(' ').trim();
      if (firstHalf) chunks.push(firstHalf);
      if (secondHalf) chunks.push(secondHalf);
    } else {
      chunks.push(part);
    }
  }

  const finalParts = chunks.length > 0 ? chunks : [normalized];
  const weights = finalParts.map((p) => Math.max(4, countCharacters(p)));
  const totalWeight = weights.reduce((sum, w) => sum + w, 0);

  let cursor = 0;
  return finalParts.map((part, idx) => {
    const dur = (weights[idx] / totalWeight) * safeDur;
    const start = Math.round(cursor * 1000) / 1000;
    const end =
      idx === finalParts.length - 1
        ? Math.round(safeDur * 1000) / 1000
        : Math.round(Math.min(safeDur, cursor + dur) * 1000) / 1000;
    cursor = end;
    return {
      id: `cap_${idx + 1}`,
      start,
      end: Math.max(start + 0.25, end),
      text: part,
      emoji: idx === 0 ? '🎬' : idx === finalParts.length - 1 ? '🔥' : '✨',
    };
  });
}

export function generateAssSubtitles(
  captions: CaptionSegment[],
  videoWidth: number,
  videoHeight: number,
  position: OverlayPosition,
  decoration?: Partial<CaptionDecorationConfig> | null
): string {
  const deco = sanitizeCaptionDecoration(decoration);
  const clampedPosY = Math.min(100 - CAPTION_BOTTOM_SAFETY_MARGIN_PCT - 4, Math.max(8, position.y));
  const clampedPosX = Math.min(100 - 15, Math.max(15, position.x));
  const posX = Math.round((clampedPosX / 100) * videoWidth);
  const posY = Math.round((clampedPosY / 100) * videoHeight);
  const fontSize = Math.max(20, Math.round(videoHeight * 0.045 * deco.fontSizeScale));
  const primaryColour = hexToAssColor(deco.textColor, 100);
  const outlineColour = hexToAssColor(deco.borderColor, 100);
  const outlineWidth = deco.borderEnabled ? deco.borderThickness : 0;
  const bgBoxColour = hexToAssColor(deco.bgColor, deco.bgOpacity);
  const bgBoxPad = Math.max(6, Math.round(deco.bgCornerRadius * 0.55));
  const showBgBox = deco.blurBgEnabled && deco.bgOpacity > 0;
  // Constrain ASS horizontal box margins to 72% usable width (14% margin left/right) and >=9% bottom margin
  const sideMarginPx = Math.max(24, Math.round(videoWidth * ((100 - CAPTION_BOX_MAX_WIDTH_PCT) / 200)));
  const verticalMarginPx = Math.max(20, Math.round(videoHeight * (CAPTION_BOTTOM_SAFETY_MARGIN_PCT / 100)));

  const normalizedCaptions = splitLongCaptionsToMaxTwoLines(captions, {
    videoWidth,
    videoHeight,
    fontSizeScale: deco.fontSizeScale,
  });

  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: ${videoWidth}
PlayResY: ${videoHeight}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: RecapBg,Noto Sans Myanmar,${fontSize},&HFF000000,&HFF000000,${bgBoxColour},${bgBoxColour},1,0,0,0,100,100,0,0,3,${bgBoxPad},0,5,${sideMarginPx},${sideMarginPx},${verticalMarginPx},1
Style: RecapMain,Noto Sans Myanmar,${fontSize},${primaryColour},&H003B82F6,${outlineColour},&H00000000,1,0,0,0,100,100,0,0,1,${outlineWidth},${deco.borderEnabled ? 1 : 0},5,${sideMarginPx},${sideMarginPx},${verticalMarginPx},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const events = normalizedCaptions
    .filter((c) => c.text.trim().length > 0 && c.end > c.start)
    .flatMap((c) => {
      const cleanText = `${c.text.trim()}${c.emoji ? ' ' + c.emoji.trim() : ''}`
        .replace(/\r?\n/g, '\\N')
        .replace(/[{}]/g, '');
      const startAss = formatAssTime(c.start);
      const endAss = formatAssTime(c.end);
      const lines: string[] = [];
      if (showBgBox) {
        lines.push(
          `Dialogue: 0,${startAss},${endAss},RecapBg,,0,0,0,,{\\pos(${posX},${posY})\\fad(120,120)}${cleanText}`
        );
      }
      lines.push(
        `Dialogue: 1,${startAss},${endAss},RecapMain,,0,0,0,,{\\pos(${posX},${posY})\\fad(120,120)}${cleanText}`
      );
      return lines;
    })
    .join('\n');

  return header + events + '\n';
}

export const UPLOAD_CHUNK_SIZE_BYTES = 4 * 1024 * 1024; // 4 MiB (safe under Cloud Run 32 MiB HTTP/1 cap)
export const MAX_UPLOAD_FILE_BYTES = 2 * 1024 * 1024 * 1024; // 2 GiB

export interface UploadChunkPlan {
  useChunked: boolean;
  chunkSizeBytes: number;
  totalChunks: number;
  totalBytes: number;
}

export function validateUploadFileSize(fileSizeBytes: number): { valid: boolean; errorMy?: string } {
  if (!Number.isFinite(fileSizeBytes) || fileSizeBytes <= 0) {
    return { valid: false, errorMy: 'ဗီဒီယိုဖိုင် အရွယ်အစား မမှန်ကန်ပါ (ဖိုင်အလွတ် ဖြစ်နေသည်)' };
  }
  if (fileSizeBytes > MAX_UPLOAD_FILE_BYTES) {
    return { valid: false, errorMy: 'ဗီဒီယိုဖိုင်သည် 2GB ထက် မကြီးရပါ — ဖိုင်အရွယ်အစား လျှော့ချပြီး ထပ်တင်ပါ' };
  }
  return { valid: true };
}

export function computeUploadChunkPlan(
  fileSizeBytes: number,
  chunkSizeBytes = UPLOAD_CHUNK_SIZE_BYTES
): UploadChunkPlan {
  const safeTotal = Math.max(1, Math.floor(Number.isFinite(fileSizeBytes) ? fileSizeBytes : 1));
  const safeChunk = Math.max(64 * 1024, Math.floor(chunkSizeBytes));
  const useChunked = safeTotal > safeChunk;
  const totalChunks = useChunked ? Math.ceil(safeTotal / safeChunk) : 1;
  return {
    useChunked,
    chunkSizeBytes: safeChunk,
    totalChunks,
    totalBytes: safeTotal,
  };
}

export function parseDurationTagToSeconds(rawTag: unknown): number {
  if (typeof rawTag === 'number' && Number.isFinite(rawTag) && rawTag > 0) {
    return rawTag;
  }
  const str = String(rawTag || '').trim();
  if (!str) return 0;
  const asNum = Number(str);
  if (Number.isFinite(asNum) && asNum > 0) return asNum;

  const hmsMatch = str.match(/^(\d+):(\d{1,2}):(\d{1,2}(?:\.\d+)?)$/);
  if (hmsMatch) {
    const h = Number(hmsMatch[1]);
    const m = Number(hmsMatch[2]);
    const s = Number(hmsMatch[3]);
    return h * 3600 + m * 60 + s;
  }
  return 0;
}

export function extractMediaDurationSeconds(ffprobeInfo: {
  format?: { duration?: unknown; tags?: Record<string, unknown> };
  streams?: Array<{ codec_type?: string; duration?: unknown; tags?: Record<string, unknown> }>;
}): number {
  const candidates: number[] = [];
  candidates.push(parseDurationTagToSeconds(ffprobeInfo.format?.duration));
  candidates.push(parseDurationTagToSeconds(ffprobeInfo.format?.tags?.DURATION));
  for (const st of ffprobeInfo.streams || []) {
    candidates.push(parseDurationTagToSeconds(st.duration));
    candidates.push(parseDurationTagToSeconds(st.tags?.DURATION));
  }
  const valid = candidates.filter((d) => Number.isFinite(d) && d > 0);
  return valid.length > 0 ? Math.max(...valid) : 0;
}

export interface ContainedVideoRect {
  width: number;
  height: number;
  aspectRatio: number;
}

/**
 * Computes the exact rendered box dimensions for a video displayed with object-fit: contain
 * inside a preview container without any stretching or aspect-ratio distortion.
 */
export function computeContainedVideoRect(
  containerWidth: number,
  containerHeight: number,
  videoWidth: number,
  videoHeight: number
): ContainedVideoRect {
  const safeCW = Math.max(1, Number.isFinite(containerWidth) ? containerWidth : 640);
  const safeCH = Math.max(1, Number.isFinite(containerHeight) ? containerHeight : 360);
  const safeVW = Math.max(1, Number.isFinite(videoWidth) && videoWidth > 0 ? videoWidth : 1280);
  const safeVH = Math.max(1, Number.isFinite(videoHeight) && videoHeight > 0 ? videoHeight : 720);

  const videoAspect = safeVW / safeVH;
  const containerAspect = safeCW / safeCH;

  if (videoAspect > containerAspect) {
    // Letterboxed top/bottom: full width, proportional height
    const width = Math.round(safeCW);
    const height = Math.max(1, Math.round(safeCW / videoAspect));
    return { width, height, aspectRatio: Number(videoAspect.toFixed(4)) };
  }
  // Pillarboxed left/right or exact fit: full height, proportional width
  const height = Math.round(safeCH);
  const width = Math.max(1, Math.round(safeCH * videoAspect));
  return { width, height, aspectRatio: Number(videoAspect.toFixed(4)) };
}

/**
 * Converts pointer coordinates against the ACTUAL rendered video viewport box into clamped
 * percentages [0..100] of the original video resolution, ensuring overlays stay strictly inside
 * the real video boundary and respect bottom/edge safety margins when requested.
 */
export function clampPointerToVideoViewport(params: {
  clientX: number;
  clientY: number;
  rect: { left: number; top: number; width: number; height: number };
  overlayWidthPx?: number;
  overlayHeightPx?: number;
  bottomSafetyMarginPct?: number;
  topSafetyMarginPct?: number;
  sideSafetyMarginPct?: number;
}): OverlayPosition {
  const {
    clientX,
    clientY,
    rect,
    overlayWidthPx = 0,
    overlayHeightPx = 0,
    bottomSafetyMarginPct = 0,
    topSafetyMarginPct = 0,
    sideSafetyMarginPct = 0,
  } = params;
  const w = Math.max(1, rect.width);
  const h = Math.max(1, rect.height);

  const halfWPct = overlayWidthPx > 0 ? Math.min(48, (overlayWidthPx / w) * 50) : 6;
  const halfHPct = overlayHeightPx > 0 ? Math.min(44, (overlayHeightPx / h) * 50) : 6;

  const rawX = ((clientX - rect.left) / w) * 100;
  const rawY = ((clientY - rect.top) / h) * 100;

  const minX = Math.min(49, halfWPct + sideSafetyMarginPct);
  const maxX = Math.max(minX, 100 - halfWPct - sideSafetyMarginPct);
  const minY = Math.min(49, halfHPct + topSafetyMarginPct);
  const maxY = Math.max(minY, 100 - halfHPct - bottomSafetyMarginPct);

  return {
    x: Math.round(Math.min(maxX, Math.max(minX, rawX)) * 10) / 10,
    y: Math.round(Math.min(maxY, Math.max(minY, rawY)) * 10) / 10,
  };
}

export const AUTO_BLUR_SOLID_SWATCHES = ['#090B10', '#000000', '#1E293B', '#E2E8F0'] as const;

export const DEFAULT_AUTO_BLUR_CONFIG: AutoBlurConfig = {
  enabled: true,
  strength: 65,
  style: 'blur',
  solidColor: '#090B10',
};

export function sanitizeAutoBlurConfig(raw?: Partial<AutoBlurConfig> | null): AutoBlurConfig {
  const c = raw || {};
  const style: AutoBlurStyle =
    c.style === 'pixelate' || c.style === 'solid' || c.style === 'blur'
      ? c.style
      : DEFAULT_AUTO_BLUR_CONFIG.style;
  const strengthRaw = Number(c.strength);
  const strength = Number.isFinite(strengthRaw)
    ? Math.round(Math.min(100, Math.max(10, strengthRaw)))
    : DEFAULT_AUTO_BLUR_CONFIG.strength;

  return {
    enabled: typeof c.enabled === 'boolean' ? c.enabled : DEFAULT_AUTO_BLUR_CONFIG.enabled,
    strength,
    style,
    solidColor: normalizeHexColor(c.solidColor, DEFAULT_AUTO_BLUR_CONFIG.solidColor),
  };
}

export function sanitizeAutoBlurRegions(rawRegions: unknown): AutoBlurRegion[] {
  if (!Array.isArray(rawRegions)) return [];

  const normalized: AutoBlurRegion[] = [];
  for (let i = 0; i < rawRegions.length && normalized.length < 8; i++) {
    const item = rawRegions[i] as Record<string, unknown> | null;
    if (!item || typeof item !== 'object') continue;

    const rawX = Number(item.xPct ?? item.x ?? 0);
    const rawY = Number(item.yPct ?? item.y ?? 0);
    const rawW = Number(item.widthPct ?? item.width ?? 0);
    const rawH = Number(item.heightPct ?? item.height ?? 0);

    if (![rawX, rawY, rawW, rawH].every((n) => Number.isFinite(n))) continue;
    if (rawW < 2 || rawH < 2) continue;

    // Strictly clamp every mask region inside [0..100] of the original video area
    const xPct = Math.round(Math.min(96, Math.max(0, rawX)) * 10) / 10;
    const yPct = Math.round(Math.min(96, Math.max(0, rawY)) * 10) / 10;
    const maxW = Math.max(2, 100 - xPct);
    const maxH = Math.max(2, 100 - yPct);
    const widthPct = Math.round(Math.min(maxW, Math.min(96, Math.max(3, rawW))) * 10) / 10;
    const heightPct = Math.round(Math.min(maxH, Math.min(48, Math.max(3, rawH))) * 10) / 10;

    const kindRaw = String(item.kind || '').toLowerCase();
    const kind: AutoBlurRegion['kind'] =
      kindRaw === 'logo' || kindRaw === 'watermark' || kindRaw === 'graphic' || kindRaw === 'text'
        ? kindRaw
        : 'text';

    normalized.push({
      id: typeof item.id === 'string' && item.id.trim() ? item.id.trim() : `auto_${i + 1}`,
      xPct,
      yPct,
      widthPct,
      heightPct,
      kind,
    });
  }

  return normalized;
}

/**
 * Builds an FFmpeg filtergraph chain that applies blur, pixelate, or solid color masking
 * strictly inside the detected regions at native video dimensions (before scale/pad or new captions).
 */
export function buildAutoBlurFfmpegFilter(params: {
  inputLabel: string;
  outputLabel: string;
  videoWidth: number;
  videoHeight: number;
  regions: AutoBlurRegion[];
  config: AutoBlurConfig;
}): string[] {
  const { inputLabel, outputLabel, videoWidth, videoHeight } = params;
  const config = sanitizeAutoBlurConfig(params.config);
  const regions = sanitizeAutoBlurRegions(params.regions);

  if (!config.enabled || regions.length === 0) {
    return [];
  }

  const vw = Math.max(32, Math.floor(Number.isFinite(videoWidth) ? videoWidth : 1280));
  const vh = Math.max(32, Math.floor(Number.isFinite(videoHeight) ? videoHeight : 720));

  const pixelBoxes = regions
    .map((r) => {
      const x = Math.max(0, Math.min(vw - 8, Math.floor((r.xPct / 100) * vw) & ~1));
      const y = Math.max(0, Math.min(vh - 8, Math.floor((r.yPct / 100) * vh) & ~1));
      const rawW = Math.max(8, Math.round((r.widthPct / 100) * vw) & ~1);
      const rawH = Math.max(8, Math.round((r.heightPct / 100) * vh) & ~1);
      const w = Math.max(8, Math.min(vw - x, rawW) & ~1);
      const h = Math.max(8, Math.min(vh - y, rawH) & ~1);
      return { x, y, w, h };
    })
    .filter((b) => b.w >= 8 && b.h >= 8);

  if (pixelBoxes.length === 0) return [];

  if (config.style === 'solid') {
    const colorHex = config.solidColor.replace('#', '0x');
    const alpha = Math.min(1, Math.max(0.45, 0.35 + (config.strength / 100) * 0.65)).toFixed(2);
    const drawboxes = pixelBoxes
      .map((b) => `drawbox=x=${b.x}:y=${b.y}:w=${b.w}:h=${b.h}:color=${colorHex}@${alpha}:t=fill`)
      .join(',');
    return [`${inputLabel}${drawboxes}${outputLabel}`];
  }

  const filters: string[] = [];
  let currentBase = inputLabel;

  pixelBoxes.forEach((b, idx) => {
    const isLast = idx === pixelBoxes.length - 1;
    const baseNext = isLast ? outputLabel : `[ab_base_${idx}]`;
    const mainRef = `[ab_main_${idx}]`;
    const cropSrc = `[ab_src_${idx}]`;
    const cropOut = `[ab_fx_${idx}]`;

    filters.push(`${currentBase}split=2${mainRef}${cropSrc}`);

    if (config.style === 'pixelate') {
      const blockSize = Math.max(4, Math.round(4 + (config.strength / 100) * 20));
      const smallW = Math.max(2, Math.floor(b.w / blockSize));
      const smallH = Math.max(2, Math.floor(b.h / blockSize));
      filters.push(
        `${cropSrc}crop=${b.w}:${b.h}:${b.x}:${b.y},scale=${smallW}:${smallH}:flags=neighbor,scale=${b.w}:${b.h}:flags=neighbor${cropOut}`
      );
    } else {
      const minSide = Math.min(b.w, b.h);
      const maxLumaRadius = Math.max(0, Math.floor(minSide / 2) - 1);
      // In yuv420p chroma planes are 2x subsampled (cw = w/2, ch = h/2), so max chroma radius is floor(minSide/4) - 1
      const maxChromaRadius = Math.max(0, Math.floor(minSide / 4) - 1);
      const targetRadius = Math.round(3 + (config.strength / 100) * 26);
      const lumaRadius = Math.min(maxLumaRadius, Math.max(1, targetRadius));
      const chromaRadius = Math.min(maxChromaRadius, lumaRadius);
      filters.push(
        `${cropSrc}crop=${b.w}:${b.h}:${b.x}:${b.y},format=yuv420p,boxblur=luma_radius='min(${lumaRadius},max(0,floor(min(w,h)/2)-1))':luma_power=2:chroma_radius='max(0,min(${chromaRadius},floor(min(cw,ch)/2)-1))':chroma_power=1${cropOut}`
      );
    }

    filters.push(`${mainRef}${cropOut}overlay=x=${b.x}:y=${b.y}:format=auto${baseNext}`);
    currentBase = baseNext;
  });

  return filters;
}

function parsePpmFrame(bytes: Uint8Array): { width: number; height: number; rgb: Uint8Array } | null {
  if (!bytes || bytes.length < 16 || bytes[0] !== 0x50 || bytes[1] !== 0x36) return null; // 'P6'
  let idx = 2;
  const tokens: number[] = [];
  const len = bytes.length;

  while (idx < len && tokens.length < 3) {
    // Skip whitespace and # comments
    while (idx < len) {
      const ch = bytes[idx];
      if (ch === 0x23) {
        while (idx < len && bytes[idx] !== 0x0a) idx++;
      } else if (ch === 0x20 || ch === 0x09 || ch === 0x0a || ch === 0x0d) {
        idx++;
      } else {
        break;
      }
    }
    let numStr = '';
    while (idx < len) {
      const ch = bytes[idx];
      if (ch >= 0x30 && ch <= 0x39) {
        numStr += String.fromCharCode(ch);
        idx++;
      } else {
        break;
      }
    }
    if (!numStr) return null;
    tokens.push(Number(numStr));
  }
  if (tokens.length < 3) return null;
  // Consume single whitespace byte after maxval
  if (idx < len && (bytes[idx] === 0x0a || bytes[idx] === 0x20 || bytes[idx] === 0x0d || bytes[idx] === 0x09)) {
    idx++;
  }
  const [width, height] = tokens;
  const expected = width * height * 3;
  if (width <= 0 || height <= 0 || idx + expected > len) return null;
  return { width, height, rgb: bytes.subarray(idx, idx + expected) };
}

/**
 * Deterministic pixel-persistence + spatial-edge overlay detector for offline/fallback auto-blur.
 * Scans multiple timestamp frames for static high-contrast graphics/text/watermarks in corners and lower thirds.
 */
export function detectStaticOverlayRegionsFromPpmFrames(ppmBuffers: Uint8Array[]): AutoBlurRegion[] {
  const frames = ppmBuffers.map(parsePpmFrame).filter((f): f is NonNullable<typeof f> => Boolean(f));
  if (frames.length < 2) return [];

  const { width, height } = frames[0];
  if (!frames.every((f) => f.width === width && f.height === height)) return [];

  const gridCols = 16;
  const gridRows = 9;
  const cellW = width / gridCols;
  const cellH = height / gridRows;

  const activeCells: boolean[][] = Array.from({ length: gridRows }, () => Array(gridCols).fill(false));

  for (let r = 0; r < gridRows; r++) {
    for (let c = 0; c < gridCols; c++) {
      // Check typical graphic/watermark/subtitle zones (top corners, bottom corners, bottom subtitle strip)
      const isCornerOrEdgeZone =
        (r <= 1 && (c <= 3 || c >= gridCols - 4)) ||
        (r >= gridRows - 3 && c >= 2 && c <= gridCols - 3) ||
        (r >= gridRows - 2 && (c <= 3 || c >= gridCols - 4));
      if (!isCornerOrEdgeZone) continue;

      const x0 = Math.floor(c * cellW);
      const x1 = Math.min(width - 1, Math.floor((c + 1) * cellW));
      const y0 = Math.floor(r * cellH);
      const y1 = Math.min(height - 1, Math.floor((r + 1) * cellH));

      let staticEdgeCount = 0;
      let sampleCount = 0;

      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          const p = (y * width + x) * 3;
          const lum0 = 0.299 * frames[0].rgb[p] + 0.587 * frames[0].rgb[p + 1] + 0.114 * frames[0].rgb[p + 2];
          let maxT = 0;
          for (let fi = 1; fi < frames.length; fi++) {
            const lumI =
              0.299 * frames[fi].rgb[p] + 0.587 * frames[fi].rgb[p + 1] + 0.114 * frames[fi].rgb[p + 2];
            maxT = Math.max(maxT, Math.abs(lum0 - lumI));
          }

          const pRight = (y * width + Math.min(width - 1, x + 1)) * 3;
          const lumR =
            0.299 * frames[0].rgb[pRight] + 0.587 * frames[0].rgb[pRight + 1] + 0.114 * frames[0].rgb[pRight + 2];
          const pDown = (Math.min(height - 1, y + 1) * width + x) * 3;
          const lumD =
            0.299 * frames[0].rgb[pDown] + 0.587 * frames[0].rgb[pDown + 1] + 0.114 * frames[0].rgb[pDown + 2];
          const edge = Math.max(Math.abs(lum0 - lumR), Math.abs(lum0 - lumD));

          if (edge > 26 && maxT < 16) {
            staticEdgeCount++;
          }
          sampleCount++;
        }
      }

      if (sampleCount === 0) continue;
      const staticEdgeRatio = staticEdgeCount / sampleCount;

      if (staticEdgeRatio >= 0.08) {
        activeCells[r][c] = true;
      }
    }
  }

  // Group horizontally contiguous active cells per row, then merge vertically overlapping boxes
  const rawRects: Array<{ minC: number; maxC: number; minR: number; maxR: number }> = [];
  for (let r = 0; r < gridRows; r++) {
    let c = 0;
    while (c < gridCols) {
      if (!activeCells[r][c]) {
        c++;
        continue;
      }
      const startC = c;
      while (c < gridCols && activeCells[r][c]) c++;
      const endC = c - 1;
      const existing = rawRects.find(
        (box) => box.maxR === r - 1 && box.minC <= endC + 1 && box.maxC >= startC - 1
      );
      if (existing) {
        existing.minC = Math.min(existing.minC, startC);
        existing.maxC = Math.max(existing.maxC, endC);
        existing.maxR = r;
      } else {
        rawRects.push({ minC: startC, maxC: endC, minR: r, maxR: r });
      }
    }
  }

  const regions: AutoBlurRegion[] = rawRects.map((box, idx) => {
    const xPct = (box.minC / gridCols) * 100;
    const yPct = (box.minR / gridRows) * 100;
    const widthPct = ((box.maxC - box.minC + 1) / gridCols) * 100;
    const heightPct = ((box.maxR - box.minR + 1) / gridRows) * 100;
    const isBottomCenter = box.minR >= gridRows - 3 && box.minC >= 2 && box.maxC <= gridCols - 3;
    return {
      id: `auto_${idx + 1}`,
      xPct: Math.round(xPct * 10) / 10,
      yPct: Math.round(yPct * 10) / 10,
      widthPct: Math.round(widthPct * 10) / 10,
      heightPct: Math.round(heightPct * 10) / 10,
      kind: isBottomCenter ? 'text' : 'watermark',
    };
  });

  return sanitizeAutoBlurRegions(regions);
}

export interface ToolWorkflowStep {
  id: WizardStep;
  displayNum: number;
  shortLabel: string;
}

export interface ToolWorkflowDefinition {
  tool: StudioTool;
  nameMy: string;
  steps: ToolWorkflowStep[];
}

export function getToolWorkflowDefinition(tool: StudioTool): ToolWorkflowDefinition {
  if (tool === 'dubbing') {
    return {
      tool: 'dubbing',
      nameMy: 'မြန်မာအသံသွင်း',
      steps: [
        { id: 1, displayNum: 1, shortLabel: 'ဗီဒီယို' },
        { id: 2, displayNum: 2, shortLabel: 'အသံနှုန်း' },
        { id: 3, displayNum: 3, shortLabel: 'Dubbing/ပုံ' },
        { id: 4, displayNum: 4, shortLabel: 'Export' },
        { id: 5, displayNum: 5, shortLabel: 'ဖန်တီးနေ' },
        { id: 6, displayNum: 6, shortLabel: 'Telegram' },
      ],
    };
  }
  if (tool === 'captions') {
    return {
      tool: 'captions',
      nameMy: 'စာတန်းသီးသန့်',
      steps: [
        { id: 1, displayNum: 1, shortLabel: 'ဗီဒီယို' },
        { id: 2, displayNum: 2, shortLabel: 'မူရင်းအသံ' },
        { id: 3, displayNum: 3, shortLabel: 'စာတန်း/ပုံ' },
        { id: 4, displayNum: 4, shortLabel: 'Export' },
        { id: 5, displayNum: 5, shortLabel: 'ဖန်တီးနေ' },
        { id: 6, displayNum: 6, shortLabel: 'Telegram' },
      ],
    };
  }
  return {
    tool: 'recap',
    nameMy: 'Movie Recap',
    steps: [
      { id: 1, displayNum: 1, shortLabel: 'ဗီဒီယို' },
      { id: 2, displayNum: 2, shortLabel: 'အသံနှုန်း' },
      { id: 3, displayNum: 3, shortLabel: 'စာတန်း/ပုံ' },
      { id: 4, displayNum: 4, shortLabel: 'Export' },
      { id: 5, displayNum: 5, shortLabel: 'ဖန်တီးနေ' },
      { id: 6, displayNum: 6, shortLabel: 'Telegram' },
    ],
  };
}

export function resolveCaptionsEnabledFlag(raw: unknown, defaultValue = true): boolean {
  if (typeof raw === 'boolean') return raw;
  if (typeof raw === 'number') return raw !== 0;
  if (typeof raw === 'string') {
    const normalized = raw.trim().toLowerCase();
    if (!normalized) return defaultValue;
    if (normalized === 'false' || normalized === '0' || normalized === 'off' || normalized === 'no') {
      return false;
    }
    if (normalized === 'true' || normalized === '1' || normalized === 'on' || normalized === 'yes') {
      return true;
    }
  }
  return defaultValue;
}

export function shouldBurnSubtitlesInRender(
  captionsEnabled: boolean,
  captions: CaptionSegment[]
): boolean {
  if (!captionsEnabled) return false;
  if (!Array.isArray(captions) || captions.length === 0) return false;
  return captions.some((c) => Boolean(c && typeof c.text === 'string' && c.text.trim().length > 0));
}


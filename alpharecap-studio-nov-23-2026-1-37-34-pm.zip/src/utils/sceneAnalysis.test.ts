import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildRecapNaturalDialoguePrompt,
  classifySceneProviderError,
  computePpmFrameDifference,
  computeRecapTargetDurationSeconds,
  computeRepresentativeFrameTimestamps,
  computeResumeBatchIndex,
  deduplicateExtractedFrames,
  formatSceneProviderStatusMy,
  GROQ_VISION_MAX_IMAGES_PER_REQUEST,
  isGeminiQuotaExhaustedError,
  mergeScenesChronologically,
  partitionFramesIntoBatches,
  PROVIDER_STATUS_MY,
  selectGroqVisionModelCandidates,
} from './sceneAnalysis';

function makeSolidPpm(width: number, height: number, r: number, g: number, b: number): Uint8Array {
  const header = Buffer.from(`P6\n${width} ${height}\n255\n`, 'ascii');
  const body = new Uint8Array(width * height * 3);
  for (let i = 0; i < width * height; i++) {
    body[i * 3] = r;
    body[i * 3 + 1] = g;
    body[i * 3 + 2] = b;
  }
  const combined = new Uint8Array(header.length + body.length);
  combined.set(header, 0);
  combined.set(body, header.length);
  return combined;
}

test('computeRepresentativeFrameTimestamps preserves chronological timestamps avoiding 0s black frames', () => {
  const shortTimestamps = computeRepresentativeFrameTimestamps(12);
  assert.ok(shortTimestamps.length >= 4);
  assert.ok(shortTimestamps[0] > 0);
  assert.ok(shortTimestamps[shortTimestamps.length - 1] < 12);
  for (let i = 1; i < shortTimestamps.length; i++) {
    assert.ok(shortTimestamps[i] > shortTimestamps[i - 1]);
  }

  const longTimestamps = computeRepresentativeFrameTimestamps(180);
  assert.ok(longTimestamps.length <= 20);
  assert.ok(longTimestamps[longTimestamps.length - 1] < 180);
});

test('deduplicateExtractedFrames removes visually identical consecutive frames while keeping timestamps and story coverage', () => {
  const black = makeSolidPpm(32, 18, 12, 14, 18);
  const red = makeSolidPpm(32, 18, 210, 40, 35);
  const brightBlue = makeSolidPpm(32, 18, 30, 140, 240);

  const frames = [
    { index: 0, timestamp: 0.4, ppmBytes: black },
    { index: 1, timestamp: 2.0, ppmBytes: black }, // duplicate of frame 0
    { index: 2, timestamp: 4.1, ppmBytes: red },
    { index: 3, timestamp: 6.2, ppmBytes: red }, // duplicate of frame 2
    { index: 4, timestamp: 8.5, ppmBytes: brightBlue },
  ];

  assert.equal(computePpmFrameDifference(black, black), 0);
  assert.ok(computePpmFrameDifference(black, red) > 0.25);

  const kept = deduplicateExtractedFrames(frames);
  assert.deepEqual(
    kept.map((f) => f.timestamp),
    [0.4, 4.1, 8.5]
  );
});

test('partitionFramesIntoBatches enforces small batch size <= GROQ_VISION_MAX_IMAGES_PER_REQUEST', () => {
  const frames = Array.from({ length: 10 }, (_, index) => ({ index, timestamp: index + 0.5 }));
  const batches = partitionFramesIntoBatches(frames, 12); // Attempting large batch clamps safely to 3
  assert.equal(batches.length, 4);
  for (const batch of batches) {
    assert.ok(batch.length <= GROQ_VISION_MAX_IMAGES_PER_REQUEST);
  }
});

test('mergeScenesChronologically and computeResumeBatchIndex preserve completed scenes and resume cleanly from last batch', () => {
  const frames = Array.from({ length: 6 }, (_, index) => ({ index, timestamp: (index + 1) * 1.5 }));
  const batch0Completed = [
    { index: 2, timestamp: 4.5, imageUrl: '/f2.jpg', descriptionMy: 'မြင်ကွင်း ၃', provider: 'gemini' as const },
    { index: 0, timestamp: 1.5, imageUrl: '/f0.jpg', descriptionMy: 'မြင်ကွင်း ၁', provider: 'gemini' as const },
    { index: 1, timestamp: 3.0, imageUrl: '/f1.jpg', descriptionMy: 'မြင်ကွင်း ၂', provider: 'gemini' as const },
  ];

  const merged0 = mergeScenesChronologically([], batch0Completed);
  assert.deepEqual(
    merged0.map((s) => s.index),
    [0, 1, 2]
  );

  // Batch 0 (indices 0..2) is complete; resume must jump directly to Batch 1 (indices 3..5)
  assert.equal(computeResumeBatchIndex(frames, merged0, 3), 1);

  const mergedAll = mergeScenesChronologically(merged0, [
    { index: 3, timestamp: 6.0, imageUrl: '/f3.jpg', descriptionMy: 'မြင်ကွင်း ၄', provider: 'groq' as const },
    { index: 4, timestamp: 7.5, imageUrl: '/f4.jpg', descriptionMy: 'မြင်ကွင်း ၅', provider: 'groq' as const },
    { index: 5, timestamp: 9.0, imageUrl: '/f5.jpg', descriptionMy: 'မြင်ကွင်း ၆', provider: 'groq' as const },
  ]);
  assert.equal(mergedAll.length, 6);
  assert.equal(computeResumeBatchIndex(frames, mergedAll, 3), 2);
});

test('isGeminiQuotaExhaustedError detects 429 RESOURCE_EXHAUSTED and daily quota errors', () => {
  assert.equal(isGeminiQuotaExhaustedError(new Error('429 RESOURCE_EXHAUSTED: Quota exceeded')), true);
  assert.equal(isGeminiQuotaExhaustedError({ status: 429, message: 'exceeded your current quota' }), true);
  assert.equal(isGeminiQuotaExhaustedError(new Error('Daily quota limit reached')), true);
  assert.equal(isGeminiQuotaExhaustedError(new Error('500 internal error')), false);
});

test('selectGroqVisionModelCandidates selects qwen/qwen3.8-27b ONLY when present on configured Groq account', () => {
  const withQwen = selectGroqVisionModelCandidates([
    'whisper-large-v3-turbo',
    'qwen/qwen3.8-27b',
    'meta-llama/llama-4-scout-17b-16e-instruct',
  ]);
  assert.equal(withQwen[0], 'qwen/qwen3.8-27b');
  assert.ok(withQwen.includes('meta-llama/llama-4-scout-17b-16e-instruct'));

  const withoutQwen = selectGroqVisionModelCandidates([
    'whisper-large-v3-turbo',
    'llama-3.3-70b-versatile',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'meta-llama/llama-4-maverick-17b-128e-instruct',
  ]);
  assert.equal(withoutQwen.includes('qwen/qwen3.8-27b'), false);
  assert.equal(withoutQwen[0], 'meta-llama/llama-4-scout-17b-16e-instruct');
  assert.equal(withoutQwen[1], 'meta-llama/llama-4-maverick-17b-128e-instruct');
});

test('Myanmar status labels and error classifications report exact user-facing states', () => {
  assert.equal(formatSceneProviderStatusMy('gemini', 'analyzing'), PROVIDER_STATUS_MY.geminiActive);
  assert.equal(formatSceneProviderStatusMy('groq', 'switching'), PROVIDER_STATUS_MY.switchingToGroq);
  assert.equal(formatSceneProviderStatusMy('groq', 'completed'), PROVIDER_STATUS_MY.groqDone);

  const groqQuotaErr = classifySceneProviderError('groq', new Error('429 rate limit exceeded'));
  assert.equal(groqQuotaErr.kind, 'quota');
  assert.ok(groqQuotaErr.errorMy.includes('Groq AI'));

  const groqAuthErr = classifySceneProviderError(
    'groq',
    new Error('Groq 401 {"error":{"message":"Invalid API Key","code":"invalid_api_key"}}')
  );
  assert.equal(groqAuthErr.kind, 'auth');
  assert.ok(groqAuthErr.errorMy.includes('401 Invalid API Key'));
});

test('buildRecapNaturalDialoguePrompt enforces Natural Character Dialogue Integration and 90% target duration', () => {
  assert.equal(computeRecapTargetDurationSeconds(100), 90);
  const { systemInstruction, prompt, targetDurationSeconds } = buildRecapNaturalDialoguePrompt({
    durationSeconds: 60,
    transcript: 'Detective: "Where did you hide the key?" Suspect: "You will never find it before midnight!"',
    voiceStyleName: 'Street Bro',
    voiceStyleTag: 'Natural',
    voiceStyleDesc: 'Conversational',
    speedNote: 'Natural pacing',
    beatListText: '- Beat id="beat_1" [0.00s -> 30.00s, MAX_WORDS=60]: "Detective confronts suspect"',
    beatCount: 1,
    scenes: [
      {
        index: 0,
        timestamp: 2.0,
        imageUrl: '/api/session/s1/file/scene_000.jpg',
        descriptionMy: 'စုံထောက်က မိုးရွာထဲမှာ တရားခံကို မေးခွန်းမေးနေသည်',
      },
    ],
    storyAnalysisMy: 'စုံထောက်နှင့် တရားခံ ထိပ်တိုက်တွေ့ဆုံခန်း',
  });

  assert.equal(targetDurationSeconds, 54);
  assert.ok(systemInstruction.includes('90%'));
  assert.ok(prompt.includes('54.00 seconds (~90%'));
  assert.ok(prompt.includes('NATURAL CHARACTER DIALOGUE INTEGRATION'));
  assert.ok(prompt.includes('Threats and warnings'));
  assert.ok(prompt.includes('DO NOT invent'));
  assert.ok(prompt.includes('faithful description of the observable scene'));
  assert.ok(prompt.includes('စုံထောက်က မိုးရွာထဲမှာ'));
});
